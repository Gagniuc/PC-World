Attribute VB_Name = "Functii"
Option Explicit
Public Declare Function BitBlt Lib "gdi32" (ByVal hDestDC As Long, ByVal X As Long, ByVal y As Long, ByVal nWidth As Long, ByVal nHeight As Long, ByVal hSrcDC As Long, ByVal xSrc As Long, ByVal ySrc As Long, ByVal dwRop As Long) As Long
Public Declare Function StretchBlt Lib "gdi32" (ByVal hDC As Long, ByVal X As Long, ByVal y As Long, ByVal nWidth As Long, ByVal nHeight As Long, ByVal hSrcDC As Long, ByVal xSrc As Long, ByVal ySrc As Long, ByVal nSrcWidth As Long, ByVal nSrcHeight As Long, ByVal dwRop As Long) As Long
Public Declare Function sndPlaySound Lib "winmm" Alias "sndPlaySoundA" (ByVal lpszSoundName As String, ByVal uFlags As Long) As Long

Public Declare Function GetSystemDirectory Lib "kernel32" Alias "GetSystemDirectoryA" (ByVal lpBuffer As String, ByVal nSize As Long) As Long
Public Declare Function GetWindowsDirectory Lib "kernel32" Alias "GetWindowsDirectoryA" (ByVal lpBuffer As String, ByVal nSize As Long) As Long

Public Const SND_SYNC = &H0           '  play synchronously (default)
Public Const SND_ASYNC = &H1      '  play asynchronously
Public Const SND_LOOP = &H8            '  loop the sound until next sndPlaySound


Public Informatii_Decupat_Sectiuni(1 To 6) As String
Public Informatii_Decupat_Sectiuni_S(1 To 6) As String
Public Informatii_final(1 To 6) As String

Public Meniu_Decupat_Sectiuni(1 To 6) As String
Public Meniu_Decupat_Sectiuni_S(1 To 6) As String
Public Meniuri_Sectiune(1 To 6) As String

Public Text_Lunar As String

Public ScrollBuffer As String

Public BackUp_sistem As String

Public Nume_Fisier_HTML As String

Public Alegere_HTML As Boolean
Public Alegere_HTML_asteapta As Boolean
Public Cale_kit_HTML As String

Public C, S As Single
Public MeterValue As Single
Public SL, ST, Size As Integer
Public Num As Integer

Public WinCx, SysCx As String

Public Meniuri(1 To 18) As String

Public Sub MegaHz(wav As String)
'*****************************************************************************
On Error Resume Next
Dim SYNC As Long
'App.Path &
SYNC = SND_ASYNC
Dim R As Long
R = sndPlaySound(ByVal wav, SYNC)
'*****************************************************************************
End Sub

Public Function Recalibrare_text(ByVal numeOBJ As Object, ByVal numeOBJ2 As Object, ByVal zulu_alfa As String) As String
On Error Resume Next

Dim Nume_Fisier, FullPath As String

FullPath = zulu_alfa 'ce e misto e ca-i da si locul obiectului ... principal.OBJ ... tam taaam

Nume_Fisier = "\" & Right(FullPath, Len(FullPath) - InStrRev(FullPath, "\"))
FullPath = Left(FullPath, InStrRev(FullPath, "\") - 1)
numeOBJ2.Caption = FullPath & Nume_Fisier
If numeOBJ2.Width <= numeOBJ.Width Then
Recalibrare_text = FullPath & Nume_Fisier
Else
1:
numeOBJ2.Caption = FullPath & "..\" & Nume_Fisier
If numeOBJ2.Width > numeOBJ.Width Then
FullPath = Mid(FullPath, 1, Len(FullPath) - 3)
GoTo 1
End If
Recalibrare_text = FullPath & ".." & Nume_Fisier
End If
End Function


Public Function Redimensionare_nume_Fisier(ByVal numeOBJ As Object, ByVal numeOBJ2 As Object, ByVal zulu_alfa As String) As String
On Error Resume Next

Dim ex_fis, fff, bey, pula_mea As String

bey = zulu_alfa
numeOBJ2.Caption = bey
fff = InStrRev(bey, ".") - 1
ex_fis = Mid(bey, fff + 1, Len(bey) - fff + 1)
pula_mea = Mid(bey, 1, fff)
If numeOBJ2.Width <= numeOBJ.Width Then GoTo 2
1:
numeOBJ2.Caption = pula_mea & "~" & ex_fis
If numeOBJ2.Width > numeOBJ.Width Then
pula_mea = Mid(pula_mea, 1, Len(pula_mea) - 2)
GoTo 1
Else
Redimensionare_nume_Fisier = pula_mea & "~" & ex_fis
GoTo 3
2:
Redimensionare_nume_Fisier = bey
3:
End If
End Function


Function xx(ByVal tars As Integer)
On Error Resume Next

Dim Keyle As String
Dim Amestec, Este As Variant

Keyle = "ABCDEFGHKLJIMNOPRSTUVZXWabcdefghijklmnoprstuvxywz"
For Amestec = 1 To tars
666:
Randomize
Este = Int(46 * Rnd(46))
If Este = 0 Then GoTo 666
xx = xx & Mid(Keyle, Este, 1)
Next Amestec
End Function

