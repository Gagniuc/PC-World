VERSION 5.00
Begin VB.Form PreFormular 
   Caption         =   "PreFormular"
   ClientHeight    =   8265
   ClientLeft      =   60
   ClientTop       =   450
   ClientWidth     =   11280
   Icon            =   "PreFormular.frx":0000
   LinkTopic       =   "Form1"
   Picture         =   "PreFormular.frx":0D2A
   ScaleHeight     =   551
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   752
   StartUpPosition =   2  'CenterScreen
   Begin GenerareMatrita.Listare_Tip_GIF Giful 
      Height          =   3015
      Left            =   6600
      Top             =   2880
      Width           =   3255
      _ExtentX        =   5741
      _ExtentY        =   5318
      BackColor       =   1121794
   End
   Begin VB.Label InformatiiPrograme 
      BackStyle       =   0  'Transparent
      Caption         =   "Explicatii ..."
      Height          =   2295
      Left            =   600
      TabIndex        =   0
      Top             =   2160
      Width           =   4455
   End
End
Attribute VB_Name = "PreFormular"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Form_Click()
Me.Hide
End Sub

Private Sub Giful_Click()
Me.Hide
End Sub

Private Sub InformatiiPrograme_Click()
Me.Hide
End Sub
