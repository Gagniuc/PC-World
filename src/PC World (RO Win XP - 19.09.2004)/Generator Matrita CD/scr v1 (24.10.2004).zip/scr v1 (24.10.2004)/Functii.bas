Attribute VB_Name = "Functii"

Public Bula_general As String
'utilitare ------------------------------------------
Public UT_Variabile_Nume(0 To 18) As String
Public UT_Variabile_Explicatii(0 To 18) As String
Public UT_Citeste_ma(0 To 18) As String

Public UT_KitZip(0 To 18) As String
Public UT_Kit(0 To 18) As String

Public UT_Img1(0 To 18) As String
Public UT_Img2(0 To 18) As String

Public MM_Variabile_Nume(0 To 18) As String
Public MM_Variabile_Explicatii(0 To 18) As String
Public MM_Citeste_ma(0 To 18) As String

Public MM_KitZip(0 To 18) As String
Public MM_Kit(0 To 18) As String
Public MM_Img1(0 To 18) As String
Public MM_Img2(0 To 18) As String

Public JC_Variabile_Nume(0 To 18) As String
Public JC_Variabile_Explicatii(0 To 18) As String
Public JC_Citeste_ma(0 To 18) As String

Public JC_KitZip(0 To 18) As String
Public JC_Kit(0 To 18) As String
Public JC_Img1(0 To 18) As String
Public JC_Img2(0 To 18) As String

Public IN_Variabile_Nume(0 To 18) As String
Public IN_Variabile_Explicatii(0 To 18) As String
Public IN_Citeste_ma(0 To 18) As String

Public IN_KitZip(0 To 18) As String
Public IN_Kit(0 To 18) As String
Public IN_Img1(0 To 18) As String
Public IN_Img2(0 To 18) As String

Public AV_Variabile_Nume(0 To 18) As String
Public AV_Variabile_Explicatii(0 To 18) As String
Public AV_Citeste_ma(0 To 18) As String

Public AV_KitZip(0 To 18) As String
Public AV_Kit(0 To 18) As String
Public AV_Img1(0 To 18) As String
Public AV_Img2(0 To 18) As String

Public PR_Variabile_Nume(0 To 18) As String
Public PR_Variabile_Explicatii(0 To 18) As String
Public PR_Citeste_ma(0 To 18) As String

Public PR_KitZip(0 To 18) As String
Public PR_Kit(0 To 18) As String
Public PR_Img1(0 To 18) As String
Public PR_Img2(0 To 18) As String
'****************************************************
Public Sectiuni_meniu_final(0 To 5) As String
Public Sectiuni_explicatii_final(0 To 5) As String
'******************** Pt. capturi si fisierul capturat *******************
'Public Cale_Captura(0 To 18) As String
Public numeDriver(0 To 7) As String

'Public CapturaSectiune As String
'Public CapturaProgram As String
'*************************************************************************
Public temp_KitZip(0 To 5) As String
Public temp_Kit(0 To 5) As String
