VERSION 5.00
Object = "{BDC217C8-ED16-11CD-956C-0000C04E4C0A}#1.1#0"; "TABCTL32.OCX"
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "Comdlg32.ocx"
Begin VB.Form Geneza 
   Caption         =   "Matrita CD - PC World  [Versiunea 0.2] - program de Paul Gagniuc [octombrie 2004]"
   ClientHeight    =   9420
   ClientLeft      =   60
   ClientTop       =   450
   ClientWidth     =   12510
   Icon            =   "Form1.frx":0000
   LinkTopic       =   "Form1"
   ScaleHeight     =   628
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   834
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton Captura_Mare666 
      Caption         =   "Captura"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   9600
      TabIndex        =   405
      Top             =   9000
      Width           =   1455
   End
   Begin VB.CommandButton Capturare 
      Caption         =   "Despre"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   11160
      TabIndex        =   404
      Top             =   9000
      Width           =   1215
   End
   Begin MSComDlg.CommonDialog Salvare_matrita 
      Left            =   11400
      Top             =   9360
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
   End
   Begin VB.TextBox Cale_matrita 
      BackColor       =   &H00000000&
      ForeColor       =   &H0000FF00&
      Height          =   285
      Left            =   4800
      TabIndex        =   202
      Text            =   "C:\PC_World"
      Top             =   9000
      Width           =   4695
   End
   Begin VB.CommandButton Creaza_in_Dir 
      Caption         =   "Creaza in ..."
      Height          =   375
      Left            =   3600
      TabIndex        =   201
      Top             =   8880
      Width           =   1095
   End
   Begin MSComDlg.CommonDialog Deschide 
      Left            =   12000
      Top             =   9360
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
   End
   Begin VB.CommandButton Pachet 
      Caption         =   "Compileaza - ( PCWorld- boot CD)"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   120
      TabIndex        =   0
      Top             =   8880
      Width           =   3375
   End
   Begin TabDlg.SSTab Master_Control 
      Height          =   8655
      Left            =   120
      TabIndex        =   1
      Top             =   120
      Width           =   12375
      _ExtentX        =   21828
      _ExtentY        =   15266
      _Version        =   393216
      Style           =   1
      Tabs            =   12
      TabsPerRow      =   12
      TabHeight       =   529
      TabCaption(0)   =   "Utilitare"
      TabPicture(0)   =   "Form1.frx":0D2A
      Tab(0).ControlEnabled=   -1  'True
      Tab(0).Control(0)=   "Label28(0)"
      Tab(0).Control(0).Enabled=   0   'False
      Tab(0).Control(1)=   "Line10(0)"
      Tab(0).Control(1).Enabled=   0   'False
      Tab(0).Control(2)=   "Line9(0)"
      Tab(0).Control(2).Enabled=   0   'False
      Tab(0).Control(3)=   "Line8(0)"
      Tab(0).Control(3).Enabled=   0   'False
      Tab(0).Control(4)=   "BorduraTemp(0)"
      Tab(0).Control(4).Enabled=   0   'False
      Tab(0).Control(5)=   "Label1"
      Tab(0).Control(5).Enabled=   0   'False
      Tab(0).Control(6)=   "Label2"
      Tab(0).Control(6).Enabled=   0   'False
      Tab(0).Control(7)=   "ListaMare(0)"
      Tab(0).Control(7).Enabled=   0   'False
      Tab(0).Control(8)=   "ListaMare(1)"
      Tab(0).Control(8).Enabled=   0   'False
      Tab(0).Control(9)=   "ListaMare(2)"
      Tab(0).Control(9).Enabled=   0   'False
      Tab(0).Control(10)=   "ListaMare(3)"
      Tab(0).Control(10).Enabled=   0   'False
      Tab(0).Control(11)=   "ListaMare(4)"
      Tab(0).Control(11).Enabled=   0   'False
      Tab(0).Control(12)=   "ListaMare(5)"
      Tab(0).Control(12).Enabled=   0   'False
      Tab(0).Control(13)=   "ListaMare(6)"
      Tab(0).Control(13).Enabled=   0   'False
      Tab(0).Control(14)=   "ListaMare(7)"
      Tab(0).Control(14).Enabled=   0   'False
      Tab(0).Control(15)=   "ListaMare(8)"
      Tab(0).Control(15).Enabled=   0   'False
      Tab(0).Control(16)=   "ListaMare(9)"
      Tab(0).Control(16).Enabled=   0   'False
      Tab(0).Control(17)=   "ListaMare(10)"
      Tab(0).Control(17).Enabled=   0   'False
      Tab(0).Control(18)=   "ListaMare(11)"
      Tab(0).Control(18).Enabled=   0   'False
      Tab(0).Control(19)=   "ListaMare(12)"
      Tab(0).Control(19).Enabled=   0   'False
      Tab(0).Control(20)=   "ListaMare(13)"
      Tab(0).Control(20).Enabled=   0   'False
      Tab(0).Control(21)=   "ListaMare(14)"
      Tab(0).Control(21).Enabled=   0   'False
      Tab(0).Control(22)=   "ListaMare(15)"
      Tab(0).Control(22).Enabled=   0   'False
      Tab(0).Control(23)=   "ListaMare(16)"
      Tab(0).Control(23).Enabled=   0   'False
      Tab(0).Control(24)=   "ListaMare(17)"
      Tab(0).Control(24).Enabled=   0   'False
      Tab(0).Control(25)=   "Label3"
      Tab(0).Control(25).Enabled=   0   'False
      Tab(0).Control(26)=   "Line1(0)"
      Tab(0).Control(26).Enabled=   0   'False
      Tab(0).Control(27)=   "Label4"
      Tab(0).Control(27).Enabled=   0   'False
      Tab(0).Control(28)=   "Imagine_Meniu(0)"
      Tab(0).Control(28).Enabled=   0   'False
      Tab(0).Control(29)=   "Pro_imagine(0)"
      Tab(0).Control(29).Enabled=   0   'False
      Tab(0).Control(30)=   "Line1(1)"
      Tab(0).Control(30).Enabled=   0   'False
      Tab(0).Control(31)=   "BorduraGata(0)"
      Tab(0).Control(31).Enabled=   0   'False
      Tab(0).Control(32)=   "Line18(0)"
      Tab(0).Control(32).Enabled=   0   'False
      Tab(0).Control(33)=   "Trebuie_completat(0)"
      Tab(0).Control(33).Enabled=   0   'False
      Tab(0).Control(34)=   "Trebuie_completat(1)"
      Tab(0).Control(34).Enabled=   0   'False
      Tab(0).Control(35)=   "Trebuie_completat(2)"
      Tab(0).Control(35).Enabled=   0   'False
      Tab(0).Control(36)=   "Trebuie_completat(3)"
      Tab(0).Control(36).Enabled=   0   'False
      Tab(0).Control(37)=   "Trebuie_completat(4)"
      Tab(0).Control(37).Enabled=   0   'False
      Tab(0).Control(38)=   "Trebuie_completat(6)"
      Tab(0).Control(38).Enabled=   0   'False
      Tab(0).Control(39)=   "Trebuie_completat(64)"
      Tab(0).Control(39).Enabled=   0   'False
      Tab(0).Control(40)=   "Titlu(0)"
      Tab(0).Control(40).Enabled=   0   'False
      Tab(0).Control(41)=   "Explicatie(0)"
      Tab(0).Control(41).Enabled=   0   'False
      Tab(0).Control(42)=   "calea(0)"
      Tab(0).Control(42).Enabled=   0   'False
      Tab(0).Control(43)=   "cale2(0)"
      Tab(0).Control(43).Enabled=   0   'False
      Tab(0).Control(44)=   "kitZip(0)"
      Tab(0).Control(44).Enabled=   0   'False
      Tab(0).Control(45)=   "kit(0)"
      Tab(0).Control(45).Enabled=   0   'False
      Tab(0).Control(46)=   "IN_Lista(0)"
      Tab(0).Control(46).Enabled=   0   'False
      Tab(0).Control(47)=   "Citeste_Text(0)"
      Tab(0).Control(47).Enabled=   0   'False
      Tab(0).Control(48)=   "Inainte_de(0)"
      Tab(0).Control(48).Enabled=   0   'False
      Tab(0).Control(49)=   "ImagineM(0)"
      Tab(0).Control(49).Enabled=   0   'False
      Tab(0).Control(50)=   "IMica(0)"
      Tab(0).Control(50).Enabled=   0   'False
      Tab(0).Control(51)=   "Imagine_Mare(0)"
      Tab(0).Control(51).Enabled=   0   'False
      Tab(0).Control(52)=   "IMare(0)"
      Tab(0).Control(52).Enabled=   0   'False
      Tab(0).Control(53)=   "Sterge(0)"
      Tab(0).Control(53).Enabled=   0   'False
      Tab(0).ControlCount=   54
      TabCaption(1)   =   "Multimedia"
      TabPicture(1)   =   "Form1.frx":0D46
      Tab(1).ControlEnabled=   0   'False
      Tab(1).Control(0)=   "Sterge(1)"
      Tab(1).Control(1)=   "IMare(1)"
      Tab(1).Control(2)=   "Imagine_Mare(1)"
      Tab(1).Control(3)=   "IMica(1)"
      Tab(1).Control(4)=   "ImagineM(1)"
      Tab(1).Control(5)=   "Inainte_de(1)"
      Tab(1).Control(6)=   "calea(1)"
      Tab(1).Control(7)=   "cale2(1)"
      Tab(1).Control(8)=   "kitZip(1)"
      Tab(1).Control(9)=   "kit(1)"
      Tab(1).Control(10)=   "IN_Lista(1)"
      Tab(1).Control(11)=   "Titlu(1)"
      Tab(1).Control(12)=   "Explicatie(1)"
      Tab(1).Control(13)=   "Citeste_Text(1)"
      Tab(1).Control(14)=   "Trebuie_completat(12)"
      Tab(1).Control(15)=   "Trebuie_completat(11)"
      Tab(1).Control(16)=   "Trebuie_completat(10)"
      Tab(1).Control(17)=   "Trebuie_completat(9)"
      Tab(1).Control(18)=   "Trebuie_completat(8)"
      Tab(1).Control(19)=   "Trebuie_completat(7)"
      Tab(1).Control(20)=   "Trebuie_completat(5)"
      Tab(1).Control(21)=   "Line18(1)"
      Tab(1).Control(22)=   "Label28(1)"
      Tab(1).Control(23)=   "BorduraGata(1)"
      Tab(1).Control(24)=   "Pro_imagine(1)"
      Tab(1).Control(25)=   "Imagine_Meniu(1)"
      Tab(1).Control(26)=   "ListaMareMM(0)"
      Tab(1).Control(27)=   "ListaMareMM(1)"
      Tab(1).Control(28)=   "ListaMareMM(2)"
      Tab(1).Control(29)=   "ListaMareMM(3)"
      Tab(1).Control(30)=   "ListaMareMM(4)"
      Tab(1).Control(31)=   "ListaMareMM(5)"
      Tab(1).Control(32)=   "ListaMareMM(6)"
      Tab(1).Control(33)=   "ListaMareMM(7)"
      Tab(1).Control(34)=   "ListaMareMM(8)"
      Tab(1).Control(35)=   "ListaMareMM(9)"
      Tab(1).Control(36)=   "ListaMareMM(10)"
      Tab(1).Control(37)=   "ListaMareMM(11)"
      Tab(1).Control(38)=   "ListaMareMM(12)"
      Tab(1).Control(39)=   "ListaMareMM(13)"
      Tab(1).Control(40)=   "ListaMareMM(14)"
      Tab(1).Control(41)=   "ListaMareMM(15)"
      Tab(1).Control(42)=   "ListaMareMM(16)"
      Tab(1).Control(43)=   "ListaMareMM(17)"
      Tab(1).Control(44)=   "Line2"
      Tab(1).Control(45)=   "Label8"
      Tab(1).Control(46)=   "Label7"
      Tab(1).Control(47)=   "Label6"
      Tab(1).Control(48)=   "Label5"
      Tab(1).Control(49)=   "Line1(2)"
      Tab(1).Control(50)=   "BorduraTemp(1)"
      Tab(1).Control(51)=   "Line8(1)"
      Tab(1).Control(52)=   "Line9(1)"
      Tab(1).Control(53)=   "Line10(3)"
      Tab(1).ControlCount=   54
      TabCaption(2)   =   "Jocuri"
      TabPicture(2)   =   "Form1.frx":0D62
      Tab(2).ControlEnabled=   0   'False
      Tab(2).Control(0)=   "Line10(1)"
      Tab(2).Control(1)=   "Line9(2)"
      Tab(2).Control(2)=   "Line8(2)"
      Tab(2).Control(3)=   "ListaMareJC(0)"
      Tab(2).Control(4)=   "ListaMareJC(1)"
      Tab(2).Control(5)=   "ListaMareJC(2)"
      Tab(2).Control(6)=   "ListaMareJC(3)"
      Tab(2).Control(7)=   "ListaMareJC(4)"
      Tab(2).Control(8)=   "ListaMareJC(5)"
      Tab(2).Control(9)=   "ListaMareJC(6)"
      Tab(2).Control(10)=   "ListaMareJC(7)"
      Tab(2).Control(11)=   "ListaMareJC(8)"
      Tab(2).Control(12)=   "ListaMareJC(9)"
      Tab(2).Control(13)=   "ListaMareJC(10)"
      Tab(2).Control(14)=   "ListaMareJC(11)"
      Tab(2).Control(15)=   "ListaMareJC(12)"
      Tab(2).Control(16)=   "ListaMareJC(13)"
      Tab(2).Control(17)=   "ListaMareJC(14)"
      Tab(2).Control(18)=   "ListaMareJC(15)"
      Tab(2).Control(19)=   "ListaMareJC(16)"
      Tab(2).Control(20)=   "ListaMareJC(17)"
      Tab(2).Control(21)=   "Line3"
      Tab(2).Control(22)=   "Label9"
      Tab(2).Control(23)=   "Label10"
      Tab(2).Control(24)=   "Label11"
      Tab(2).Control(25)=   "Label12"
      Tab(2).Control(26)=   "Imagine_Meniu(2)"
      Tab(2).Control(27)=   "Pro_imagine(2)"
      Tab(2).Control(28)=   "BorduraGata(2)"
      Tab(2).Control(29)=   "Label28(2)"
      Tab(2).Control(30)=   "Line1(3)"
      Tab(2).Control(31)=   "BorduraTemp(2)"
      Tab(2).Control(32)=   "Line18(2)"
      Tab(2).Control(33)=   "Trebuie_completat(13)"
      Tab(2).Control(34)=   "Trebuie_completat(14)"
      Tab(2).Control(35)=   "Trebuie_completat(15)"
      Tab(2).Control(36)=   "Trebuie_completat(16)"
      Tab(2).Control(37)=   "Trebuie_completat(17)"
      Tab(2).Control(38)=   "Trebuie_completat(18)"
      Tab(2).Control(39)=   "Trebuie_completat(19)"
      Tab(2).Control(40)=   "calea(2)"
      Tab(2).Control(41)=   "cale2(2)"
      Tab(2).Control(42)=   "kitZip(2)"
      Tab(2).Control(43)=   "kit(2)"
      Tab(2).Control(44)=   "IN_Lista(2)"
      Tab(2).Control(45)=   "Titlu(2)"
      Tab(2).Control(46)=   "Explicatie(2)"
      Tab(2).Control(47)=   "Citeste_Text(2)"
      Tab(2).Control(48)=   "Inainte_de(2)"
      Tab(2).Control(49)=   "ImagineM(2)"
      Tab(2).Control(50)=   "IMica(2)"
      Tab(2).Control(51)=   "Imagine_Mare(2)"
      Tab(2).Control(52)=   "IMare(2)"
      Tab(2).Control(53)=   "Sterge(2)"
      Tab(2).ControlCount=   54
      TabCaption(3)   =   "Internet"
      TabPicture(3)   =   "Form1.frx":0D7E
      Tab(3).ControlEnabled=   0   'False
      Tab(3).Control(0)=   "Line10(2)"
      Tab(3).Control(1)=   "Line9(3)"
      Tab(3).Control(2)=   "Line8(3)"
      Tab(3).Control(3)=   "ListaMareIN(0)"
      Tab(3).Control(4)=   "ListaMareIN(1)"
      Tab(3).Control(5)=   "ListaMareIN(2)"
      Tab(3).Control(6)=   "ListaMareIN(3)"
      Tab(3).Control(7)=   "ListaMareIN(4)"
      Tab(3).Control(8)=   "ListaMareIN(5)"
      Tab(3).Control(9)=   "ListaMareIN(6)"
      Tab(3).Control(10)=   "ListaMareIN(7)"
      Tab(3).Control(11)=   "ListaMareIN(8)"
      Tab(3).Control(12)=   "ListaMareIN(9)"
      Tab(3).Control(13)=   "ListaMareIN(10)"
      Tab(3).Control(14)=   "ListaMareIN(11)"
      Tab(3).Control(15)=   "ListaMareIN(12)"
      Tab(3).Control(16)=   "ListaMareIN(13)"
      Tab(3).Control(17)=   "ListaMareIN(14)"
      Tab(3).Control(18)=   "ListaMareIN(15)"
      Tab(3).Control(19)=   "ListaMareIN(16)"
      Tab(3).Control(20)=   "ListaMareIN(17)"
      Tab(3).Control(21)=   "Line4"
      Tab(3).Control(22)=   "Label13"
      Tab(3).Control(23)=   "Label14"
      Tab(3).Control(24)=   "Label15"
      Tab(3).Control(25)=   "Label16"
      Tab(3).Control(26)=   "Imagine_Meniu(3)"
      Tab(3).Control(27)=   "Pro_imagine(3)"
      Tab(3).Control(28)=   "BorduraGata(3)"
      Tab(3).Control(29)=   "Label28(3)"
      Tab(3).Control(30)=   "Line1(4)"
      Tab(3).Control(31)=   "BorduraTemp(3)"
      Tab(3).Control(32)=   "Line18(3)"
      Tab(3).Control(33)=   "Trebuie_completat(20)"
      Tab(3).Control(34)=   "Trebuie_completat(21)"
      Tab(3).Control(35)=   "Trebuie_completat(22)"
      Tab(3).Control(36)=   "Trebuie_completat(23)"
      Tab(3).Control(37)=   "Trebuie_completat(24)"
      Tab(3).Control(38)=   "Trebuie_completat(25)"
      Tab(3).Control(39)=   "Trebuie_completat(26)"
      Tab(3).Control(40)=   "calea(3)"
      Tab(3).Control(41)=   "cale2(3)"
      Tab(3).Control(42)=   "kitZip(3)"
      Tab(3).Control(43)=   "kit(3)"
      Tab(3).Control(44)=   "IN_Lista(3)"
      Tab(3).Control(45)=   "Titlu(3)"
      Tab(3).Control(46)=   "Explicatie(3)"
      Tab(3).Control(47)=   "Citeste_Text(3)"
      Tab(3).Control(48)=   "Inainte_de(3)"
      Tab(3).Control(49)=   "ImagineM(3)"
      Tab(3).Control(50)=   "IMica(3)"
      Tab(3).Control(51)=   "Imagine_Mare(3)"
      Tab(3).Control(52)=   "IMare(3)"
      Tab(3).Control(53)=   "Sterge(3)"
      Tab(3).ControlCount=   54
      TabCaption(4)   =   "Antivirus"
      TabPicture(4)   =   "Form1.frx":0D9A
      Tab(4).ControlEnabled=   0   'False
      Tab(4).Control(0)=   "Line10(4)"
      Tab(4).Control(1)=   "Line9(4)"
      Tab(4).Control(2)=   "Line8(4)"
      Tab(4).Control(3)=   "ListaMareAV(0)"
      Tab(4).Control(4)=   "ListaMareAV(1)"
      Tab(4).Control(5)=   "ListaMareAV(2)"
      Tab(4).Control(6)=   "ListaMareAV(3)"
      Tab(4).Control(7)=   "ListaMareAV(4)"
      Tab(4).Control(8)=   "ListaMareAV(5)"
      Tab(4).Control(9)=   "ListaMareAV(6)"
      Tab(4).Control(10)=   "ListaMareAV(7)"
      Tab(4).Control(11)=   "ListaMareAV(8)"
      Tab(4).Control(12)=   "ListaMareAV(9)"
      Tab(4).Control(13)=   "ListaMareAV(10)"
      Tab(4).Control(14)=   "ListaMareAV(11)"
      Tab(4).Control(15)=   "ListaMareAV(12)"
      Tab(4).Control(16)=   "ListaMareAV(13)"
      Tab(4).Control(17)=   "ListaMareAV(14)"
      Tab(4).Control(18)=   "ListaMareAV(15)"
      Tab(4).Control(19)=   "ListaMareAV(16)"
      Tab(4).Control(20)=   "ListaMareAV(17)"
      Tab(4).Control(21)=   "Line5"
      Tab(4).Control(22)=   "Label17"
      Tab(4).Control(23)=   "Label18"
      Tab(4).Control(24)=   "Label19"
      Tab(4).Control(25)=   "Label20"
      Tab(4).Control(26)=   "Line7"
      Tab(4).Control(27)=   "Imagine_Meniu(4)"
      Tab(4).Control(28)=   "Pro_imagine(4)"
      Tab(4).Control(29)=   "BorduraGata(4)"
      Tab(4).Control(30)=   "Label28(4)"
      Tab(4).Control(31)=   "BorduraTemp(4)"
      Tab(4).Control(32)=   "Line18(4)"
      Tab(4).Control(33)=   "Trebuie_completat(27)"
      Tab(4).Control(34)=   "Trebuie_completat(28)"
      Tab(4).Control(35)=   "Trebuie_completat(29)"
      Tab(4).Control(36)=   "Trebuie_completat(30)"
      Tab(4).Control(37)=   "Trebuie_completat(31)"
      Tab(4).Control(38)=   "Trebuie_completat(32)"
      Tab(4).Control(39)=   "Trebuie_completat(33)"
      Tab(4).Control(40)=   "calea(4)"
      Tab(4).Control(41)=   "cale2(4)"
      Tab(4).Control(42)=   "kitZip(4)"
      Tab(4).Control(43)=   "kit(4)"
      Tab(4).Control(44)=   "IN_Lista(4)"
      Tab(4).Control(45)=   "Titlu(4)"
      Tab(4).Control(46)=   "Explicatie(4)"
      Tab(4).Control(47)=   "Citeste_Text(4)"
      Tab(4).Control(48)=   "Inainte_de(4)"
      Tab(4).Control(49)=   "ImagineM(4)"
      Tab(4).Control(50)=   "IMica(4)"
      Tab(4).Control(51)=   "Imagine_Mare(4)"
      Tab(4).Control(52)=   "IMare(4)"
      Tab(4).Control(53)=   "Sterge(4)"
      Tab(4).ControlCount=   54
      TabCaption(5)   =   "Permanente"
      TabPicture(5)   =   "Form1.frx":0DB6
      Tab(5).ControlEnabled=   0   'False
      Tab(5).Control(0)=   "Line10(5)"
      Tab(5).Control(0).Enabled=   0   'False
      Tab(5).Control(1)=   "Line9(5)"
      Tab(5).Control(1).Enabled=   0   'False
      Tab(5).Control(2)=   "Line8(5)"
      Tab(5).Control(2).Enabled=   0   'False
      Tab(5).Control(3)=   "ListaMarePR(0)"
      Tab(5).Control(3).Enabled=   0   'False
      Tab(5).Control(4)=   "ListaMarePR(1)"
      Tab(5).Control(4).Enabled=   0   'False
      Tab(5).Control(5)=   "ListaMarePR(2)"
      Tab(5).Control(5).Enabled=   0   'False
      Tab(5).Control(6)=   "ListaMarePR(3)"
      Tab(5).Control(6).Enabled=   0   'False
      Tab(5).Control(7)=   "ListaMarePR(4)"
      Tab(5).Control(7).Enabled=   0   'False
      Tab(5).Control(8)=   "ListaMarePR(5)"
      Tab(5).Control(8).Enabled=   0   'False
      Tab(5).Control(9)=   "ListaMarePR(6)"
      Tab(5).Control(9).Enabled=   0   'False
      Tab(5).Control(10)=   "ListaMarePR(7)"
      Tab(5).Control(10).Enabled=   0   'False
      Tab(5).Control(11)=   "ListaMarePR(8)"
      Tab(5).Control(11).Enabled=   0   'False
      Tab(5).Control(12)=   "ListaMarePR(9)"
      Tab(5).Control(12).Enabled=   0   'False
      Tab(5).Control(13)=   "ListaMarePR(10)"
      Tab(5).Control(13).Enabled=   0   'False
      Tab(5).Control(14)=   "ListaMarePR(11)"
      Tab(5).Control(14).Enabled=   0   'False
      Tab(5).Control(15)=   "ListaMarePR(12)"
      Tab(5).Control(15).Enabled=   0   'False
      Tab(5).Control(16)=   "ListaMarePR(13)"
      Tab(5).Control(16).Enabled=   0   'False
      Tab(5).Control(17)=   "ListaMarePR(14)"
      Tab(5).Control(17).Enabled=   0   'False
      Tab(5).Control(18)=   "ListaMarePR(15)"
      Tab(5).Control(18).Enabled=   0   'False
      Tab(5).Control(19)=   "ListaMarePR(16)"
      Tab(5).Control(19).Enabled=   0   'False
      Tab(5).Control(20)=   "ListaMarePR(17)"
      Tab(5).Control(20).Enabled=   0   'False
      Tab(5).Control(21)=   "Line6"
      Tab(5).Control(21).Enabled=   0   'False
      Tab(5).Control(22)=   "Label21"
      Tab(5).Control(22).Enabled=   0   'False
      Tab(5).Control(23)=   "Label22"
      Tab(5).Control(23).Enabled=   0   'False
      Tab(5).Control(24)=   "Label23"
      Tab(5).Control(24).Enabled=   0   'False
      Tab(5).Control(25)=   "Label24"
      Tab(5).Control(25).Enabled=   0   'False
      Tab(5).Control(26)=   "Imagine_Meniu(5)"
      Tab(5).Control(26).Enabled=   0   'False
      Tab(5).Control(27)=   "Pro_imagine(5)"
      Tab(5).Control(27).Enabled=   0   'False
      Tab(5).Control(28)=   "BorduraGata(5)"
      Tab(5).Control(28).Enabled=   0   'False
      Tab(5).Control(29)=   "Label28(5)"
      Tab(5).Control(29).Enabled=   0   'False
      Tab(5).Control(30)=   "BorduraTemp(5)"
      Tab(5).Control(30).Enabled=   0   'False
      Tab(5).Control(31)=   "Line11"
      Tab(5).Control(31).Enabled=   0   'False
      Tab(5).Control(32)=   "Line18(5)"
      Tab(5).Control(32).Enabled=   0   'False
      Tab(5).Control(33)=   "Trebuie_completat(34)"
      Tab(5).Control(33).Enabled=   0   'False
      Tab(5).Control(34)=   "Trebuie_completat(35)"
      Tab(5).Control(34).Enabled=   0   'False
      Tab(5).Control(35)=   "Trebuie_completat(36)"
      Tab(5).Control(35).Enabled=   0   'False
      Tab(5).Control(36)=   "Trebuie_completat(37)"
      Tab(5).Control(36).Enabled=   0   'False
      Tab(5).Control(37)=   "Trebuie_completat(38)"
      Tab(5).Control(37).Enabled=   0   'False
      Tab(5).Control(38)=   "Trebuie_completat(39)"
      Tab(5).Control(38).Enabled=   0   'False
      Tab(5).Control(39)=   "Trebuie_completat(40)"
      Tab(5).Control(39).Enabled=   0   'False
      Tab(5).Control(40)=   "calea(5)"
      Tab(5).Control(40).Enabled=   0   'False
      Tab(5).Control(41)=   "cale2(5)"
      Tab(5).Control(41).Enabled=   0   'False
      Tab(5).Control(42)=   "kitZip(5)"
      Tab(5).Control(42).Enabled=   0   'False
      Tab(5).Control(43)=   "kit(5)"
      Tab(5).Control(43).Enabled=   0   'False
      Tab(5).Control(44)=   "IN_Lista(5)"
      Tab(5).Control(44).Enabled=   0   'False
      Tab(5).Control(45)=   "Titlu(5)"
      Tab(5).Control(45).Enabled=   0   'False
      Tab(5).Control(46)=   "Explicatie(5)"
      Tab(5).Control(46).Enabled=   0   'False
      Tab(5).Control(47)=   "Citeste_Text(5)"
      Tab(5).Control(47).Enabled=   0   'False
      Tab(5).Control(48)=   "Inainte_de(5)"
      Tab(5).Control(48).Enabled=   0   'False
      Tab(5).Control(49)=   "ImagineM(5)"
      Tab(5).Control(49).Enabled=   0   'False
      Tab(5).Control(50)=   "IMica(5)"
      Tab(5).Control(50).Enabled=   0   'False
      Tab(5).Control(51)=   "Imagine_Mare(5)"
      Tab(5).Control(51).Enabled=   0   'False
      Tab(5).Control(52)=   "IMare(5)"
      Tab(5).Control(52).Enabled=   0   'False
      Tab(5).Control(53)=   "I_mica_deschide"
      Tab(5).Control(53).Enabled=   0   'False
      Tab(5).Control(54)=   "I_Mare_deschide"
      Tab(5).Control(54).Enabled=   0   'False
      Tab(5).Control(55)=   "Sterge(5)"
      Tab(5).Control(55).Enabled=   0   'False
      Tab(5).ControlCount=   56
      TabCaption(6)   =   "Revista"
      TabPicture(6)   =   "Form1.frx":0DD2
      Tab(6).ControlEnabled=   0   'False
      Tab(6).Control(0)=   "revista2"
      Tab(6).Control(1)=   "revista1"
      Tab(6).Control(2)=   "Inainte_de(6)"
      Tab(6).Control(3)=   "Revista"
      Tab(6).Control(4)=   "Trebuie_completat(65)"
      Tab(6).Control(5)=   "Label44"
      Tab(6).ControlCount=   6
      TabCaption(7)   =   "INTRO"
      TabPicture(7)   =   "Form1.frx":0DEE
      Tab(7).ControlEnabled=   0   'False
      Tab(7).Control(0)=   "borduraG"
      Tab(7).Control(1)=   "FundalReclama"
      Tab(7).Control(2)=   "CaleFundalIntro"
      Tab(7).Control(3)=   "FundalIntro"
      Tab(7).Control(4)=   "culoare"
      Tab(7).Control(5)=   "latime"
      Tab(7).Control(6)=   "Inaltime"
      Tab(7).Control(7)=   "Intro3"
      Tab(7).Control(8)=   "Intro2"
      Tab(7).Control(9)=   "Intro1"
      Tab(7).Control(10)=   "Inainte_de(7)"
      Tab(7).Control(11)=   "Intro"
      Tab(7).Control(12)=   "Trebuie_completat(47)"
      Tab(7).Control(13)=   "Trebuie_completat(46)"
      Tab(7).Control(14)=   "Trebuie_completat(45)"
      Tab(7).Control(15)=   "Trebuie_completat(44)"
      Tab(7).Control(16)=   "Trebuie_completat(43)"
      Tab(7).Control(17)=   "Trebuie_completat(42)"
      Tab(7).Control(18)=   "Trebuie_completat(41)"
      Tab(7).Control(19)=   "Shape5"
      Tab(7).Control(20)=   "Label34"
      Tab(7).Control(21)=   "Label33"
      Tab(7).Control(22)=   "Label32"
      Tab(7).Control(23)=   "Line17"
      Tab(7).Control(24)=   "Shape1"
      Tab(7).Control(25)=   "Label31"
      Tab(7).Control(26)=   "Line16"
      Tab(7).Control(27)=   "Line15"
      Tab(7).Control(28)=   "Line14"
      Tab(7).Control(29)=   "Line13"
      Tab(7).Control(30)=   "Label30"
      Tab(7).Control(31)=   "Label29"
      Tab(7).Control(32)=   "Label25"
      Tab(7).ControlCount=   33
      TabCaption(8)   =   "Ajutor"
      TabPicture(8)   =   "Form1.frx":0E0A
      Tab(8).ControlEnabled=   0   'False
      Tab(8).Control(0)=   "Label35"
      Tab(8).Control(0).Enabled=   0   'False
      Tab(8).Control(1)=   "Label36"
      Tab(8).Control(1).Enabled=   0   'False
      Tab(8).Control(2)=   "Label37"
      Tab(8).Control(2).Enabled=   0   'False
      Tab(8).Control(3)=   "Shape2"
      Tab(8).Control(3).Enabled=   0   'False
      Tab(8).Control(4)=   "Line19"
      Tab(8).Control(4).Enabled=   0   'False
      Tab(8).Control(5)=   "Line20"
      Tab(8).Control(5).Enabled=   0   'False
      Tab(8).Control(6)=   "Line21"
      Tab(8).Control(6).Enabled=   0   'False
      Tab(8).Control(7)=   "Line22"
      Tab(8).Control(7).Enabled=   0   'False
      Tab(8).Control(8)=   "Label38"
      Tab(8).Control(8).Enabled=   0   'False
      Tab(8).Control(9)=   "Shape3"
      Tab(8).Control(9).Enabled=   0   'False
      Tab(8).Control(10)=   "Shape4"
      Tab(8).Control(10).Enabled=   0   'False
      Tab(8).Control(11)=   "Trebuie_completat(48)"
      Tab(8).Control(11).Enabled=   0   'False
      Tab(8).Control(12)=   "Trebuie_completat(49)"
      Tab(8).Control(12).Enabled=   0   'False
      Tab(8).Control(13)=   "Trebuie_completat(50)"
      Tab(8).Control(13).Enabled=   0   'False
      Tab(8).Control(14)=   "Trebuie_completat(51)"
      Tab(8).Control(14).Enabled=   0   'False
      Tab(8).Control(15)=   "Trebuie_completat(66)"
      Tab(8).Control(15).Enabled=   0   'False
      Tab(8).Control(16)=   "Ajutor"
      Tab(8).Control(16).Enabled=   0   'False
      Tab(8).Control(17)=   "Inainte_de(8)"
      Tab(8).Control(17).Enabled=   0   'False
      Tab(8).Control(18)=   "Ajutor1"
      Tab(8).Control(18).Enabled=   0   'False
      Tab(8).Control(19)=   "Fontul"
      Tab(8).Control(19).Enabled=   0   'False
      Tab(8).Control(20)=   "FontCuloare"
      Tab(8).Control(20).Enabled=   0   'False
      Tab(8).Control(21)=   "FontMarime"
      Tab(8).Control(21).Enabled=   0   'False
      Tab(8).Control(22)=   "FundalAjutor"
      Tab(8).Control(22).Enabled=   0   'False
      Tab(8).Control(23)=   "CaleAjutor"
      Tab(8).Control(23).Enabled=   0   'False
      Tab(8).Control(24)=   "DeschideAjutor"
      Tab(8).Control(24).Enabled=   0   'False
      Tab(8).ControlCount=   25
      TabCaption(9)   =   "Drivere"
      TabPicture(9)   =   "Form1.frx":0E26
      Tab(9).ControlEnabled=   0   'False
      Tab(9).Control(0)=   "DriverInformatii1(0)"
      Tab(9).Control(1)=   "DriverInformatii2(0)"
      Tab(9).Control(2)=   "DriverInformatii3(0)"
      Tab(9).Control(3)=   "DriverInformatii1(1)"
      Tab(9).Control(4)=   "DriverInformatii2(1)"
      Tab(9).Control(5)=   "DriverInformatii3(1)"
      Tab(9).Control(6)=   "DriverInformatii1(2)"
      Tab(9).Control(7)=   "DriverInformatii2(2)"
      Tab(9).Control(8)=   "DriverInformatii3(2)"
      Tab(9).Control(9)=   "DriverInformatii1(3)"
      Tab(9).Control(10)=   "DriverInformatii2(3)"
      Tab(9).Control(11)=   "DriverInformatii3(3)"
      Tab(9).Control(12)=   "DriverInformatii1(4)"
      Tab(9).Control(13)=   "DriverInformatii2(4)"
      Tab(9).Control(14)=   "DriverInformatii3(4)"
      Tab(9).Control(15)=   "DriverInformatii1(5)"
      Tab(9).Control(16)=   "DriverInformatii2(5)"
      Tab(9).Control(17)=   "DriverInformatii3(5)"
      Tab(9).Control(18)=   "DriverInformatii1(6)"
      Tab(9).Control(19)=   "DriverInformatii2(6)"
      Tab(9).Control(20)=   "DriverInformatii3(6)"
      Tab(9).Control(21)=   "DriverInformatii1(7)"
      Tab(9).Control(22)=   "DriverInformatii2(7)"
      Tab(9).Control(23)=   "DriverInformatii3(7)"
      Tab(9).Control(24)=   "Line23(0)"
      Tab(9).Control(25)=   "Line23(1)"
      Tab(9).Control(26)=   "Line23(2)"
      Tab(9).Control(27)=   "Line23(3)"
      Tab(9).Control(28)=   "Line23(4)"
      Tab(9).Control(29)=   "Line24"
      Tab(9).Control(30)=   "etete"
      Tab(9).Control(31)=   "Shape6"
      Tab(9).Control(32)=   "Label26"
      Tab(9).Control(33)=   "Label39"
      Tab(9).Control(34)=   "Label40"
      Tab(9).Control(35)=   "Shape7"
      Tab(9).Control(36)=   "Label41"
      Tab(9).Control(37)=   "Label42"
      Tab(9).Control(38)=   "Label43"
      Tab(9).Control(39)=   "Shape8"
      Tab(9).Control(40)=   "Trebuie_completat(52)"
      Tab(9).Control(41)=   "Trebuie_completat(53)"
      Tab(9).Control(42)=   "Trebuie_completat(54)"
      Tab(9).Control(43)=   "Trebuie_completat(55)"
      Tab(9).Control(44)=   "Trebuie_completat(56)"
      Tab(9).Control(45)=   "Trebuie_completat(57)"
      Tab(9).Control(46)=   "Trebuie_completat(58)"
      Tab(9).Control(47)=   "Trebuie_completat(59)"
      Tab(9).Control(48)=   "Trebuie_completat(60)"
      Tab(9).Control(49)=   "Trebuie_completat(61)"
      Tab(9).Control(50)=   "Label45"
      Tab(9).Control(51)=   "Label46"
      Tab(9).Control(52)=   "Inainte_de(9)"
      Tab(9).Control(53)=   "Drivere"
      Tab(9).Control(54)=   "drivere1"
      Tab(9).Control(55)=   "drivere2"
      Tab(9).Control(56)=   "DrivereTitlu(0)"
      Tab(9).Control(57)=   "DrivereExplicatii(0)"
      Tab(9).Control(58)=   "DrivereTitlu(1)"
      Tab(9).Control(59)=   "DrivereExplicatii(1)"
      Tab(9).Control(60)=   "DrivereExplicatii(2)"
      Tab(9).Control(61)=   "DrivereExplicatii(3)"
      Tab(9).Control(62)=   "DrivereExplicatii(4)"
      Tab(9).Control(63)=   "DrivereExplicatii(5)"
      Tab(9).Control(64)=   "DrivereTitlu(2)"
      Tab(9).Control(65)=   "DrivereTitlu(3)"
      Tab(9).Control(66)=   "DrivereTitlu(4)"
      Tab(9).Control(67)=   "DrivereTitlu(5)"
      Tab(9).Control(68)=   "DrivereTitlu(6)"
      Tab(9).Control(69)=   "DrivereTitlu(7)"
      Tab(9).Control(70)=   "DrivereExplicatii(6)"
      Tab(9).Control(71)=   "DrivereExplicatii(7)"
      Tab(9).Control(72)=   "DrivereCale(0)"
      Tab(9).Control(73)=   "DrivereCale(1)"
      Tab(9).Control(74)=   "DrivereCale(2)"
      Tab(9).Control(75)=   "DrivereCale(3)"
      Tab(9).Control(76)=   "DrivereCale(4)"
      Tab(9).Control(77)=   "DrivereCale(5)"
      Tab(9).Control(78)=   "DrivereCale(6)"
      Tab(9).Control(79)=   "DrivereCale(7)"
      Tab(9).Control(80)=   "StergeDriver"
      Tab(9).Control(81)=   "DeschideDriver"
      Tab(9).Control(82)=   "D_FontMarime"
      Tab(9).Control(83)=   "D_FontCuloare"
      Tab(9).Control(84)=   "D_Font"
      Tab(9).Control(85)=   "D_Cale_text"
      Tab(9).Control(86)=   "D_Alege"
      Tab(9).Control(87)=   "EX_Font"
      Tab(9).Control(88)=   "EX_FontCuloare"
      Tab(9).Control(89)=   "EX_FontMarime"
      Tab(9).Control(90)=   "Deschide_Driver_fundal"
      Tab(9).ControlCount=   91
      TabCaption(10)  =   "Alte setari"
      TabPicture(10)  =   "Form1.frx":0E42
      Tab(10).ControlEnabled=   0   'False
      Tab(10).Control(0)=   "Line12"
      Tab(10).Control(1)=   "Trebuie_completat(62)"
      Tab(10).Control(2)=   "Trebuie_completat(63)"
      Tab(10).Control(3)=   "Image2"
      Tab(10).Control(4)=   "Ar_text"
      Tab(10).Control(5)=   "Arhiva"
      Tab(10).Control(6)=   "sunetul"
      Tab(10).Control(7)=   "cale_sunet"
      Tab(10).Control(8)=   "sunetEu"
      Tab(10).ControlCount=   9
      TabCaption(11)  =   "Impachetare"
      TabPicture(11)  =   "Form1.frx":0E5E
      Tab(11).ControlEnabled=   0   'False
      Tab(11).Control(0)=   "Label27"
      Tab(11).Control(0).Enabled=   0   'False
      Tab(11).Control(1)=   "Compilare_CD"
      Tab(11).Control(1).Enabled=   0   'False
      Tab(11).ControlCount=   2
      Begin MSComDlg.CommonDialog Deschide_Driver_fundal 
         Left            =   -63360
         Top             =   4560
         _ExtentX        =   847
         _ExtentY        =   847
         _Version        =   393216
      End
      Begin VB.TextBox EX_FontMarime 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Left            =   -66960
         TabIndex        =   330
         Text            =   "2"
         Top             =   6240
         Width           =   1815
      End
      Begin VB.TextBox EX_FontCuloare 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Left            =   -66960
         TabIndex        =   329
         Text            =   "ffffff"
         Top             =   5880
         Width           =   1815
      End
      Begin VB.TextBox EX_Font 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Left            =   -66960
         TabIndex        =   328
         Text            =   "Arial"
         Top             =   5520
         Width           =   1815
      End
      Begin VB.CommandButton D_Alege 
         Caption         =   "Imagine fundal pentru ""Drivere"" ..."
         Height          =   255
         Left            =   -74640
         TabIndex        =   327
         Top             =   7440
         Width           =   3255
      End
      Begin VB.TextBox D_Cale_text 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Left            =   -71400
         Locked          =   -1  'True
         TabIndex        =   326
         Top             =   7440
         Width           =   8415
      End
      Begin VB.TextBox D_Font 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Left            =   -72960
         TabIndex        =   322
         Text            =   "Arial"
         Top             =   5520
         Width           =   1815
      End
      Begin VB.TextBox D_FontCuloare 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Left            =   -72960
         TabIndex        =   321
         Text            =   "ffffff"
         Top             =   5880
         Width           =   1815
      End
      Begin VB.TextBox D_FontMarime 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Left            =   -72960
         TabIndex        =   320
         Text            =   "2"
         Top             =   6240
         Width           =   1815
      End
      Begin MSComDlg.CommonDialog DeschideDriver 
         Left            =   -63840
         Top             =   4560
         _ExtentX        =   847
         _ExtentY        =   847
         _Version        =   393216
      End
      Begin VB.CommandButton StergeDriver 
         BackColor       =   &H00C0C0C0&
         Caption         =   "Sterge tot ..."
         Height          =   255
         Left            =   -74880
         TabIndex        =   294
         Top             =   4320
         Width           =   12015
      End
      Begin VB.TextBox DrivereCale 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   7
         Left            =   -66720
         Locked          =   -1  'True
         TabIndex        =   293
         Text            =   "Text1"
         Top             =   3840
         Width           =   3975
      End
      Begin VB.TextBox DrivereCale 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   6
         Left            =   -66720
         Locked          =   -1  'True
         TabIndex        =   292
         Text            =   "Text1"
         Top             =   2880
         Width           =   3975
      End
      Begin VB.TextBox DrivereCale 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   5
         Left            =   -66720
         Locked          =   -1  'True
         TabIndex        =   291
         Text            =   "Text1"
         Top             =   1920
         Width           =   3975
      End
      Begin VB.TextBox DrivereCale 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   4
         Left            =   -66720
         Locked          =   -1  'True
         TabIndex        =   290
         Text            =   "Text1"
         Top             =   960
         Width           =   3975
      End
      Begin VB.TextBox DrivereCale 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   3
         Left            =   -72480
         Locked          =   -1  'True
         TabIndex        =   289
         Text            =   "Text1"
         Top             =   3840
         Width           =   3135
      End
      Begin VB.TextBox DrivereCale 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   2
         Left            =   -72480
         Locked          =   -1  'True
         TabIndex        =   288
         Text            =   "Text1"
         Top             =   2880
         Width           =   3135
      End
      Begin VB.TextBox DrivereCale 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   1
         Left            =   -72480
         Locked          =   -1  'True
         TabIndex        =   287
         Text            =   "Text1"
         Top             =   1920
         Width           =   3135
      End
      Begin VB.TextBox DrivereCale 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   0
         Left            =   -72480
         Locked          =   -1  'True
         TabIndex        =   286
         Text            =   "Text1"
         Top             =   960
         Width           =   3015
      End
      Begin VB.TextBox DrivereExplicatii 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   7
         Left            =   -66720
         TabIndex        =   285
         Text            =   "xxxxxxxxxxxxxxxx"
         Top             =   3600
         Width           =   3975
      End
      Begin VB.TextBox DrivereExplicatii 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   6
         Left            =   -66720
         TabIndex        =   284
         Text            =   "xxxxxxxxxxxxxxxxxx"
         Top             =   2640
         Width           =   3975
      End
      Begin VB.TextBox DrivereTitlu 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   7
         Left            =   -66720
         TabIndex        =   283
         Text            =   "xxxxxxxxxxxxxxxxxxxxx"
         Top             =   3360
         Width           =   3975
      End
      Begin VB.TextBox DrivereTitlu 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   6
         Left            =   -66720
         TabIndex        =   282
         Text            =   "xxxxxxxxxxxxxxxxxxxxxx"
         Top             =   2400
         Width           =   3975
      End
      Begin VB.TextBox DrivereTitlu 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   5
         Left            =   -66720
         TabIndex        =   281
         Text            =   "xxxxxxxxxxxxxxxxx"
         Top             =   1440
         Width           =   3975
      End
      Begin VB.TextBox DrivereTitlu 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   4
         Left            =   -66720
         TabIndex        =   280
         Text            =   "xxxxxxxxxxxxx"
         Top             =   480
         Width           =   3975
      End
      Begin VB.TextBox DrivereTitlu 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   3
         Left            =   -72480
         TabIndex        =   279
         Text            =   "xxxxxxxxxxxxxxxxxxxx"
         Top             =   3360
         Width           =   3135
      End
      Begin VB.TextBox DrivereTitlu 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   2
         Left            =   -72480
         TabIndex        =   278
         Text            =   "xxxxxxxxxxxxxxxxxxxxxx"
         Top             =   2400
         Width           =   3135
      End
      Begin VB.TextBox DrivereExplicatii 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   5
         Left            =   -66720
         TabIndex        =   277
         Text            =   "xxxxxxxxxxxxxxxxxxxx"
         Top             =   1680
         Width           =   3975
      End
      Begin VB.TextBox DrivereExplicatii 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   4
         Left            =   -66720
         TabIndex        =   276
         Text            =   "xxxxxxxxxxxxxxx"
         Top             =   720
         Width           =   3975
      End
      Begin VB.TextBox DrivereExplicatii 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   3
         Left            =   -72480
         TabIndex        =   275
         Text            =   "xxxxxxxxxxxxxxxxxx"
         Top             =   3600
         Width           =   3135
      End
      Begin VB.TextBox DrivereExplicatii 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   2
         Left            =   -72480
         TabIndex        =   274
         Text            =   "xxxxxxxxxxxxxx"
         Top             =   2640
         Width           =   3135
      End
      Begin VB.TextBox DrivereExplicatii 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   1
         Left            =   -72480
         TabIndex        =   273
         Text            =   "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
         Top             =   1680
         Width           =   3135
      End
      Begin VB.TextBox DrivereTitlu 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   1
         Left            =   -72480
         TabIndex        =   272
         Text            =   "xxxxxxxxxxxxxx"
         Top             =   1440
         Width           =   3135
      End
      Begin VB.TextBox DrivereExplicatii 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   0
         Left            =   -72480
         TabIndex        =   271
         Text            =   "xxxxxxxxxxxxxxxxxx"
         Top             =   720
         Width           =   3015
      End
      Begin VB.TextBox DrivereTitlu 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   0
         Left            =   -72480
         TabIndex        =   270
         Text            =   "xxxxxxxxx"
         Top             =   480
         Width           =   3015
      End
      Begin VB.CommandButton Sterge 
         Caption         =   "Sterge toata sectiunea !"
         Height          =   255
         Index           =   5
         Left            =   -65880
         TabIndex        =   269
         Top             =   4560
         Width           =   3015
      End
      Begin VB.CommandButton Sterge 
         Caption         =   "Sterge toata sectiunea !"
         Height          =   255
         Index           =   4
         Left            =   -65880
         TabIndex        =   268
         Top             =   4560
         Width           =   3015
      End
      Begin VB.CommandButton Sterge 
         Caption         =   "Sterge toata sectiunea !"
         Height          =   255
         Index           =   3
         Left            =   -65880
         TabIndex        =   267
         Top             =   4560
         Width           =   3015
      End
      Begin VB.CommandButton Sterge 
         Caption         =   "Sterge toata sectiunea !"
         Height          =   255
         Index           =   2
         Left            =   -65880
         TabIndex        =   266
         Top             =   4560
         Width           =   3015
      End
      Begin VB.CommandButton Sterge 
         Caption         =   "Sterge toata sectiunea !"
         Height          =   255
         Index           =   0
         Left            =   9120
         TabIndex        =   265
         Top             =   4560
         Width           =   3015
      End
      Begin VB.CommandButton Sterge 
         Caption         =   "Sterge toata sectiunea !"
         Height          =   255
         Index           =   1
         Left            =   -65880
         TabIndex        =   264
         Top             =   4560
         Width           =   3015
      End
      Begin MSComDlg.CommonDialog DeschideAjutor 
         Left            =   -74760
         Top             =   8040
         _ExtentX        =   847
         _ExtentY        =   847
         _Version        =   393216
      End
      Begin VB.TextBox CaleAjutor 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Left            =   -71400
         Locked          =   -1  'True
         TabIndex        =   263
         Top             =   7680
         Width           =   8415
      End
      Begin VB.CommandButton FundalAjutor 
         Caption         =   "Imagine fundal pentru ""Ajutor"" ..."
         Height          =   255
         Left            =   -74640
         TabIndex        =   262
         Top             =   7680
         Width           =   3255
      End
      Begin VB.TextBox FontMarime 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Left            =   -72960
         TabIndex        =   257
         Text            =   "2"
         Top             =   6840
         Width           =   1815
      End
      Begin VB.TextBox FontCuloare 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Left            =   -72960
         TabIndex        =   256
         Text            =   "ffffff"
         Top             =   6480
         Width           =   1815
      End
      Begin VB.TextBox Fontul 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Left            =   -72960
         TabIndex        =   255
         Text            =   "Arial"
         Top             =   6120
         Width           =   1815
      End
      Begin MSComDlg.CommonDialog sunetEu 
         Left            =   -74760
         Top             =   1680
         _ExtentX        =   847
         _ExtentY        =   847
         _Version        =   393216
      End
      Begin VB.TextBox cale_sunet 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Left            =   -72360
         Locked          =   -1  'True
         TabIndex        =   253
         Top             =   1320
         Width           =   9495
      End
      Begin VB.CommandButton sunetul 
         Caption         =   "Fisierul wav(sunet fundal) ..."
         Height          =   255
         Left            =   -74760
         TabIndex        =   252
         Top             =   1320
         Width           =   2415
      End
      Begin MSComDlg.CommonDialog I_Mare_deschide 
         Left            =   -69120
         Top             =   5640
         _ExtentX        =   847
         _ExtentY        =   847
         _Version        =   393216
      End
      Begin MSComDlg.CommonDialog I_mica_deschide 
         Left            =   -69720
         Top             =   5640
         _ExtentX        =   847
         _ExtentY        =   847
         _Version        =   393216
      End
      Begin VB.TextBox borduraG 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Left            =   -64080
         TabIndex        =   250
         Text            =   "1"
         Top             =   6840
         Width           =   975
      End
      Begin MSComDlg.CommonDialog FundalReclama 
         Left            =   -74880
         Top             =   7920
         _ExtentX        =   847
         _ExtentY        =   847
         _Version        =   393216
      End
      Begin VB.TextBox CaleFundalIntro 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Left            =   -71400
         Locked          =   -1  'True
         TabIndex        =   248
         Top             =   7560
         Width           =   8295
      End
      Begin VB.CommandButton FundalIntro 
         Caption         =   "Fisier imagine pentru fundal ..."
         Height          =   255
         Left            =   -74760
         TabIndex        =   247
         Top             =   7560
         Width           =   3375
      End
      Begin VB.TextBox culoare 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Left            =   -64080
         TabIndex        =   245
         Text            =   "8888ff"
         Top             =   6480
         Width           =   975
      End
      Begin VB.TextBox latime 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Left            =   -64080
         TabIndex        =   242
         Text            =   "468"
         Top             =   6000
         Width           =   975
      End
      Begin VB.TextBox Inaltime 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Left            =   -64080
         TabIndex        =   241
         Text            =   "60"
         Top             =   5520
         Width           =   975
      End
      Begin VB.TextBox IMare 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   5
         Left            =   -72000
         Locked          =   -1  'True
         TabIndex        =   239
         Top             =   6600
         Width           =   5775
      End
      Begin VB.TextBox IMare 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   4
         Left            =   -72000
         Locked          =   -1  'True
         TabIndex        =   238
         Top             =   6600
         Width           =   5775
      End
      Begin VB.TextBox IMare 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   3
         Left            =   -72000
         Locked          =   -1  'True
         TabIndex        =   237
         Top             =   6600
         Width           =   5775
      End
      Begin VB.TextBox IMare 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   2
         Left            =   -72000
         Locked          =   -1  'True
         TabIndex        =   236
         Top             =   6600
         Width           =   5775
      End
      Begin VB.TextBox IMare 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   1
         Left            =   -72000
         Locked          =   -1  'True
         TabIndex        =   235
         Top             =   6600
         Width           =   5775
      End
      Begin VB.TextBox IMare 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   0
         Left            =   3000
         Locked          =   -1  'True
         TabIndex        =   234
         Top             =   6600
         Width           =   5775
      End
      Begin VB.CommandButton Imagine_Mare 
         Caption         =   "Imagine_Mare"
         Height          =   255
         Index           =   5
         Left            =   -74640
         TabIndex        =   233
         Top             =   6600
         Width           =   2655
      End
      Begin VB.CommandButton Imagine_Mare 
         Caption         =   "Imagine_Mare"
         Height          =   255
         Index           =   4
         Left            =   -74640
         TabIndex        =   232
         Top             =   6600
         Width           =   2655
      End
      Begin VB.CommandButton Imagine_Mare 
         Caption         =   "Imagine_Mare"
         Height          =   255
         Index           =   3
         Left            =   -74640
         TabIndex        =   231
         Top             =   6600
         Width           =   2655
      End
      Begin VB.CommandButton Imagine_Mare 
         Caption         =   "Imagine_Mare"
         Height          =   255
         Index           =   2
         Left            =   -74640
         TabIndex        =   230
         Top             =   6600
         Width           =   2655
      End
      Begin VB.CommandButton Imagine_Mare 
         Caption         =   "Imagine_Mare"
         Height          =   255
         Index           =   1
         Left            =   -74640
         TabIndex        =   229
         Top             =   6600
         Width           =   2655
      End
      Begin VB.CommandButton Imagine_Mare 
         Caption         =   "Imagine_Mare"
         Height          =   255
         Index           =   0
         Left            =   360
         TabIndex        =   228
         Top             =   6600
         Width           =   2655
      End
      Begin VB.TextBox IMica 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   5
         Left            =   -72000
         Locked          =   -1  'True
         TabIndex        =   227
         Top             =   6240
         Width           =   5775
      End
      Begin VB.TextBox IMica 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   4
         Left            =   -72000
         Locked          =   -1  'True
         TabIndex        =   226
         Top             =   6240
         Width           =   5775
      End
      Begin VB.TextBox IMica 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   3
         Left            =   -72000
         Locked          =   -1  'True
         TabIndex        =   225
         Top             =   6240
         Width           =   5775
      End
      Begin VB.TextBox IMica 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   2
         Left            =   -72000
         Locked          =   -1  'True
         TabIndex        =   224
         Top             =   6240
         Width           =   5775
      End
      Begin VB.TextBox IMica 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   1
         Left            =   -72000
         Locked          =   -1  'True
         TabIndex        =   223
         Top             =   6240
         Width           =   5775
      End
      Begin VB.TextBox IMica 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   0
         Left            =   3000
         Locked          =   -1  'True
         TabIndex        =   222
         Top             =   6240
         Width           =   5775
      End
      Begin VB.CommandButton ImagineM 
         Caption         =   "Imagine_Mica"
         Height          =   255
         Index           =   5
         Left            =   -74640
         TabIndex        =   221
         Top             =   6240
         Width           =   2655
      End
      Begin VB.CommandButton ImagineM 
         Caption         =   "Imagine_Mica"
         Height          =   255
         Index           =   4
         Left            =   -74640
         TabIndex        =   220
         Top             =   6240
         Width           =   2655
      End
      Begin VB.CommandButton ImagineM 
         Caption         =   "Imagine_Mica"
         Height          =   255
         Index           =   3
         Left            =   -74640
         TabIndex        =   219
         Top             =   6240
         Width           =   2655
      End
      Begin VB.CommandButton ImagineM 
         Caption         =   "Imagine_Mica"
         Height          =   255
         Index           =   2
         Left            =   -74640
         TabIndex        =   218
         Top             =   6240
         Width           =   2655
      End
      Begin VB.CommandButton ImagineM 
         Caption         =   "Imagine_Mica"
         Height          =   255
         Index           =   1
         Left            =   -74640
         TabIndex        =   217
         Top             =   6240
         Width           =   2655
      End
      Begin VB.CommandButton ImagineM 
         Caption         =   "Imagine_Mica"
         Height          =   255
         Index           =   0
         Left            =   360
         TabIndex        =   216
         Top             =   6240
         Width           =   2655
      End
      Begin VB.CommandButton Arhiva 
         Caption         =   "Calea fisierului arhiva ..."
         Height          =   255
         Left            =   -74760
         TabIndex        =   215
         Top             =   720
         Width           =   2415
      End
      Begin VB.TextBox Ar_text 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Left            =   -72360
         Locked          =   -1  'True
         TabIndex        =   214
         Top             =   720
         Width           =   9495
      End
      Begin VB.TextBox Compilare_CD 
         BackColor       =   &H00000000&
         BeginProperty Font 
            Name            =   "System"
            Size            =   9.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H0000FF00&
         Height          =   7815
         Left            =   -74880
         Locked          =   -1  'True
         MultiLine       =   -1  'True
         ScrollBars      =   3  'Both
         TabIndex        =   212
         Top             =   720
         Width           =   12135
      End
      Begin VB.TextBox drivere2 
         Height          =   615
         Left            =   -63720
         MultiLine       =   -1  'True
         ScrollBars      =   3  'Both
         TabIndex        =   211
         Text            =   "Form1.frx":0E7A
         Top             =   8040
         Visible         =   0   'False
         Width           =   1095
      End
      Begin VB.TextBox drivere1 
         Height          =   615
         Left            =   -64920
         MultiLine       =   -1  'True
         ScrollBars      =   3  'Both
         TabIndex        =   210
         Text            =   "Form1.frx":0EDB
         Top             =   8040
         Visible         =   0   'False
         Width           =   1215
      End
      Begin VB.TextBox Drivere 
         Height          =   615
         Left            =   -75000
         MultiLine       =   -1  'True
         ScrollBars      =   3  'Both
         TabIndex        =   209
         Text            =   "Form1.frx":17FD
         Top             =   8040
         Visible         =   0   'False
         Width           =   2295
      End
      Begin VB.TextBox Intro3 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   2535
         Left            =   -74880
         MultiLine       =   -1  'True
         ScrollBars      =   3  'Both
         TabIndex        =   208
         Text            =   "Form1.frx":189C
         Top             =   4560
         Width           =   9375
      End
      Begin VB.TextBox Ajutor1 
         Height          =   975
         Left            =   -65160
         MultiLine       =   -1  'True
         ScrollBars      =   3  'Both
         TabIndex        =   207
         Text            =   "Form1.frx":19D0
         Top             =   600
         Visible         =   0   'False
         Width           =   1935
      End
      Begin VB.TextBox Intro2 
         Height          =   1215
         Left            =   -68160
         MultiLine       =   -1  'True
         ScrollBars      =   3  'Both
         TabIndex        =   206
         Text            =   "Form1.frx":2232
         Top             =   4680
         Visible         =   0   'False
         Width           =   1935
      End
      Begin VB.TextBox Intro1 
         Height          =   1215
         Left            =   -70320
         MultiLine       =   -1  'True
         ScrollBars      =   3  'Both
         TabIndex        =   205
         Text            =   "Form1.frx":27EC
         Top             =   4680
         Visible         =   0   'False
         Width           =   2175
      End
      Begin VB.TextBox revista2 
         Height          =   1455
         Left            =   -71760
         MultiLine       =   -1  'True
         ScrollBars      =   3  'Both
         TabIndex        =   204
         Text            =   "Form1.frx":31DC
         Top             =   6480
         Visible         =   0   'False
         Width           =   2895
      End
      Begin VB.TextBox revista1 
         Height          =   1455
         Left            =   -74760
         MultiLine       =   -1  'True
         ScrollBars      =   3  'Both
         TabIndex        =   203
         Text            =   "Form1.frx":3203
         Top             =   6480
         Visible         =   0   'False
         Width           =   2895
      End
      Begin VB.CommandButton Inainte_de 
         Caption         =   "Vezi cum arata inainte de compilare !"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Index           =   9
         Left            =   -71640
         TabIndex        =   200
         Top             =   8280
         Width           =   5775
      End
      Begin VB.CommandButton Inainte_de 
         Caption         =   "Vezi cum arata inainte de compilare !"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Index           =   8
         Left            =   -71640
         TabIndex        =   199
         Top             =   8280
         Width           =   5775
      End
      Begin VB.CommandButton Inainte_de 
         Caption         =   "Vezi cum arata inainte de compilare !"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Index           =   7
         Left            =   -71640
         TabIndex        =   198
         Top             =   8280
         Width           =   5775
      End
      Begin VB.CommandButton Inainte_de 
         Caption         =   "Vezi cum arata inainte de compilare !"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Index           =   6
         Left            =   -71640
         TabIndex        =   197
         Top             =   8280
         Width           =   5775
      End
      Begin VB.CommandButton Inainte_de 
         Caption         =   "Vezi cum arata inainte de compilare !"
         Height          =   255
         Index           =   5
         Left            =   -74640
         TabIndex        =   58
         Top             =   8280
         Width           =   8535
      End
      Begin VB.CommandButton Inainte_de 
         Caption         =   "Vezi cum arata inainte de compilare !"
         Height          =   255
         Index           =   4
         Left            =   -74640
         TabIndex        =   57
         Top             =   8280
         Width           =   8535
      End
      Begin VB.CommandButton Inainte_de 
         Caption         =   "Vezi cum arata inainte de compilare !"
         Height          =   255
         Index           =   3
         Left            =   -74640
         TabIndex        =   56
         Top             =   8280
         Width           =   8535
      End
      Begin VB.CommandButton Inainte_de 
         Caption         =   "Vezi cum arata inainte de compilare !"
         Height          =   255
         Index           =   2
         Left            =   -74640
         TabIndex        =   55
         Top             =   8280
         Width           =   8535
      End
      Begin VB.CommandButton Inainte_de 
         Caption         =   "Vezi cum arata inainte de compilare !"
         Height          =   255
         Index           =   1
         Left            =   -74640
         TabIndex        =   54
         Top             =   8280
         Width           =   8535
      End
      Begin VB.CommandButton Inainte_de 
         Caption         =   "Vezi cum arata inainte de compilare !"
         Height          =   255
         Index           =   0
         Left            =   360
         TabIndex        =   53
         Top             =   8280
         Width           =   8535
      End
      Begin VB.TextBox Citeste_Text 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   1815
         Index           =   5
         Left            =   -74640
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertical
         TabIndex        =   52
         Text            =   "Form1.frx":3B05
         Top             =   3720
         Width           =   4575
      End
      Begin VB.TextBox Explicatie 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   1845
         Index           =   5
         Left            =   -74640
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertical
         TabIndex        =   51
         Text            =   "Form1.frx":3B4F
         ToolTipText     =   "Date privind programul prezentat !"
         Top             =   1440
         Width           =   4575
      End
      Begin VB.TextBox Titlu 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   5
         Left            =   -72600
         MaxLength       =   36
         TabIndex        =   50
         Text            =   "Nume program"
         ToolTipText     =   "Nume program"
         Top             =   720
         Width           =   2535
      End
      Begin VB.CommandButton IN_Lista 
         Caption         =   "Introdu in lista de setari"
         Height          =   495
         Index           =   5
         Left            =   -74640
         TabIndex        =   49
         Top             =   7680
         Width           =   8535
      End
      Begin VB.CommandButton kit 
         Caption         =   "Kit-ul pt. butonul ""Instalare"""
         Height          =   255
         Index           =   5
         Left            =   -74640
         TabIndex        =   48
         Top             =   7320
         Width           =   2655
      End
      Begin VB.CommandButton kitZip 
         Caption         =   "Kit-ul pt. butonul ""Copiere"""
         Height          =   255
         Index           =   5
         Left            =   -74640
         TabIndex        =   47
         Top             =   6960
         Width           =   2655
      End
      Begin VB.TextBox cale2 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   5
         Left            =   -72000
         Locked          =   -1  'True
         TabIndex        =   46
         Top             =   7320
         Width           =   5775
      End
      Begin VB.TextBox calea 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   5
         Left            =   -72000
         Locked          =   -1  'True
         TabIndex        =   45
         Top             =   6960
         Width           =   5775
      End
      Begin VB.TextBox Citeste_Text 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   1815
         Index           =   4
         Left            =   -74640
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertical
         TabIndex        =   44
         Text            =   "Form1.frx":3B74
         Top             =   3720
         Width           =   4575
      End
      Begin VB.TextBox Explicatie 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   1845
         Index           =   4
         Left            =   -74640
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertical
         TabIndex        =   43
         Text            =   "Form1.frx":3BBE
         ToolTipText     =   "Date privind programul prezentat !"
         Top             =   1440
         Width           =   4575
      End
      Begin VB.TextBox Titlu 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   4
         Left            =   -72600
         MaxLength       =   36
         TabIndex        =   42
         Text            =   "Nume program"
         ToolTipText     =   "Nume program"
         Top             =   720
         Width           =   2535
      End
      Begin VB.CommandButton IN_Lista 
         Caption         =   "Introdu in lista de setari"
         Height          =   495
         Index           =   4
         Left            =   -74640
         TabIndex        =   41
         Top             =   7680
         Width           =   8535
      End
      Begin VB.CommandButton kit 
         Caption         =   "Kit-ul pt. butonul ""Instalare"""
         Height          =   255
         Index           =   4
         Left            =   -74640
         TabIndex        =   40
         Top             =   7320
         Width           =   2655
      End
      Begin VB.CommandButton kitZip 
         Caption         =   "Kit-ul pt. butonul ""Copiere"""
         Height          =   255
         Index           =   4
         Left            =   -74640
         TabIndex        =   39
         Top             =   6960
         Width           =   2655
      End
      Begin VB.TextBox cale2 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   4
         Left            =   -72000
         Locked          =   -1  'True
         TabIndex        =   38
         Top             =   7320
         Width           =   5775
      End
      Begin VB.TextBox calea 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   4
         Left            =   -72000
         Locked          =   -1  'True
         TabIndex        =   37
         Top             =   6960
         Width           =   5775
      End
      Begin VB.TextBox Citeste_Text 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   1815
         Index           =   3
         Left            =   -74640
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertical
         TabIndex        =   36
         Text            =   "Form1.frx":3BE3
         Top             =   3720
         Width           =   4575
      End
      Begin VB.TextBox Explicatie 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   1845
         Index           =   3
         Left            =   -74640
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertical
         TabIndex        =   35
         Text            =   "Form1.frx":3C2D
         ToolTipText     =   "Date privind programul prezentat !"
         Top             =   1440
         Width           =   4575
      End
      Begin VB.TextBox Titlu 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   3
         Left            =   -72600
         MaxLength       =   36
         TabIndex        =   34
         Text            =   "Nume program"
         ToolTipText     =   "Nume program"
         Top             =   720
         Width           =   2535
      End
      Begin VB.CommandButton IN_Lista 
         Caption         =   "Introdu in lista de setari"
         Height          =   495
         Index           =   3
         Left            =   -74640
         TabIndex        =   33
         Top             =   7680
         Width           =   8535
      End
      Begin VB.CommandButton kit 
         Caption         =   "Kit-ul pt. butonul ""Instalare"""
         Height          =   255
         Index           =   3
         Left            =   -74640
         TabIndex        =   32
         Top             =   7320
         Width           =   2655
      End
      Begin VB.CommandButton kitZip 
         Caption         =   "Kit-ul pt. butonul ""Copiere"""
         Height          =   255
         Index           =   3
         Left            =   -74640
         TabIndex        =   31
         Top             =   6960
         Width           =   2655
      End
      Begin VB.TextBox cale2 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   3
         Left            =   -72000
         Locked          =   -1  'True
         TabIndex        =   30
         Top             =   7320
         Width           =   5775
      End
      Begin VB.TextBox calea 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   3
         Left            =   -72000
         Locked          =   -1  'True
         TabIndex        =   29
         Top             =   6960
         Width           =   5775
      End
      Begin VB.TextBox Citeste_Text 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   1815
         Index           =   2
         Left            =   -74640
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertical
         TabIndex        =   28
         Text            =   "Form1.frx":3C52
         Top             =   3720
         Width           =   4575
      End
      Begin VB.TextBox Explicatie 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   1845
         Index           =   2
         Left            =   -74640
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertical
         TabIndex        =   27
         Text            =   "Form1.frx":3C9C
         ToolTipText     =   "Date privind programul prezentat !"
         Top             =   1440
         Width           =   4575
      End
      Begin VB.TextBox Titlu 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   2
         Left            =   -72600
         MaxLength       =   36
         TabIndex        =   26
         Text            =   "Nume program"
         ToolTipText     =   "Nume program"
         Top             =   720
         Width           =   2535
      End
      Begin VB.CommandButton IN_Lista 
         Caption         =   "Introdu in lista de setari"
         Height          =   495
         Index           =   2
         Left            =   -74640
         TabIndex        =   25
         Top             =   7680
         Width           =   8535
      End
      Begin VB.CommandButton kit 
         Caption         =   "Kit-ul pt. butonul ""Instalare"""
         Height          =   255
         Index           =   2
         Left            =   -74640
         TabIndex        =   24
         Top             =   7320
         Width           =   2655
      End
      Begin VB.CommandButton kitZip 
         Caption         =   "Kit-ul pt. butonul ""Copiere"""
         Height          =   255
         Index           =   2
         Left            =   -74640
         TabIndex        =   23
         Top             =   6960
         Width           =   2655
      End
      Begin VB.TextBox cale2 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   2
         Left            =   -72000
         Locked          =   -1  'True
         TabIndex        =   22
         Top             =   7320
         Width           =   5775
      End
      Begin VB.TextBox calea 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   2
         Left            =   -72000
         Locked          =   -1  'True
         TabIndex        =   21
         Top             =   6960
         Width           =   5775
      End
      Begin VB.TextBox calea 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   1
         Left            =   -72000
         Locked          =   -1  'True
         TabIndex        =   20
         Top             =   6960
         Width           =   5775
      End
      Begin VB.TextBox cale2 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   1
         Left            =   -72000
         Locked          =   -1  'True
         TabIndex        =   19
         Top             =   7320
         Width           =   5775
      End
      Begin VB.CommandButton kitZip 
         Caption         =   "Kit-ul pt. butonul ""Copiere"""
         Height          =   255
         Index           =   1
         Left            =   -74640
         TabIndex        =   18
         Top             =   6960
         Width           =   2655
      End
      Begin VB.CommandButton kit 
         Caption         =   "Kit-ul pt. butonul ""Instalare"""
         Height          =   255
         Index           =   1
         Left            =   -74640
         TabIndex        =   17
         Top             =   7320
         Width           =   2655
      End
      Begin VB.CommandButton IN_Lista 
         Caption         =   "Introdu in lista de setari"
         Height          =   495
         Index           =   1
         Left            =   -74640
         TabIndex        =   16
         Top             =   7680
         Width           =   8535
      End
      Begin VB.TextBox Titlu 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   1
         Left            =   -72600
         MaxLength       =   36
         TabIndex        =   15
         Text            =   "Nume program"
         ToolTipText     =   "Nume program"
         Top             =   720
         Width           =   2535
      End
      Begin VB.TextBox Explicatie 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   1845
         Index           =   1
         Left            =   -74640
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertical
         TabIndex        =   14
         Text            =   "Form1.frx":3CC1
         ToolTipText     =   "Date privind programul prezentat !"
         Top             =   1440
         Width           =   4575
      End
      Begin VB.TextBox Citeste_Text 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   1815
         Index           =   1
         Left            =   -74640
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertical
         TabIndex        =   13
         Text            =   "Form1.frx":3CE6
         Top             =   3720
         Width           =   4575
      End
      Begin VB.TextBox Citeste_Text 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   1815
         Index           =   0
         Left            =   360
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertical
         TabIndex        =   12
         Text            =   "Form1.frx":3D30
         Top             =   3720
         Width           =   4575
      End
      Begin VB.CommandButton IN_Lista 
         Caption         =   "Introdu datele in lista de setari"
         Height          =   495
         Index           =   0
         Left            =   360
         TabIndex        =   11
         Top             =   7680
         Width           =   8535
      End
      Begin VB.CommandButton kit 
         Caption         =   "Kit-ul pt. butonul ""Instalare"""
         Height          =   255
         Index           =   0
         Left            =   360
         TabIndex        =   10
         Top             =   7320
         Width           =   2655
      End
      Begin VB.CommandButton kitZip 
         Caption         =   "Kit-ul pt. butonul ""Copiere"""
         Height          =   255
         Index           =   0
         Left            =   360
         TabIndex        =   9
         Top             =   6960
         Width           =   2655
      End
      Begin VB.TextBox Revista 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FFFF&
         Height          =   7335
         Left            =   -74880
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertical
         TabIndex        =   8
         Text            =   "Form1.frx":3D6D
         Top             =   720
         Width           =   12135
      End
      Begin VB.TextBox Intro 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   2895
         Left            =   -74880
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertical
         TabIndex        =   7
         Text            =   "Form1.frx":4DD3
         Top             =   480
         Width           =   12015
      End
      Begin VB.TextBox Ajutor 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   5415
         Left            =   -74760
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertical
         TabIndex        =   6
         Text            =   "Form1.frx":50F3
         Top             =   480
         Width           =   11895
      End
      Begin VB.TextBox cale2 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   0
         Left            =   3000
         Locked          =   -1  'True
         TabIndex        =   5
         Top             =   7320
         Width           =   5775
      End
      Begin VB.TextBox calea 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   0
         Left            =   3000
         Locked          =   -1  'True
         TabIndex        =   4
         Top             =   6960
         Width           =   5775
      End
      Begin VB.TextBox Explicatie 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   1845
         Index           =   0
         Left            =   360
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertical
         TabIndex        =   3
         Text            =   "Form1.frx":5BE0
         ToolTipText     =   "Date despre utilitarul prezentat !"
         Top             =   1440
         Width           =   4575
      End
      Begin VB.TextBox Titlu 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   0
         Left            =   2400
         MaxLength       =   36
         TabIndex        =   2
         Text            =   "Nume utilitar"
         ToolTipText     =   "Nume utilitar"
         Top             =   720
         Width           =   2535
      End
      Begin VB.Image Image2 
         Height          =   3600
         Left            =   -70200
         Picture         =   "Form1.frx":5C05
         Top             =   3000
         Visible         =   0   'False
         Width           =   3090
      End
      Begin VB.Label Label46 
         BackStyle       =   0  'Transparent
         Caption         =   "Textul cu care se scriu explicatiile privitoare la drivere :"
         Height          =   255
         Left            =   -69000
         TabIndex        =   403
         Top             =   5160
         Width           =   3975
      End
      Begin VB.Label Label45 
         BackStyle       =   0  'Transparent
         Caption         =   "Textul cu care se scriu numele driverilor :"
         Height          =   255
         Left            =   -74880
         TabIndex        =   402
         Top             =   5160
         Width           =   3495
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF00FF&
         Height          =   255
         Index           =   66
         Left            =   -63000
         TabIndex        =   401
         Top             =   7680
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   65
         Left            =   -70800
         TabIndex        =   400
         Top             =   480
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF0000&
         Height          =   255
         Index           =   64
         Left            =   8760
         TabIndex        =   399
         Top             =   6960
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   63
         Left            =   -62880
         TabIndex        =   398
         Top             =   720
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   62
         Left            =   -62880
         TabIndex        =   397
         Top             =   1320
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF00FF&
         Height          =   255
         Index           =   61
         Left            =   -63000
         TabIndex        =   396
         Top             =   7440
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   60
         Left            =   -69480
         TabIndex        =   395
         Top             =   480
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   59
         Left            =   -69480
         TabIndex        =   394
         Top             =   720
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   58
         Left            =   -69480
         TabIndex        =   393
         Top             =   960
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF00FF&
         Height          =   255
         Index           =   57
         Left            =   -71160
         TabIndex        =   392
         Top             =   5520
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF00FF&
         Height          =   255
         Index           =   56
         Left            =   -71160
         TabIndex        =   391
         Top             =   5880
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF00FF&
         Height          =   255
         Index           =   55
         Left            =   -71160
         TabIndex        =   390
         Top             =   6240
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF00FF&
         Height          =   255
         Index           =   54
         Left            =   -65160
         TabIndex        =   389
         Top             =   5520
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF00FF&
         Height          =   255
         Index           =   53
         Left            =   -65160
         TabIndex        =   388
         Top             =   5880
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF00FF&
         Height          =   255
         Index           =   52
         Left            =   -65160
         TabIndex        =   387
         Top             =   6240
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF00FF&
         Height          =   255
         Index           =   51
         Left            =   -62880
         TabIndex        =   386
         Top             =   480
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF00FF&
         Height          =   255
         Index           =   50
         Left            =   -71160
         TabIndex        =   385
         Top             =   6840
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF00FF&
         Height          =   255
         Index           =   49
         Left            =   -71160
         TabIndex        =   384
         Top             =   6480
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF00FF&
         Height          =   255
         Index           =   48
         Left            =   -71160
         TabIndex        =   383
         Top             =   6120
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   47
         Left            =   -63120
         TabIndex        =   382
         Top             =   7560
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF00FF&
         Height          =   255
         Index           =   46
         Left            =   -63120
         TabIndex        =   381
         Top             =   5520
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF00FF&
         Height          =   255
         Index           =   45
         Left            =   -63120
         TabIndex        =   380
         Top             =   6000
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF00FF&
         Height          =   255
         Index           =   44
         Left            =   -63120
         TabIndex        =   379
         Top             =   6480
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF00FF&
         Height          =   255
         Index           =   43
         Left            =   -63120
         TabIndex        =   378
         Top             =   6840
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF00FF&
         Height          =   255
         Index           =   42
         Left            =   -65520
         TabIndex        =   377
         Top             =   4560
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF00FF&
         Height          =   255
         Index           =   41
         Left            =   -62880
         TabIndex        =   376
         Top             =   480
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF0000&
         Height          =   255
         Index           =   40
         Left            =   -66240
         TabIndex        =   375
         Top             =   7320
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF0000&
         Height          =   255
         Index           =   39
         Left            =   -66240
         TabIndex        =   374
         Top             =   6960
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   38
         Left            =   -66240
         TabIndex        =   373
         Top             =   6600
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   37
         Left            =   -66240
         TabIndex        =   372
         Top             =   6240
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   36
         Left            =   -70080
         TabIndex        =   371
         Top             =   3720
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   35
         Left            =   -70080
         TabIndex        =   370
         Top             =   1440
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   34
         Left            =   -70080
         TabIndex        =   369
         Top             =   720
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF0000&
         Height          =   255
         Index           =   33
         Left            =   -66240
         TabIndex        =   368
         Top             =   7320
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF0000&
         Height          =   255
         Index           =   32
         Left            =   -66240
         TabIndex        =   367
         Top             =   6960
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   31
         Left            =   -66240
         TabIndex        =   366
         Top             =   6600
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   30
         Left            =   -66240
         TabIndex        =   365
         Top             =   6240
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   29
         Left            =   -70080
         TabIndex        =   364
         Top             =   3720
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   28
         Left            =   -70080
         TabIndex        =   363
         Top             =   1440
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   27
         Left            =   -70080
         TabIndex        =   362
         Top             =   720
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF0000&
         Height          =   255
         Index           =   26
         Left            =   -66240
         TabIndex        =   361
         Top             =   7320
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF0000&
         Height          =   255
         Index           =   25
         Left            =   -66240
         TabIndex        =   360
         Top             =   6960
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   24
         Left            =   -66240
         TabIndex        =   359
         Top             =   6600
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   23
         Left            =   -66240
         TabIndex        =   358
         Top             =   6240
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   22
         Left            =   -70080
         TabIndex        =   357
         Top             =   3720
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   21
         Left            =   -70080
         TabIndex        =   356
         Top             =   1440
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   20
         Left            =   -70080
         TabIndex        =   355
         Top             =   720
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF0000&
         Height          =   255
         Index           =   19
         Left            =   -66240
         TabIndex        =   354
         Top             =   7320
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF0000&
         Height          =   255
         Index           =   18
         Left            =   -66240
         TabIndex        =   353
         Top             =   6960
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   17
         Left            =   -66240
         TabIndex        =   352
         Top             =   6600
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   16
         Left            =   -66240
         TabIndex        =   351
         Top             =   6240
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   15
         Left            =   -70080
         TabIndex        =   350
         Top             =   3720
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   14
         Left            =   -70080
         TabIndex        =   349
         Top             =   1440
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   13
         Left            =   -70080
         TabIndex        =   348
         Top             =   720
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF0000&
         Height          =   255
         Index           =   12
         Left            =   -66240
         TabIndex        =   347
         Top             =   7320
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF0000&
         Height          =   255
         Index           =   11
         Left            =   -66240
         TabIndex        =   346
         Top             =   6960
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   10
         Left            =   -66240
         TabIndex        =   345
         Top             =   6600
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   9
         Left            =   -66240
         TabIndex        =   344
         Top             =   6240
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   8
         Left            =   -70080
         TabIndex        =   343
         Top             =   3720
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   7
         Left            =   -70080
         TabIndex        =   342
         Top             =   1440
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   5
         Left            =   -70080
         TabIndex        =   341
         Top             =   720
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF0000&
         Height          =   255
         Index           =   6
         Left            =   8760
         TabIndex        =   340
         Top             =   7320
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   4
         Left            =   8760
         TabIndex        =   339
         Top             =   6600
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   3
         Left            =   8760
         TabIndex        =   338
         Top             =   6240
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   2
         Left            =   4920
         TabIndex        =   337
         Top             =   3720
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   1
         Left            =   4920
         TabIndex        =   336
         Top             =   1440
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   0
         Left            =   4920
         TabIndex        =   335
         Top             =   720
         Width           =   135
      End
      Begin VB.Label Label44 
         Caption         =   "Am vorbit la telefon de partea asta ... este doar HTML  ... "
         Height          =   255
         Left            =   -74880
         TabIndex        =   334
         Top             =   480
         Width           =   4455
      End
      Begin VB.Shape Shape8 
         BorderColor     =   &H00808080&
         Height          =   1335
         Left            =   -68760
         Top             =   5400
         Width           =   3855
      End
      Begin VB.Label Label43 
         Caption         =   "Marime font:"
         Height          =   255
         Left            =   -68640
         TabIndex        =   333
         Top             =   6240
         Width           =   1095
      End
      Begin VB.Label Label42 
         Caption         =   "Culoare font:"
         Height          =   255
         Left            =   -68640
         TabIndex        =   332
         Top             =   5880
         Width           =   1095
      End
      Begin VB.Label Label41 
         Caption         =   "Culoare font:"
         Height          =   255
         Left            =   -68640
         TabIndex        =   331
         Top             =   5520
         Width           =   1095
      End
      Begin VB.Shape Shape7 
         BorderColor     =   &H00808080&
         Height          =   495
         Left            =   -74760
         Top             =   7320
         Width           =   12015
      End
      Begin VB.Label Label40 
         Caption         =   "Culoare font:"
         Height          =   255
         Left            =   -74640
         TabIndex        =   325
         Top             =   5520
         Width           =   1095
      End
      Begin VB.Label Label39 
         Caption         =   "Culoare font:"
         Height          =   255
         Left            =   -74640
         TabIndex        =   324
         Top             =   5880
         Width           =   1095
      End
      Begin VB.Label Label26 
         Caption         =   "Marime font:"
         Height          =   255
         Left            =   -74640
         TabIndex        =   323
         Top             =   6240
         Width           =   1095
      End
      Begin VB.Shape Shape6 
         BorderColor     =   &H00808080&
         Height          =   1335
         Left            =   -74760
         Top             =   5400
         Width           =   3855
      End
      Begin VB.Label etete 
         Caption         =   "Nu este necesara completarea tuturor casutelor dar trebuie completata cel putin una !"
         Height          =   255
         Left            =   -72000
         TabIndex        =   319
         Top             =   4680
         Width           =   6135
      End
      Begin VB.Line Line24 
         BorderColor     =   &H00000000&
         X1              =   -69240
         X2              =   -69240
         Y1              =   360
         Y2              =   4200
      End
      Begin VB.Line Line23 
         BorderColor     =   &H00000000&
         Index           =   4
         X1              =   -74880
         X2              =   -62880
         Y1              =   360
         Y2              =   360
      End
      Begin VB.Line Line23 
         BorderColor     =   &H00000000&
         Index           =   3
         X1              =   -74880
         X2              =   -62760
         Y1              =   4200
         Y2              =   4200
      End
      Begin VB.Line Line23 
         BorderColor     =   &H00000000&
         Index           =   2
         X1              =   -74880
         X2              =   -62760
         Y1              =   3240
         Y2              =   3240
      End
      Begin VB.Line Line23 
         BorderColor     =   &H00000000&
         Index           =   1
         X1              =   -74880
         X2              =   -62760
         Y1              =   2280
         Y2              =   2280
      End
      Begin VB.Line Line23 
         BorderColor     =   &H00000000&
         Index           =   0
         X1              =   -74880
         X2              =   -62760
         Y1              =   1320
         Y2              =   1320
      End
      Begin VB.Label DriverInformatii3 
         Caption         =   "Calea spre aplicatia de instalare:"
         Height          =   255
         Index           =   7
         Left            =   -69120
         TabIndex        =   318
         Top             =   3840
         Width           =   2415
      End
      Begin VB.Label DriverInformatii2 
         Caption         =   "Explicatii scurte privind driver-ul:"
         Height          =   255
         Index           =   7
         Left            =   -69120
         TabIndex        =   317
         Top             =   3600
         Width           =   2415
      End
      Begin VB.Label DriverInformatii1 
         Caption         =   "Nume driver:"
         Height          =   255
         Index           =   7
         Left            =   -69120
         TabIndex        =   316
         Top             =   3360
         Width           =   1695
      End
      Begin VB.Label DriverInformatii3 
         Caption         =   "Calea spre aplicatia de instalare:"
         Height          =   255
         Index           =   6
         Left            =   -69120
         TabIndex        =   315
         Top             =   2880
         Width           =   2415
      End
      Begin VB.Label DriverInformatii2 
         Caption         =   "Explicatii scurte privind driver-ul:"
         Height          =   255
         Index           =   6
         Left            =   -69120
         TabIndex        =   314
         Top             =   2640
         Width           =   2415
      End
      Begin VB.Label DriverInformatii1 
         Caption         =   "Nume driver:"
         Height          =   255
         Index           =   6
         Left            =   -69120
         TabIndex        =   313
         Top             =   2400
         Width           =   1695
      End
      Begin VB.Label DriverInformatii3 
         Caption         =   "Calea spre aplicatia de instalare:"
         Height          =   255
         Index           =   5
         Left            =   -69120
         TabIndex        =   312
         Top             =   1920
         Width           =   2415
      End
      Begin VB.Label DriverInformatii2 
         Caption         =   "Explicatii scurte privind driver-ul:"
         Height          =   255
         Index           =   5
         Left            =   -69120
         TabIndex        =   311
         Top             =   1680
         Width           =   2415
      End
      Begin VB.Label DriverInformatii1 
         Caption         =   "Nume driver:"
         Height          =   255
         Index           =   5
         Left            =   -69120
         TabIndex        =   310
         Top             =   1440
         Width           =   1695
      End
      Begin VB.Label DriverInformatii3 
         Caption         =   "Calea spre aplicatia de instalare:"
         Height          =   255
         Index           =   4
         Left            =   -69120
         TabIndex        =   309
         Top             =   960
         Width           =   2415
      End
      Begin VB.Label DriverInformatii2 
         Caption         =   "Explicatii scurte privind driver-ul:"
         Height          =   255
         Index           =   4
         Left            =   -69120
         TabIndex        =   308
         Top             =   720
         Width           =   2415
      End
      Begin VB.Label DriverInformatii1 
         Caption         =   "Nume driver:"
         Height          =   255
         Index           =   4
         Left            =   -69120
         TabIndex        =   307
         Top             =   480
         Width           =   1695
      End
      Begin VB.Label DriverInformatii3 
         Caption         =   "Calea spre aplicatia de instalare:"
         Height          =   255
         Index           =   3
         Left            =   -74880
         TabIndex        =   306
         Top             =   3840
         Width           =   2415
      End
      Begin VB.Label DriverInformatii2 
         Caption         =   "Explicatii scurte privind driver-ul:"
         Height          =   255
         Index           =   3
         Left            =   -74880
         TabIndex        =   305
         Top             =   3600
         Width           =   2415
      End
      Begin VB.Label DriverInformatii1 
         Caption         =   "Nume driver:"
         Height          =   255
         Index           =   3
         Left            =   -74880
         TabIndex        =   304
         Top             =   3360
         Width           =   1695
      End
      Begin VB.Label DriverInformatii3 
         Caption         =   "Calea spre aplicatia de instalare:"
         Height          =   255
         Index           =   2
         Left            =   -74880
         TabIndex        =   303
         Top             =   2880
         Width           =   2415
      End
      Begin VB.Label DriverInformatii2 
         Caption         =   "Explicatii scurte privind driver-ul:"
         Height          =   255
         Index           =   2
         Left            =   -74880
         TabIndex        =   302
         Top             =   2640
         Width           =   2415
      End
      Begin VB.Label DriverInformatii1 
         Caption         =   "Nume driver:"
         Height          =   255
         Index           =   2
         Left            =   -74880
         TabIndex        =   301
         Top             =   2400
         Width           =   1695
      End
      Begin VB.Label DriverInformatii3 
         Caption         =   "Calea spre aplicatia de instalare:"
         Height          =   255
         Index           =   1
         Left            =   -74880
         TabIndex        =   300
         Top             =   1920
         Width           =   2415
      End
      Begin VB.Label DriverInformatii2 
         Caption         =   "Explicatii scurte privind driver-ul:"
         Height          =   255
         Index           =   1
         Left            =   -74880
         TabIndex        =   299
         Top             =   1680
         Width           =   2415
      End
      Begin VB.Label DriverInformatii1 
         Caption         =   "Nume driver:"
         Height          =   255
         Index           =   1
         Left            =   -74880
         TabIndex        =   298
         Top             =   1440
         Width           =   1695
      End
      Begin VB.Label DriverInformatii3 
         Caption         =   "Calea spre aplicatia de instalare:"
         Height          =   255
         Index           =   0
         Left            =   -74880
         TabIndex        =   297
         Top             =   960
         Width           =   2415
      End
      Begin VB.Label DriverInformatii2 
         Caption         =   "Explicatii scurte privind driver-ul:"
         Height          =   255
         Index           =   0
         Left            =   -74880
         TabIndex        =   296
         Top             =   720
         Width           =   2415
      End
      Begin VB.Label DriverInformatii1 
         Caption         =   "Nume driver:"
         Height          =   255
         Index           =   0
         Left            =   -74880
         TabIndex        =   295
         Top             =   480
         Width           =   1695
      End
      Begin VB.Line Line18 
         BorderColor     =   &H00000000&
         Index           =   5
         X1              =   -68160
         X2              =   -68160
         Y1              =   6000
         Y2              =   6240
      End
      Begin VB.Line Line18 
         BorderColor     =   &H00000000&
         Index           =   4
         X1              =   -69000
         X2              =   -69000
         Y1              =   6000
         Y2              =   6240
      End
      Begin VB.Line Line18 
         BorderColor     =   &H00000000&
         Index           =   3
         X1              =   -69480
         X2              =   -69480
         Y1              =   6000
         Y2              =   6240
      End
      Begin VB.Line Line18 
         BorderColor     =   &H00000000&
         Index           =   2
         X1              =   -70200
         X2              =   -70200
         Y1              =   6000
         Y2              =   6240
      End
      Begin VB.Line Line18 
         BorderColor     =   &H00000000&
         Index           =   1
         X1              =   -71160
         X2              =   -71160
         Y1              =   6000
         Y2              =   6240
      End
      Begin VB.Line Line18 
         BorderColor     =   &H00000000&
         Index           =   0
         X1              =   3480
         X2              =   3480
         Y1              =   6000
         Y2              =   6240
      End
      Begin VB.Shape Shape5 
         BorderColor     =   &H00808080&
         BorderWidth     =   3
         Height          =   735
         Left            =   -74880
         Top             =   7200
         Width           =   12015
      End
      Begin VB.Shape Shape4 
         BorderColor     =   &H00808080&
         Height          =   495
         Left            =   -74760
         Top             =   7560
         Width           =   12015
      End
      Begin VB.Shape Shape3 
         BackColor       =   &H00C0C0C0&
         BorderColor     =   &H00808080&
         Height          =   1335
         Left            =   -68640
         Top             =   6000
         Width           =   5175
      End
      Begin VB.Label Label38 
         Caption         =   $"Form1.frx":6FD4
         Height          =   1095
         Left            =   -68520
         TabIndex        =   261
         Top             =   6120
         Width           =   5055
      End
      Begin VB.Line Line22 
         BorderColor     =   &H00000000&
         X1              =   -70680
         X2              =   -70920
         Y1              =   6840
         Y2              =   6720
      End
      Begin VB.Line Line21 
         BorderColor     =   &H00000000&
         X1              =   -70680
         X2              =   -70920
         Y1              =   6600
         Y2              =   6720
      End
      Begin VB.Line Line20 
         BorderColor     =   &H00000000&
         X1              =   -70920
         X2              =   -69600
         Y1              =   6720
         Y2              =   6720
      End
      Begin VB.Line Line19 
         BorderColor     =   &H00000000&
         X1              =   -69600
         X2              =   -69600
         Y1              =   5880
         Y2              =   6720
      End
      Begin VB.Shape Shape2 
         BorderColor     =   &H00808080&
         Height          =   1335
         Left            =   -74760
         Top             =   6000
         Width           =   3855
      End
      Begin VB.Label Label37 
         Caption         =   "Marime font:"
         Height          =   255
         Left            =   -74640
         TabIndex        =   260
         Top             =   6840
         Width           =   1095
      End
      Begin VB.Label Label36 
         Caption         =   "Culoare font:"
         Height          =   255
         Left            =   -74640
         TabIndex        =   259
         Top             =   6480
         Width           =   1095
      End
      Begin VB.Label Label35 
         Caption         =   "Culoare font:"
         Height          =   255
         Left            =   -74640
         TabIndex        =   258
         Top             =   6120
         Width           =   1095
      End
      Begin VB.Label Label34 
         Alignment       =   2  'Center
         BackStyle       =   0  'Transparent
         Caption         =   "Caseta de reclama"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   24
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   615
         Left            =   -71280
         TabIndex        =   254
         Top             =   3840
         Width           =   4095
      End
      Begin VB.Label Label33 
         Caption         =   "Grosime bordura"
         Height          =   255
         Left            =   -65280
         TabIndex        =   251
         Top             =   6840
         Width           =   1215
      End
      Begin VB.Label Label32 
         Caption         =   "Fisierul imagine(GIF) pentru fundalul casutei de reclama:"
         Height          =   255
         Left            =   -74760
         TabIndex        =   249
         Top             =   7320
         Width           =   4335
      End
      Begin VB.Line Line17 
         BorderColor     =   &H00808080&
         BorderWidth     =   3
         X1              =   -74880
         X2              =   -62880
         Y1              =   3720
         Y2              =   3720
      End
      Begin VB.Shape Shape1 
         BorderColor     =   &H00808080&
         BorderWidth     =   3
         Height          =   1935
         Left            =   -65400
         Top             =   5280
         Width           =   2535
      End
      Begin VB.Label Label31 
         Caption         =   "Culoare"
         Height          =   255
         Left            =   -65280
         TabIndex        =   246
         Top             =   6480
         Width           =   1215
      End
      Begin VB.Line Line16 
         BorderColor     =   &H00000000&
         X1              =   -63720
         X2              =   -63960
         Y1              =   5160
         Y2              =   5280
      End
      Begin VB.Line Line15 
         BorderColor     =   &H00000000&
         X1              =   -64200
         X2              =   -63960
         Y1              =   5160
         Y2              =   5280
      End
      Begin VB.Line Line14 
         BorderColor     =   &H00808080&
         BorderWidth     =   3
         X1              =   -63960
         X2              =   -63960
         Y1              =   5280
         Y2              =   4440
      End
      Begin VB.Line Line13 
         BorderColor     =   &H00808080&
         BorderWidth     =   3
         X1              =   -73200
         X2              =   -63960
         Y1              =   4440
         Y2              =   4440
      End
      Begin VB.Label Label30 
         Caption         =   "Latime"
         Height          =   255
         Left            =   -65280
         TabIndex        =   244
         Top             =   6000
         Width           =   1215
      End
      Begin VB.Label Label29 
         Caption         =   "Inaltime"
         Height          =   255
         Left            =   -65280
         TabIndex        =   243
         Top             =   5520
         Width           =   1215
      End
      Begin VB.Label Label25 
         Caption         =   "Casuta pentru reclama:"
         Height          =   255
         Left            =   -74880
         TabIndex        =   240
         Top             =   4320
         Width           =   1815
      End
      Begin VB.Line Line12 
         BorderColor     =   &H00000000&
         X1              =   -74760
         X2              =   -62880
         Y1              =   1200
         Y2              =   1200
      End
      Begin VB.Label Label27 
         Alignment       =   2  'Center
         BackStyle       =   0  'Transparent
         Caption         =   "Compilare..."
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   13.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -69720
         TabIndex        =   213
         Top             =   360
         Width           =   1935
      End
      Begin VB.Line Line11 
         BorderColor     =   &H00000000&
         X1              =   -69720
         X2              =   -62760
         Y1              =   5400
         Y2              =   5400
      End
      Begin VB.Shape BorduraTemp 
         BackColor       =   &H000000FF&
         BorderColor     =   &H000000FF&
         Height          =   2895
         Index           =   5
         Left            =   -66000
         Top             =   5640
         Width           =   3255
      End
      Begin VB.Shape BorduraTemp 
         BackColor       =   &H000000FF&
         BorderColor     =   &H000000FF&
         Height          =   2895
         Index           =   4
         Left            =   -66000
         Top             =   5640
         Width           =   3255
      End
      Begin VB.Shape BorduraTemp 
         BackColor       =   &H000000FF&
         BorderColor     =   &H000000FF&
         Height          =   2895
         Index           =   3
         Left            =   -66000
         Top             =   5640
         Width           =   3255
      End
      Begin VB.Line Line1 
         BorderColor     =   &H00000000&
         Index           =   4
         X1              =   -69720
         X2              =   -62760
         Y1              =   5400
         Y2              =   5400
      End
      Begin VB.Shape BorduraTemp 
         BackColor       =   &H000000FF&
         BorderColor     =   &H000000FF&
         Height          =   2895
         Index           =   2
         Left            =   -66000
         Top             =   5640
         Width           =   3255
      End
      Begin VB.Line Line1 
         BorderColor     =   &H00000000&
         Index           =   3
         X1              =   -69720
         X2              =   -62760
         Y1              =   5400
         Y2              =   5400
      End
      Begin VB.Label Label28 
         Alignment       =   2  'Center
         Caption         =   "Permanente"
         BeginProperty Font 
            Name            =   "MS Serif"
            Size            =   24
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   615
         Index           =   5
         Left            =   -65880
         TabIndex        =   196
         Top             =   3960
         Width           =   3015
      End
      Begin VB.Label Label28 
         Alignment       =   2  'Center
         Caption         =   "Antivirus"
         BeginProperty Font 
            Name            =   "MS Serif"
            Size            =   24
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   615
         Index           =   4
         Left            =   -65880
         TabIndex        =   195
         Top             =   3960
         Width           =   3015
      End
      Begin VB.Label Label28 
         Alignment       =   2  'Center
         Caption         =   "Internet"
         BeginProperty Font 
            Name            =   "MS Serif"
            Size            =   24
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   615
         Index           =   3
         Left            =   -65880
         TabIndex        =   194
         Top             =   3960
         Width           =   3015
      End
      Begin VB.Label Label28 
         Alignment       =   2  'Center
         Caption         =   "Jocuri"
         BeginProperty Font 
            Name            =   "MS Serif"
            Size            =   24
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   615
         Index           =   2
         Left            =   -65880
         TabIndex        =   193
         Top             =   3960
         Width           =   3015
      End
      Begin VB.Label Label28 
         Alignment       =   2  'Center
         Caption         =   "Multimedia"
         BeginProperty Font 
            Name            =   "MS Serif"
            Size            =   24
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   615
         Index           =   1
         Left            =   -65880
         TabIndex        =   192
         Top             =   3960
         Width           =   3015
      End
      Begin VB.Shape BorduraGata 
         BorderColor     =   &H00000000&
         Height          =   2895
         Index           =   5
         Left            =   -66000
         Top             =   480
         Width           =   3255
      End
      Begin VB.Shape BorduraGata 
         BorderColor     =   &H00000000&
         Height          =   2895
         Index           =   4
         Left            =   -66000
         Top             =   480
         Width           =   3255
      End
      Begin VB.Shape BorduraGata 
         BorderColor     =   &H00000000&
         Height          =   2895
         Index           =   3
         Left            =   -66000
         Top             =   480
         Width           =   3255
      End
      Begin VB.Shape BorduraGata 
         BorderColor     =   &H00000000&
         Height          =   2895
         Index           =   2
         Left            =   -66000
         Top             =   480
         Width           =   3255
      End
      Begin VB.Shape BorduraGata 
         BorderColor     =   &H00000000&
         Height          =   2895
         Index           =   1
         Left            =   -66000
         Top             =   480
         Width           =   3255
      End
      Begin VB.Shape BorduraGata 
         BorderColor     =   &H00000000&
         Height          =   2895
         Index           =   0
         Left            =   9000
         Top             =   480
         Width           =   3255
      End
      Begin VB.Line Line1 
         BorderColor     =   &H00000000&
         Index           =   1
         X1              =   5280
         X2              =   12240
         Y1              =   5400
         Y2              =   5400
      End
      Begin VB.Image Pro_imagine 
         Height          =   2895
         Index           =   5
         Left            =   -66000
         Stretch         =   -1  'True
         Top             =   5640
         Width           =   3255
      End
      Begin VB.Image Pro_imagine 
         Height          =   2895
         Index           =   4
         Left            =   -66000
         Stretch         =   -1  'True
         Top             =   5640
         Width           =   3255
      End
      Begin VB.Image Pro_imagine 
         Height          =   2895
         Index           =   3
         Left            =   -66000
         Stretch         =   -1  'True
         Top             =   5640
         Width           =   3255
      End
      Begin VB.Image Pro_imagine 
         Height          =   2895
         Index           =   2
         Left            =   -66000
         Stretch         =   -1  'True
         Top             =   5640
         Width           =   3255
      End
      Begin VB.Image Pro_imagine 
         Height          =   2895
         Index           =   1
         Left            =   -66000
         Stretch         =   -1  'True
         Top             =   5640
         Width           =   3255
      End
      Begin VB.Image Pro_imagine 
         Height          =   2895
         Index           =   0
         Left            =   9000
         Stretch         =   -1  'True
         Top             =   5640
         Width           =   3255
      End
      Begin VB.Image Imagine_Meniu 
         Height          =   2895
         Index           =   5
         Left            =   -66000
         Stretch         =   -1  'True
         Top             =   480
         Width           =   3255
      End
      Begin VB.Image Imagine_Meniu 
         Height          =   2895
         Index           =   4
         Left            =   -66000
         Stretch         =   -1  'True
         Top             =   480
         Width           =   3255
      End
      Begin VB.Image Imagine_Meniu 
         Height          =   2895
         Index           =   3
         Left            =   -66000
         Stretch         =   -1  'True
         Top             =   480
         Width           =   3255
      End
      Begin VB.Image Imagine_Meniu 
         Height          =   2895
         Index           =   2
         Left            =   -66000
         Stretch         =   -1  'True
         Top             =   480
         Width           =   3255
      End
      Begin VB.Image Imagine_Meniu 
         Height          =   2895
         Index           =   1
         Left            =   -66000
         Stretch         =   -1  'True
         Top             =   480
         Width           =   3255
      End
      Begin VB.Image Imagine_Meniu 
         Height          =   2895
         Index           =   0
         Left            =   9000
         Stretch         =   -1  'True
         Top             =   480
         Width           =   3255
      End
      Begin VB.Line Line7 
         BorderColor     =   &H00000000&
         X1              =   -69720
         X2              =   -62760
         Y1              =   5400
         Y2              =   5400
      End
      Begin VB.Label Label24 
         Caption         =   "Informatii ce se vor citi la apasarea butonului ""Citeste-ma"""
         Height          =   255
         Left            =   -74640
         TabIndex        =   191
         Top             =   3480
         Width           =   4215
      End
      Begin VB.Label Label23 
         Caption         =   "Expicatii despre programul prezentat"
         Height          =   255
         Left            =   -74640
         TabIndex        =   190
         Top             =   1200
         Width           =   2775
      End
      Begin VB.Label Label22 
         Caption         =   "Titlul programului prezentat:"
         Height          =   255
         Left            =   -74640
         TabIndex        =   189
         Top             =   720
         Width           =   2055
      End
      Begin VB.Label Label21 
         Alignment       =   2  'Center
         Caption         =   "Programele introduse deja."
         Height          =   255
         Left            =   -69360
         TabIndex        =   188
         Top             =   480
         Width           =   3015
      End
      Begin VB.Line Line6 
         BorderColor     =   &H00000000&
         X1              =   -69840
         X2              =   -69840
         Y1              =   600
         Y2              =   5280
      End
      Begin VB.Label ListaMarePR 
         Caption         =   "18 nimic"
         Height          =   255
         Index           =   17
         Left            =   -69600
         TabIndex        =   187
         Top             =   4920
         Width           =   3375
      End
      Begin VB.Label ListaMarePR 
         Caption         =   "17 nimic"
         Height          =   255
         Index           =   16
         Left            =   -69600
         TabIndex        =   186
         Top             =   4680
         Width           =   3375
      End
      Begin VB.Label ListaMarePR 
         Caption         =   "16 nimic"
         Height          =   255
         Index           =   15
         Left            =   -69600
         TabIndex        =   185
         Top             =   4440
         Width           =   3375
      End
      Begin VB.Label ListaMarePR 
         Caption         =   "15 nimic"
         Height          =   255
         Index           =   14
         Left            =   -69600
         TabIndex        =   184
         Top             =   4200
         Width           =   3375
      End
      Begin VB.Label ListaMarePR 
         Caption         =   "14 nimic"
         Height          =   255
         Index           =   13
         Left            =   -69600
         TabIndex        =   183
         Top             =   3960
         Width           =   3375
      End
      Begin VB.Label ListaMarePR 
         Caption         =   "13 nimic"
         Height          =   255
         Index           =   12
         Left            =   -69600
         TabIndex        =   182
         Top             =   3720
         Width           =   3375
      End
      Begin VB.Label ListaMarePR 
         Caption         =   "12 nimic"
         Height          =   255
         Index           =   11
         Left            =   -69600
         TabIndex        =   181
         Top             =   3480
         Width           =   3375
      End
      Begin VB.Label ListaMarePR 
         Caption         =   "11 nimic"
         Height          =   255
         Index           =   10
         Left            =   -69600
         TabIndex        =   180
         Top             =   3240
         Width           =   3375
      End
      Begin VB.Label ListaMarePR 
         Caption         =   "10 nimic"
         Height          =   255
         Index           =   9
         Left            =   -69600
         TabIndex        =   179
         Top             =   3000
         Width           =   3375
      End
      Begin VB.Label ListaMarePR 
         Caption         =   "9 nimic"
         Height          =   255
         Index           =   8
         Left            =   -69600
         TabIndex        =   178
         Top             =   2760
         Width           =   3375
      End
      Begin VB.Label ListaMarePR 
         Caption         =   "8 nimic"
         Height          =   255
         Index           =   7
         Left            =   -69600
         TabIndex        =   177
         Top             =   2520
         Width           =   3375
      End
      Begin VB.Label ListaMarePR 
         Caption         =   "7 nimic"
         Height          =   255
         Index           =   6
         Left            =   -69600
         TabIndex        =   176
         Top             =   2280
         Width           =   3375
      End
      Begin VB.Label ListaMarePR 
         Caption         =   "6 nimic"
         Height          =   255
         Index           =   5
         Left            =   -69600
         TabIndex        =   175
         Top             =   2040
         Width           =   3375
      End
      Begin VB.Label ListaMarePR 
         Caption         =   "5 nimic"
         Height          =   255
         Index           =   4
         Left            =   -69600
         TabIndex        =   174
         Top             =   1800
         Width           =   3375
      End
      Begin VB.Label ListaMarePR 
         Caption         =   "4 nimic"
         Height          =   255
         Index           =   3
         Left            =   -69600
         TabIndex        =   173
         Top             =   1560
         Width           =   3375
      End
      Begin VB.Label ListaMarePR 
         Caption         =   "3 nimic"
         Height          =   255
         Index           =   2
         Left            =   -69600
         TabIndex        =   172
         Top             =   1320
         Width           =   3375
      End
      Begin VB.Label ListaMarePR 
         Caption         =   "2 nimic"
         Height          =   255
         Index           =   1
         Left            =   -69600
         TabIndex        =   171
         Top             =   1080
         Width           =   3375
      End
      Begin VB.Label ListaMarePR 
         Caption         =   "1 nimic"
         Height          =   255
         Index           =   0
         Left            =   -69600
         TabIndex        =   170
         Top             =   840
         Width           =   3375
      End
      Begin VB.Label Label20 
         Caption         =   "Informatii ce se vor citi la apasarea butonului ""Citeste-ma"""
         Height          =   255
         Left            =   -74640
         TabIndex        =   169
         Top             =   3480
         Width           =   4215
      End
      Begin VB.Label Label19 
         Caption         =   "Expicatii despre programul prezentat"
         Height          =   255
         Left            =   -74640
         TabIndex        =   168
         Top             =   1200
         Width           =   2775
      End
      Begin VB.Label Label18 
         Caption         =   "Titlul programului prezentat:"
         Height          =   255
         Left            =   -74640
         TabIndex        =   167
         Top             =   720
         Width           =   2055
      End
      Begin VB.Label Label17 
         Alignment       =   2  'Center
         Caption         =   "Programele introduse deja."
         Height          =   255
         Left            =   -69360
         TabIndex        =   166
         Top             =   480
         Width           =   3015
      End
      Begin VB.Line Line5 
         BorderColor     =   &H00000000&
         X1              =   -69840
         X2              =   -69840
         Y1              =   600
         Y2              =   5280
      End
      Begin VB.Label ListaMareAV 
         Caption         =   "18 nimic"
         Height          =   255
         Index           =   17
         Left            =   -69600
         TabIndex        =   165
         Top             =   4920
         Width           =   3375
      End
      Begin VB.Label ListaMareAV 
         Caption         =   "17 nimic"
         Height          =   255
         Index           =   16
         Left            =   -69600
         TabIndex        =   164
         Top             =   4680
         Width           =   3375
      End
      Begin VB.Label ListaMareAV 
         Caption         =   "16 nimic"
         Height          =   255
         Index           =   15
         Left            =   -69600
         TabIndex        =   163
         Top             =   4440
         Width           =   3375
      End
      Begin VB.Label ListaMareAV 
         Caption         =   "15 nimic"
         Height          =   255
         Index           =   14
         Left            =   -69600
         TabIndex        =   162
         Top             =   4200
         Width           =   3375
      End
      Begin VB.Label ListaMareAV 
         Caption         =   "14 nimic"
         Height          =   255
         Index           =   13
         Left            =   -69600
         TabIndex        =   161
         Top             =   3960
         Width           =   3375
      End
      Begin VB.Label ListaMareAV 
         Caption         =   "13 nimic"
         Height          =   255
         Index           =   12
         Left            =   -69600
         TabIndex        =   160
         Top             =   3720
         Width           =   3375
      End
      Begin VB.Label ListaMareAV 
         Caption         =   "12 nimic"
         Height          =   255
         Index           =   11
         Left            =   -69600
         TabIndex        =   159
         Top             =   3480
         Width           =   3375
      End
      Begin VB.Label ListaMareAV 
         Caption         =   "11 nimic"
         Height          =   255
         Index           =   10
         Left            =   -69600
         TabIndex        =   158
         Top             =   3240
         Width           =   3375
      End
      Begin VB.Label ListaMareAV 
         Caption         =   "10 nimic"
         Height          =   255
         Index           =   9
         Left            =   -69600
         TabIndex        =   157
         Top             =   3000
         Width           =   3375
      End
      Begin VB.Label ListaMareAV 
         Caption         =   "9 nimic"
         Height          =   255
         Index           =   8
         Left            =   -69600
         TabIndex        =   156
         Top             =   2760
         Width           =   3375
      End
      Begin VB.Label ListaMareAV 
         Caption         =   "8 nimic"
         Height          =   255
         Index           =   7
         Left            =   -69600
         TabIndex        =   155
         Top             =   2520
         Width           =   3375
      End
      Begin VB.Label ListaMareAV 
         Caption         =   "7 nimic"
         Height          =   255
         Index           =   6
         Left            =   -69600
         TabIndex        =   154
         Top             =   2280
         Width           =   3375
      End
      Begin VB.Label ListaMareAV 
         Caption         =   "6 nimic"
         Height          =   255
         Index           =   5
         Left            =   -69600
         TabIndex        =   153
         Top             =   2040
         Width           =   3375
      End
      Begin VB.Label ListaMareAV 
         Caption         =   "5 nimic"
         Height          =   255
         Index           =   4
         Left            =   -69600
         TabIndex        =   152
         Top             =   1800
         Width           =   3375
      End
      Begin VB.Label ListaMareAV 
         Caption         =   "4 nimic"
         Height          =   255
         Index           =   3
         Left            =   -69600
         TabIndex        =   151
         Top             =   1560
         Width           =   3375
      End
      Begin VB.Label ListaMareAV 
         Caption         =   "3 nimic"
         Height          =   255
         Index           =   2
         Left            =   -69600
         TabIndex        =   150
         Top             =   1320
         Width           =   3375
      End
      Begin VB.Label ListaMareAV 
         Caption         =   "2 nimic"
         Height          =   255
         Index           =   1
         Left            =   -69600
         TabIndex        =   149
         Top             =   1080
         Width           =   3375
      End
      Begin VB.Label ListaMareAV 
         Caption         =   "1 nimic"
         Height          =   255
         Index           =   0
         Left            =   -69600
         TabIndex        =   148
         Top             =   840
         Width           =   3375
      End
      Begin VB.Label Label16 
         Caption         =   "Informatii ce se vor citi la apasarea butonului ""Citeste-ma"""
         Height          =   255
         Left            =   -74640
         TabIndex        =   147
         Top             =   3480
         Width           =   4215
      End
      Begin VB.Label Label15 
         Caption         =   "Expicatii despre programul prezentat"
         Height          =   255
         Left            =   -74640
         TabIndex        =   146
         Top             =   1200
         Width           =   2775
      End
      Begin VB.Label Label14 
         Caption         =   "Titlul programului prezentat:"
         Height          =   255
         Left            =   -74640
         TabIndex        =   145
         Top             =   720
         Width           =   2055
      End
      Begin VB.Label Label13 
         Alignment       =   2  'Center
         Caption         =   "Programele introduse deja."
         Height          =   255
         Left            =   -69360
         TabIndex        =   144
         Top             =   480
         Width           =   3015
      End
      Begin VB.Line Line4 
         BorderColor     =   &H00000000&
         X1              =   -69840
         X2              =   -69840
         Y1              =   600
         Y2              =   5280
      End
      Begin VB.Label ListaMareIN 
         Caption         =   "18 nimic"
         Height          =   255
         Index           =   17
         Left            =   -69600
         TabIndex        =   143
         Top             =   4920
         Width           =   3375
      End
      Begin VB.Label ListaMareIN 
         Caption         =   "17 nimic"
         Height          =   255
         Index           =   16
         Left            =   -69600
         TabIndex        =   142
         Top             =   4680
         Width           =   3375
      End
      Begin VB.Label ListaMareIN 
         Caption         =   "16 nimic"
         Height          =   255
         Index           =   15
         Left            =   -69600
         TabIndex        =   141
         Top             =   4440
         Width           =   3375
      End
      Begin VB.Label ListaMareIN 
         Caption         =   "15 nimic"
         Height          =   255
         Index           =   14
         Left            =   -69600
         TabIndex        =   140
         Top             =   4200
         Width           =   3375
      End
      Begin VB.Label ListaMareIN 
         Caption         =   "14 nimic"
         Height          =   255
         Index           =   13
         Left            =   -69600
         TabIndex        =   139
         Top             =   3960
         Width           =   3375
      End
      Begin VB.Label ListaMareIN 
         Caption         =   "13 nimic"
         Height          =   255
         Index           =   12
         Left            =   -69600
         TabIndex        =   138
         Top             =   3720
         Width           =   3375
      End
      Begin VB.Label ListaMareIN 
         Caption         =   "12 nimic"
         Height          =   255
         Index           =   11
         Left            =   -69600
         TabIndex        =   137
         Top             =   3480
         Width           =   3375
      End
      Begin VB.Label ListaMareIN 
         Caption         =   "11 nimic"
         Height          =   255
         Index           =   10
         Left            =   -69600
         TabIndex        =   136
         Top             =   3240
         Width           =   3375
      End
      Begin VB.Label ListaMareIN 
         Caption         =   "10 nimic"
         Height          =   255
         Index           =   9
         Left            =   -69600
         TabIndex        =   135
         Top             =   3000
         Width           =   3375
      End
      Begin VB.Label ListaMareIN 
         Caption         =   "9 nimic"
         Height          =   255
         Index           =   8
         Left            =   -69600
         TabIndex        =   134
         Top             =   2760
         Width           =   3375
      End
      Begin VB.Label ListaMareIN 
         Caption         =   "8 nimic"
         Height          =   255
         Index           =   7
         Left            =   -69600
         TabIndex        =   133
         Top             =   2520
         Width           =   3375
      End
      Begin VB.Label ListaMareIN 
         Caption         =   "7 nimic"
         Height          =   255
         Index           =   6
         Left            =   -69600
         TabIndex        =   132
         Top             =   2280
         Width           =   3375
      End
      Begin VB.Label ListaMareIN 
         Caption         =   "6 nimic"
         Height          =   255
         Index           =   5
         Left            =   -69600
         TabIndex        =   131
         Top             =   2040
         Width           =   3375
      End
      Begin VB.Label ListaMareIN 
         Caption         =   "5 nimic"
         Height          =   255
         Index           =   4
         Left            =   -69600
         TabIndex        =   130
         Top             =   1800
         Width           =   3375
      End
      Begin VB.Label ListaMareIN 
         Caption         =   "4 nimic"
         Height          =   255
         Index           =   3
         Left            =   -69600
         TabIndex        =   129
         Top             =   1560
         Width           =   3375
      End
      Begin VB.Label ListaMareIN 
         Caption         =   "3 nimic"
         Height          =   255
         Index           =   2
         Left            =   -69600
         TabIndex        =   128
         Top             =   1320
         Width           =   3375
      End
      Begin VB.Label ListaMareIN 
         Caption         =   "2 nimic"
         Height          =   255
         Index           =   1
         Left            =   -69600
         TabIndex        =   127
         Top             =   1080
         Width           =   3375
      End
      Begin VB.Label ListaMareIN 
         Caption         =   "1 nimic"
         Height          =   255
         Index           =   0
         Left            =   -69600
         TabIndex        =   126
         Top             =   840
         Width           =   3375
      End
      Begin VB.Label Label12 
         Caption         =   "Informatii ce se vor citi la apasarea butonului ""Citeste-ma"""
         Height          =   255
         Left            =   -74640
         TabIndex        =   125
         Top             =   3480
         Width           =   4215
      End
      Begin VB.Label Label11 
         Caption         =   "Expicatii despre programul prezentat"
         Height          =   255
         Left            =   -74640
         TabIndex        =   124
         Top             =   1200
         Width           =   2775
      End
      Begin VB.Label Label10 
         Caption         =   "Titlul programului prezentat:"
         Height          =   255
         Left            =   -74640
         TabIndex        =   123
         Top             =   720
         Width           =   2055
      End
      Begin VB.Label Label9 
         Alignment       =   2  'Center
         Caption         =   "Programele introduse deja."
         Height          =   255
         Left            =   -69360
         TabIndex        =   122
         Top             =   480
         Width           =   3015
      End
      Begin VB.Line Line3 
         BorderColor     =   &H00000000&
         X1              =   -69840
         X2              =   -69840
         Y1              =   600
         Y2              =   5280
      End
      Begin VB.Label ListaMareJC 
         Caption         =   "18 nimic"
         Height          =   255
         Index           =   17
         Left            =   -69600
         TabIndex        =   121
         Top             =   4920
         Width           =   3375
      End
      Begin VB.Label ListaMareJC 
         Caption         =   "17 nimic"
         Height          =   255
         Index           =   16
         Left            =   -69600
         TabIndex        =   120
         Top             =   4680
         Width           =   3375
      End
      Begin VB.Label ListaMareJC 
         Caption         =   "16 nimic"
         Height          =   255
         Index           =   15
         Left            =   -69600
         TabIndex        =   119
         Top             =   4440
         Width           =   3375
      End
      Begin VB.Label ListaMareJC 
         Caption         =   "15 nimic"
         Height          =   255
         Index           =   14
         Left            =   -69600
         TabIndex        =   118
         Top             =   4200
         Width           =   3375
      End
      Begin VB.Label ListaMareJC 
         Caption         =   "14 nimic"
         Height          =   255
         Index           =   13
         Left            =   -69600
         TabIndex        =   117
         Top             =   3960
         Width           =   3375
      End
      Begin VB.Label ListaMareJC 
         Caption         =   "13 nimic"
         Height          =   255
         Index           =   12
         Left            =   -69600
         TabIndex        =   116
         Top             =   3720
         Width           =   3375
      End
      Begin VB.Label ListaMareJC 
         Caption         =   "12 nimic"
         Height          =   255
         Index           =   11
         Left            =   -69600
         TabIndex        =   115
         Top             =   3480
         Width           =   3375
      End
      Begin VB.Label ListaMareJC 
         Caption         =   "11 nimic"
         Height          =   255
         Index           =   10
         Left            =   -69600
         TabIndex        =   114
         Top             =   3240
         Width           =   3375
      End
      Begin VB.Label ListaMareJC 
         Caption         =   "10 nimic"
         Height          =   255
         Index           =   9
         Left            =   -69600
         TabIndex        =   113
         Top             =   3000
         Width           =   3375
      End
      Begin VB.Label ListaMareJC 
         Caption         =   "9 nimic"
         Height          =   255
         Index           =   8
         Left            =   -69600
         TabIndex        =   112
         Top             =   2760
         Width           =   3375
      End
      Begin VB.Label ListaMareJC 
         Caption         =   "8 nimic"
         Height          =   255
         Index           =   7
         Left            =   -69600
         TabIndex        =   111
         Top             =   2520
         Width           =   3375
      End
      Begin VB.Label ListaMareJC 
         Caption         =   "7 nimic"
         Height          =   255
         Index           =   6
         Left            =   -69600
         TabIndex        =   110
         Top             =   2280
         Width           =   3375
      End
      Begin VB.Label ListaMareJC 
         Caption         =   "6 nimic"
         Height          =   255
         Index           =   5
         Left            =   -69600
         TabIndex        =   109
         Top             =   2040
         Width           =   3375
      End
      Begin VB.Label ListaMareJC 
         Caption         =   "5 nimic"
         Height          =   255
         Index           =   4
         Left            =   -69600
         TabIndex        =   108
         Top             =   1800
         Width           =   3375
      End
      Begin VB.Label ListaMareJC 
         Caption         =   "4 nimic"
         Height          =   255
         Index           =   3
         Left            =   -69600
         TabIndex        =   107
         Top             =   1560
         Width           =   3375
      End
      Begin VB.Label ListaMareJC 
         Caption         =   "3 nimic"
         Height          =   255
         Index           =   2
         Left            =   -69600
         TabIndex        =   106
         Top             =   1320
         Width           =   3375
      End
      Begin VB.Label ListaMareJC 
         Caption         =   "2 nimic"
         Height          =   255
         Index           =   1
         Left            =   -69600
         TabIndex        =   105
         Top             =   1080
         Width           =   3375
      End
      Begin VB.Label ListaMareJC 
         Caption         =   "1 nimic"
         Height          =   255
         Index           =   0
         Left            =   -69600
         TabIndex        =   104
         Top             =   840
         Width           =   3375
      End
      Begin VB.Label ListaMareMM 
         Caption         =   "1 nimic"
         Height          =   255
         Index           =   0
         Left            =   -69600
         TabIndex        =   103
         Top             =   840
         Width           =   3375
      End
      Begin VB.Label ListaMareMM 
         Caption         =   "2 nimic"
         Height          =   255
         Index           =   1
         Left            =   -69600
         TabIndex        =   102
         Top             =   1080
         Width           =   3375
      End
      Begin VB.Label ListaMareMM 
         Caption         =   "3 nimic"
         Height          =   255
         Index           =   2
         Left            =   -69600
         TabIndex        =   101
         Top             =   1320
         Width           =   3375
      End
      Begin VB.Label ListaMareMM 
         Caption         =   "4 nimic"
         Height          =   255
         Index           =   3
         Left            =   -69600
         TabIndex        =   100
         Top             =   1560
         Width           =   3375
      End
      Begin VB.Label ListaMareMM 
         Caption         =   "5 nimic"
         Height          =   255
         Index           =   4
         Left            =   -69600
         TabIndex        =   99
         Top             =   1800
         Width           =   3375
      End
      Begin VB.Label ListaMareMM 
         Caption         =   "6 nimic"
         Height          =   255
         Index           =   5
         Left            =   -69600
         TabIndex        =   98
         Top             =   2040
         Width           =   3375
      End
      Begin VB.Label ListaMareMM 
         Caption         =   "7 nimic"
         Height          =   255
         Index           =   6
         Left            =   -69600
         TabIndex        =   97
         Top             =   2280
         Width           =   3375
      End
      Begin VB.Label ListaMareMM 
         Caption         =   "8 nimic"
         Height          =   255
         Index           =   7
         Left            =   -69600
         TabIndex        =   96
         Top             =   2520
         Width           =   3375
      End
      Begin VB.Label ListaMareMM 
         Caption         =   "9 nimic"
         Height          =   255
         Index           =   8
         Left            =   -69600
         TabIndex        =   95
         Top             =   2760
         Width           =   3375
      End
      Begin VB.Label ListaMareMM 
         Caption         =   "10 nimic"
         Height          =   255
         Index           =   9
         Left            =   -69600
         TabIndex        =   94
         Top             =   3000
         Width           =   3375
      End
      Begin VB.Label ListaMareMM 
         Caption         =   "11 nimic"
         Height          =   255
         Index           =   10
         Left            =   -69600
         TabIndex        =   93
         Top             =   3240
         Width           =   3375
      End
      Begin VB.Label ListaMareMM 
         Caption         =   "12 nimic"
         Height          =   255
         Index           =   11
         Left            =   -69600
         TabIndex        =   92
         Top             =   3480
         Width           =   3375
      End
      Begin VB.Label ListaMareMM 
         Caption         =   "13 nimic"
         Height          =   255
         Index           =   12
         Left            =   -69600
         TabIndex        =   91
         Top             =   3720
         Width           =   3375
      End
      Begin VB.Label ListaMareMM 
         Caption         =   "14 nimic"
         Height          =   255
         Index           =   13
         Left            =   -69600
         TabIndex        =   90
         Top             =   3960
         Width           =   3375
      End
      Begin VB.Label ListaMareMM 
         Caption         =   "15 nimic"
         Height          =   255
         Index           =   14
         Left            =   -69600
         TabIndex        =   89
         Top             =   4200
         Width           =   3375
      End
      Begin VB.Label ListaMareMM 
         Caption         =   "16 nimic"
         Height          =   255
         Index           =   15
         Left            =   -69600
         TabIndex        =   88
         Top             =   4440
         Width           =   3375
      End
      Begin VB.Label ListaMareMM 
         Caption         =   "17 nimic"
         Height          =   255
         Index           =   16
         Left            =   -69600
         TabIndex        =   87
         Top             =   4680
         Width           =   3375
      End
      Begin VB.Label ListaMareMM 
         Caption         =   "18 nimic"
         Height          =   255
         Index           =   17
         Left            =   -69600
         TabIndex        =   86
         Top             =   4920
         Width           =   3375
      End
      Begin VB.Line Line2 
         BorderColor     =   &H00000000&
         X1              =   -69840
         X2              =   -69840
         Y1              =   600
         Y2              =   5280
      End
      Begin VB.Label Label8 
         Alignment       =   2  'Center
         Caption         =   "Programele introduse deja."
         Height          =   255
         Left            =   -69360
         TabIndex        =   85
         Top             =   480
         Width           =   3015
      End
      Begin VB.Label Label7 
         Caption         =   "Titlul programului prezentat:"
         Height          =   255
         Left            =   -74640
         TabIndex        =   84
         Top             =   720
         Width           =   2055
      End
      Begin VB.Label Label6 
         Caption         =   "Expicatii despre programul prezentat"
         Height          =   255
         Left            =   -74640
         TabIndex        =   83
         Top             =   1200
         Width           =   2775
      End
      Begin VB.Label Label5 
         Caption         =   "Informatii ce se vor citi la apasarea butonului ""Citeste-ma"""
         Height          =   255
         Left            =   -74640
         TabIndex        =   82
         Top             =   3480
         Width           =   4215
      End
      Begin VB.Label Label4 
         Alignment       =   2  'Center
         Caption         =   "Programele introduse deja."
         Height          =   255
         Left            =   5640
         TabIndex        =   81
         Top             =   480
         Width           =   3015
      End
      Begin VB.Line Line1 
         BorderColor     =   &H00000000&
         Index           =   0
         X1              =   5160
         X2              =   5160
         Y1              =   480
         Y2              =   5280
      End
      Begin VB.Label Label3 
         Caption         =   "Informatii ce se vor citi la apasarea butonului ""Citeste-ma"":"
         Height          =   255
         Left            =   360
         TabIndex        =   80
         Top             =   3480
         Width           =   4215
      End
      Begin VB.Label ListaMare 
         Caption         =   "18 nimic"
         Height          =   255
         Index           =   17
         Left            =   5400
         TabIndex        =   79
         Top             =   4920
         Width           =   3375
      End
      Begin VB.Label ListaMare 
         Caption         =   "17 nimic"
         Height          =   255
         Index           =   16
         Left            =   5400
         TabIndex        =   78
         Top             =   4680
         Width           =   3375
      End
      Begin VB.Label ListaMare 
         Caption         =   "16 nimic"
         Height          =   255
         Index           =   15
         Left            =   5400
         TabIndex        =   77
         Top             =   4440
         Width           =   3375
      End
      Begin VB.Label ListaMare 
         Caption         =   "15 nimic"
         Height          =   255
         Index           =   14
         Left            =   5400
         TabIndex        =   76
         Top             =   4200
         Width           =   3375
      End
      Begin VB.Label ListaMare 
         Caption         =   "14 nimic"
         Height          =   255
         Index           =   13
         Left            =   5400
         TabIndex        =   75
         Top             =   3960
         Width           =   3375
      End
      Begin VB.Label ListaMare 
         Caption         =   "13 nimic"
         Height          =   255
         Index           =   12
         Left            =   5400
         TabIndex        =   74
         Top             =   3720
         Width           =   3375
      End
      Begin VB.Label ListaMare 
         Caption         =   "12 nimic"
         Height          =   255
         Index           =   11
         Left            =   5400
         TabIndex        =   73
         Top             =   3480
         Width           =   3375
      End
      Begin VB.Label ListaMare 
         Caption         =   "11 nimic"
         Height          =   255
         Index           =   10
         Left            =   5400
         TabIndex        =   72
         Top             =   3240
         Width           =   3375
      End
      Begin VB.Label ListaMare 
         Caption         =   "10 nimic"
         Height          =   255
         Index           =   9
         Left            =   5400
         TabIndex        =   71
         Top             =   3000
         Width           =   3375
      End
      Begin VB.Label ListaMare 
         Caption         =   "9 nimic"
         Height          =   255
         Index           =   8
         Left            =   5400
         TabIndex        =   70
         Top             =   2760
         Width           =   3375
      End
      Begin VB.Label ListaMare 
         Caption         =   "8 nimic"
         Height          =   255
         Index           =   7
         Left            =   5400
         TabIndex        =   69
         Top             =   2520
         Width           =   3375
      End
      Begin VB.Label ListaMare 
         Caption         =   "7 nimic"
         Height          =   255
         Index           =   6
         Left            =   5400
         TabIndex        =   68
         Top             =   2280
         Width           =   3375
      End
      Begin VB.Label ListaMare 
         Caption         =   "6 nimic"
         Height          =   255
         Index           =   5
         Left            =   5400
         TabIndex        =   67
         Top             =   2040
         Width           =   3375
      End
      Begin VB.Label ListaMare 
         Caption         =   "5 nimic"
         Height          =   255
         Index           =   4
         Left            =   5400
         TabIndex        =   66
         Top             =   1800
         Width           =   3375
      End
      Begin VB.Label ListaMare 
         Caption         =   "4 nimic"
         Height          =   255
         Index           =   3
         Left            =   5400
         TabIndex        =   65
         Top             =   1560
         Width           =   3375
      End
      Begin VB.Label ListaMare 
         Caption         =   "3 nimic"
         Height          =   255
         Index           =   2
         Left            =   5400
         TabIndex        =   64
         Top             =   1320
         Width           =   3375
      End
      Begin VB.Label ListaMare 
         Caption         =   "2 nimic"
         Height          =   255
         Index           =   1
         Left            =   5400
         TabIndex        =   63
         Top             =   1080
         Width           =   3375
      End
      Begin VB.Label ListaMare 
         Caption         =   "1 nimic"
         Height          =   255
         Index           =   0
         Left            =   5400
         TabIndex        =   62
         Top             =   840
         Width           =   3375
      End
      Begin VB.Label Label2 
         Caption         =   "Expicatii despre programul prezentat:"
         Height          =   255
         Left            =   360
         TabIndex        =   61
         Top             =   1200
         Width           =   2775
      End
      Begin VB.Label Label1 
         Caption         =   "Titlul programului prezentat:"
         Height          =   255
         Left            =   360
         TabIndex        =   60
         Top             =   720
         Width           =   2055
      End
      Begin VB.Line Line1 
         BorderColor     =   &H00000000&
         Index           =   2
         X1              =   -69720
         X2              =   -62760
         Y1              =   5400
         Y2              =   5400
      End
      Begin VB.Shape BorduraTemp 
         BackColor       =   &H000000FF&
         BorderColor     =   &H000000FF&
         Height          =   2895
         Index           =   0
         Left            =   9000
         Top             =   5640
         Width           =   3255
      End
      Begin VB.Shape BorduraTemp 
         BackColor       =   &H000000FF&
         BorderColor     =   &H000000FF&
         Height          =   2895
         Index           =   1
         Left            =   -66000
         Top             =   5640
         Width           =   3255
      End
      Begin VB.Line Line8 
         BorderColor     =   &H00000000&
         Index           =   0
         X1              =   3480
         X2              =   8880
         Y1              =   6000
         Y2              =   6000
      End
      Begin VB.Line Line9 
         BorderColor     =   &H00000000&
         Index           =   0
         X1              =   8640
         X2              =   8880
         Y1              =   5880
         Y2              =   6000
      End
      Begin VB.Line Line10 
         BorderColor     =   &H00000000&
         Index           =   0
         X1              =   8640
         X2              =   8880
         Y1              =   6120
         Y2              =   6000
      End
      Begin VB.Line Line8 
         BorderColor     =   &H00000000&
         Index           =   1
         X1              =   -71160
         X2              =   -66120
         Y1              =   6000
         Y2              =   6000
      End
      Begin VB.Line Line9 
         BorderColor     =   &H00000000&
         Index           =   1
         X1              =   -66360
         X2              =   -66120
         Y1              =   5880
         Y2              =   6000
      End
      Begin VB.Line Line10 
         BorderColor     =   &H00000000&
         Index           =   3
         X1              =   -66360
         X2              =   -66120
         Y1              =   6120
         Y2              =   6000
      End
      Begin VB.Line Line8 
         BorderColor     =   &H00000000&
         Index           =   2
         X1              =   -70200
         X2              =   -66120
         Y1              =   6000
         Y2              =   6000
      End
      Begin VB.Line Line9 
         BorderColor     =   &H00000000&
         Index           =   2
         X1              =   -66360
         X2              =   -66120
         Y1              =   5880
         Y2              =   6000
      End
      Begin VB.Line Line10 
         BorderColor     =   &H00000000&
         Index           =   1
         X1              =   -66360
         X2              =   -66120
         Y1              =   6120
         Y2              =   6000
      End
      Begin VB.Line Line8 
         BorderColor     =   &H00000000&
         Index           =   3
         X1              =   -69480
         X2              =   -66120
         Y1              =   6000
         Y2              =   6000
      End
      Begin VB.Line Line9 
         BorderColor     =   &H00000000&
         Index           =   3
         X1              =   -66360
         X2              =   -66120
         Y1              =   5880
         Y2              =   6000
      End
      Begin VB.Line Line10 
         BorderColor     =   &H00000000&
         Index           =   2
         X1              =   -66360
         X2              =   -66120
         Y1              =   6120
         Y2              =   6000
      End
      Begin VB.Line Line8 
         BorderColor     =   &H00000000&
         Index           =   4
         X1              =   -69000
         X2              =   -66120
         Y1              =   6000
         Y2              =   6000
      End
      Begin VB.Line Line9 
         BorderColor     =   &H00000000&
         Index           =   4
         X1              =   -66360
         X2              =   -66120
         Y1              =   5880
         Y2              =   6000
      End
      Begin VB.Line Line10 
         BorderColor     =   &H00000000&
         Index           =   4
         X1              =   -66360
         X2              =   -66120
         Y1              =   6120
         Y2              =   6000
      End
      Begin VB.Line Line8 
         BorderColor     =   &H00000000&
         Index           =   5
         X1              =   -68160
         X2              =   -66120
         Y1              =   6000
         Y2              =   6000
      End
      Begin VB.Line Line9 
         BorderColor     =   &H00000000&
         Index           =   5
         X1              =   -66360
         X2              =   -66120
         Y1              =   5880
         Y2              =   6000
      End
      Begin VB.Line Line10 
         BorderColor     =   &H00000000&
         Index           =   5
         X1              =   -66360
         X2              =   -66120
         Y1              =   6120
         Y2              =   6000
      End
      Begin VB.Label Label28 
         Alignment       =   2  'Center
         Caption         =   "Utilitare"
         BeginProperty Font 
            Name            =   "MS Serif"
            Size            =   24
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   615
         Index           =   0
         Left            =   9120
         TabIndex        =   59
         Top             =   3960
         Width           =   3015
      End
   End
End
Attribute VB_Name = "Geneza"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private sat(0 To 5) As String

Private Sub Arhiva_Click()
On Error GoTo aa
Salvare_matrita.Filter = "Fisiere xls (*.xls)|*.xls"
Salvare_matrita.ShowOpen
Ar_text.Text = Salvare_matrita.Filename
aa:
End Sub

Private Sub cale2_GotFocus(Index As Integer)
cale2(Index).BackColor = &H0&
End Sub

Private Sub calea_GotFocus(Index As Integer)
calea(Index).BackColor = &H0&
End Sub

Private Sub Captura_Mare666_Click()
CapturaEU.Show
End Sub

Private Sub Capturare_Click()
DespreYO.Show
End Sub

Private Sub Citeste_Text_GotFocus(Index As Integer)
Citeste_Text(Index).BackColor = &H0&
End Sub

Private Sub Creaza_in_Dir_Click()
'On Error GoTo aa
'Salvare_matrita.Filter = "Fisiere zip (*.zip)|*.zip"
'Salvare_matrita.ShowOpen
'Cale_matrita.Text = Salvare_matrita.FileName
'aa:
Dim sRet As String

mBFF.InitFolder = "c:\"
sRet = mBFF.BrowseForFolder(Me.hWnd, "Selecteaza directorul in care va fi creata matrita ...")

If (sRet <> vbNullString) Then
Cale_matrita.Text = sRet
End If
End Sub

Private Sub D_Alege_Click()
On Error GoTo aa
Deschide_Driver_fundal.Filter = "Fisiere jpg (*.jpg)|*.jpg"
Deschide_Driver_fundal.ShowOpen
D_Cale_text.Text = Deschide_Driver_fundal.Filename
aa:
End Sub

Private Sub DrivereCale_Click(Index As Integer)
On Error GoTo aa
DeschideDriver.Filter = "Fisiere exe (*.exe)|*.exe"
DeschideDriver.ShowOpen
DrivereCale(Index).Text = DeschideDriver.Filename
numeDriver(Index) = DeschideDriver.FileTitle
aa:

End Sub

Private Sub DrivereCale_GotFocus(Index As Integer)
DrivereCale(Index).BackColor = &H0&
End Sub

Private Sub DrivereExplicatii_GotFocus(Index As Integer)
DrivereExplicatii(Index).BackColor = &H0&
End Sub

Private Sub DrivereTitlu_GotFocus(Index As Integer)
DrivereTitlu(Index).BackColor = &H0&
End Sub

Private Sub Explicatie_GotFocus(Index As Integer)
Explicatie(Index).BackColor = &H0&
End Sub

Private Sub Form_Load()

sat(0) = "UTILITARE"
sat(1) = "MULTIMEDIA"
sat(2) = "JOCURI"
sat(3) = "INTERNET"
sat(4) = "ANTIVIRUS"
sat(5) = "PERMANENTE"

Bula_general = "c:\"

On Error Resume Next
MkDir "C:\PC_World"

For nnn = 1 To 18
UT_Variabile_Nume(nnn) = ""
Next nnn

For yo = 0 To 5
Sterge_Click (yo)
Next yo

StergeDriver_Click

CaleFundalIntro.Text = App.Path & "\Geneza\IMG\fundal_reclama.gif"
CaleAjutor.Text = App.Path & "\Geneza\IMG\fundal-c.gif"
D_Cale_text.Text = App.Path & "\Geneza\IMG\fundal7.jpg"
End Sub

Private Sub Form_Unload(Cancel As Integer)
'Unload CapturaEU
Unload PreFormular
Unload PreVedere
Unload Me
End
End Sub

Private Sub FundalAjutor_Click()
On Error GoTo aa
DeschideAjutor.Filter = "Fisiere gif (*.gif)|*.gif"
DeschideAjutor.ShowOpen
CaleAjutor.Text = DeschideAjutor.Filename
aa:
End Sub

Private Sub FundalIntro_Click()
On Error GoTo aa
FundalReclama.Filter = "Fisiere gif (*.gif)|*.gif"
FundalReclama.ShowOpen
CaleFundalIntro.Text = FundalReclama.Filename
aa:

End Sub

Private Sub Imagine_Mare_Click(Index As Integer)
On Error GoTo aa

I_Mare_deschide.Filename = ""
I_Mare_deschide.Filter = "Fisiere gif (*.gif)|*.gif"
I_Mare_deschide.ShowOpen

IMare(Index).Text = I_Mare_deschide.Filename
Pro_imagine(Index).Picture = LoadPicture(IMica(Index).Text)
IMare(Index).BackColor = &H0&
aa:

End Sub

Private Sub ImagineM_Click(Index As Integer)
On Error GoTo aa

I_mica_deschide.Filename = ""
I_mica_deschide.Filter = "Fisiere gif (*.gif)|*.gif"
I_mica_deschide.ShowOpen

IMica(Index).Text = I_mica_deschide.Filename
Pro_imagine(Index).Picture = LoadPicture(IMica(Index).Text)
IMica(Index).BackColor = &H0&
aa:

End Sub

Private Sub IMare_GotFocus(Index As Integer)
IMare(Index).BackColor = &H0&
End Sub

Private Sub IMica_GotFocus(Index As Integer)
IMica(Index).BackColor = &H0&
End Sub

Private Sub IN_Lista_Click(Index As Integer)
'**********************************************************

If Titlu(Index).Text = "" Then
MsgBox "Programul prezentat trebuie sa aiba un nume. Te rog completeaza casuta: TITLUL PROGRAMULUI PREZENTAT"
Titlu(Index).BackColor = &HFF0000
Exit Sub
End If

If Explicatie(Index).Text = "" Then
MsgBox "Programul prezentat trebuie sa aiba explicatii. Te rog completeaza casuta:" & UCase("Expicatii despre programul prezentat")
Explicatie(Index).BackColor = &HFF0000
Exit Sub
End If

If Citeste_Text(Index).Text = "" Then
MsgBox "Te rog sa introduci in casuta " & UCase("Informatii ce se vor citi la apasarea butonului Citeste-ma") & " text cu privire la programul prezentat."
Citeste_Text(Index).BackColor = &HFF0000
Exit Sub
End If



If IMare(Index).Text = "" And IMica(Index).Text = "" Then
MsgBox "Trebuie sa-ti alegi doua fisiere gif:" & vbCrLf & "unul care conzine captura mica si altul care contine captura 1:1"
IMare(Index).BackColor = &HFF0000
IMica(Index).BackColor = &HFF0000
Exit Sub
End If

If IMare(Index).Text = "" Then
MsgBox "Trebuie sa alegi fisierul pentru captura 1:1 (captura mare)"
IMare(Index).BackColor = &HFF0000
Exit Sub
End If

If IMica(Index).Text = "" Then
MsgBox "Trebuie sa alegi fisierul pentru captura mica."
IMica(Index).BackColor = &HFF0000
Exit Sub
End If

If calea(Index).Text = "" And cale2(Index).Text = "" Then
MsgBox "In functie de ce dispui trebuie sa-i pui programului la dispozitie calea spre kit-ul de instalare sau spre aplicatia de instalare"
calea(Index).BackColor = &HFF0000
cale2(Index).BackColor = &HFF0000
Exit Sub
End If


For vaca = 0 To 5

If InStr(Titlu(vaca).Text, "]") <> 0 Or InStr(Titlu(vaca).Text, "[") <> 0 Or InStr(Titlu(vaca).Text, Chr(39)) <> 0 Or InStr(Titlu(vaca).Text, Chr(34)) <> 0 Or InStr(Titlu(vaca).Text, "#") <> 0 Or InStr(Titlu(vaca).Text, "|") <> 0 Then
MsgBox "Caracterele: <|><[><]><#><" & Chr(39) & "><" & Chr(34) & "> sunt nepermise. " & vbCrLf & _
"Greseala este in sectiunea - " & sat(vaca) & ", la casuta " & Chr(34) & "Titlul programului prezentat" & Chr(34)
Master_Control.Tab = vaca
Titlu(vaca).BackColor = &HFF0000
Exit Sub
End If

If InStr(Explicatie(vaca).Text, "]") <> 0 Or InStr(Explicatie(vaca).Text, "[") <> 0 Or InStr(Explicatie(vaca).Text, Chr(39)) <> 0 Or InStr(Explicatie(vaca).Text, Chr(34)) <> 0 Or InStr(Explicatie(vaca).Text, "#") <> 0 Or InStr(Explicatie(vaca).Text, "|") <> 0 Then
MsgBox "Caracterele: <|><[><]><#><" & Chr(39) & "><" & Chr(34) & "> sunt nepermise. " & vbCrLf & _
"Greseala este in sectiunea - " & sat(vaca) & ", la casuta " & Chr(34) & "Expicatii despre programul prezentat" & Chr(34)
Explicatie(vaca).BackColor = &HFF0000
Master_Control.Tab = vaca
Exit Sub
End If

Next vaca


If Index = 0 Then
ggg = 0
Do While UT_Variabile_Nume(ggg) <> ""
ggg = ggg + 1
Loop

If ggg >= 18 Then
MsgBox "(Utilitare) Prea multe ! Limita este de 18 programe/sectiune -> (0 la 18) "
Exit Sub
End If

UT_Variabile_Nume(ggg) = ggg & "|" & Titlu(0).Text & "|#"
UT_Variabile_Explicatii(ggg) = "[" & ggg & "]" & vbCrLf & Explicatie(0).Text & "[STOP]"
UT_Citeste_ma(ggg) = Citeste_Text(0).Text

UT_KitZip(ggg) = temp_KitZip(0)
UT_Kit(ggg) = temp_Kit(0)

ListaMare(ggg).Caption = Titlu(0).Text

UT_Img1(ggg) = IMica(Index).Text
UT_Img2(ggg) = IMare(Index).Text

Imagine_Meniu(Index).Picture = Pro_imagine(Index).Picture

'Titlu(0).Text = ""
'Explicatie(0).Text = ""
'Citeste_Text(0).Text = ""
'calea(0).Text = ""
'cale2(0).Text = ""
End If
'**********************************************************
If Index = 1 Then
ggg = 0
Do While MM_Variabile_Nume(ggg) <> ""
ggg = ggg + 1
Loop

If ggg >= 18 Then
MsgBox "(Multimedia) Prea multe ! Limita este de 18 programe/sectiune -> (0 la 18) "
Exit Sub
End If


MM_Variabile_Nume(ggg) = ggg & "|" & Titlu(1).Text & "|#"
MM_Variabile_Explicatii(ggg) = "[" & ggg & "]" & vbCrLf & Explicatie(1).Text & "[STOP]"
MM_Citeste_ma(ggg) = Citeste_Text(1).Text

MM_KitZip(ggg) = temp_KitZip(1)
MM_Kit(ggg) = temp_Kit(1)

ListaMareMM(ggg).Caption = Titlu(1).Text

MM_Img1(ggg) = IMica(Index).Text
MM_Img2(ggg) = IMare(Index).Text

Imagine_Meniu(Index).Picture = Pro_imagine(Index).Picture

End If
'**********************************************************
If Index = 2 Then
ggg = 0
Do While JC_Variabile_Nume(ggg) <> ""
ggg = ggg + 1
Loop

If ggg >= 18 Then
MsgBox "(Jocuri) Prea multe ! Limita este de 18 programe/sectiune -> (0 la 18) "
Exit Sub
End If


JC_Variabile_Nume(ggg) = ggg & "|" & Titlu(2).Text & "|#"
JC_Variabile_Explicatii(ggg) = "[" & ggg & "]" & vbCrLf & Explicatie(2).Text & "[STOP]"
JC_Citeste_ma(ggg) = Citeste_Text(2).Text

JC_KitZip(ggg) = temp_KitZip(2)
JC_Kit(ggg) = temp_Kit(2)

ListaMareJC(ggg).Caption = Titlu(2).Text

JC_Img1(ggg) = IMica(Index).Text
JC_Img2(ggg) = IMare(Index).Text

Imagine_Meniu(Index).Picture = Pro_imagine(Index).Picture

End If
'**********************************************************
If Index = 3 Then
ggg = 0
Do While IN_Variabile_Nume(ggg) <> ""
ggg = ggg + 1
Loop

If ggg >= 18 Then
MsgBox "(Internet) Prea multe ! Limita este de 18 programe/sectiune -> (0 la 18) "
Exit Sub
End If


IN_Variabile_Nume(ggg) = ggg & "|" & Titlu(3).Text & "|#"
IN_Variabile_Explicatii(ggg) = "[" & ggg & "]" & vbCrLf & Explicatie(3).Text & "[STOP]"
IN_Citeste_ma(ggg) = Citeste_Text(3).Text

IN_KitZip(ggg) = temp_KitZip(3)
IN_Kit(ggg) = temp_Kit(3)

ListaMareIN(ggg).Caption = Titlu(3).Text

IN_Img1(ggg) = IMica(Index).Text
IN_Img2(ggg) = IMare(Index).Text

Imagine_Meniu(Index).Picture = Pro_imagine(Index).Picture

End If
'**********************************************************
If Index = 4 Then
ggg = 0
Do While AV_Variabile_Nume(ggg) <> ""
ggg = ggg + 1
Loop

If ggg >= 18 Then
MsgBox "(Antivirus) Prea multe ! Limita este de 18 programe/sectiune -> (0 la 18) "
Exit Sub
End If


AV_Variabile_Nume(ggg) = ggg & "|" & Titlu(4).Text & "|#"
AV_Variabile_Explicatii(ggg) = "[" & ggg & "]" & vbCrLf & Explicatie(4).Text & "[STOP]"
AV_Citeste_ma(ggg) = Citeste_Text(4).Text

AV_KitZip(ggg) = temp_KitZip(4)
AV_Kit(ggg) = temp_Kit(4)

ListaMareAV(ggg).Caption = Titlu(4).Text

AV_Img1(ggg) = IMica(Index).Text
AV_Img2(ggg) = IMare(Index).Text

Imagine_Meniu(Index).Picture = Pro_imagine(Index).Picture

End If
'**********************************************************
If Index = 5 Then
ggg = 0
Do While PR_Variabile_Nume(ggg) <> ""
ggg = ggg + 1
Loop

If ggg >= 18 Then
MsgBox "(Permanente) Prea multe ! Limita este de 18 programe/sectiune -> (0 la 18) "
Exit Sub
End If


PR_Variabile_Nume(ggg) = ggg & "|" & Titlu(5).Text & "|#"
PR_Variabile_Explicatii(ggg) = "[" & ggg & "]" & vbCrLf & Explicatie(5).Text & "[STOP]"
PR_Citeste_ma(ggg) = Citeste_Text(5).Text

PR_KitZip(ggg) = temp_KitZip(5)
PR_Kit(ggg) = temp_Kit(5)

ListaMarePR(ggg).Caption = Titlu(5).Text

PR_Img1(ggg) = IMica(Index).Text
PR_Img2(ggg) = IMare(Index).Text

Imagine_Meniu(Index).Picture = Pro_imagine(Index).Picture

End If


Titlu(Index).Text = ""
Explicatie(Index).Text = ""
Citeste_Text(Index).Text = ""
IMica(Index).Text = ""
IMare(Index).Text = ""
calea(Index).Text = ""
cale2(Index).Text = ""

End Sub


Private Sub Redimensioneaza_Click()
iWMax = bordura.Width
iHMax = bordura.Height
  w = LungimeQ
  h = InaltimeQ

   zAspect = w / h
   If w <= iWMax Then
      iW = w
      iH = CLng(iW / zAspect)
   Else  ' Picture1.Width > iWMax
      iW = iWMax
      iH = CLng(iWMax / zAspect)
   End If
   If iH > iHMax Then
      iH = iHMax
      iW = CLng(iH * zAspect)
   End If
   
Image1.Width = iW
Image1.Height = iH
Image1.Refresh

Image1.Left = bordura.Left + (bordura.Width / 2) - (Image1.Width / 2)
Image1.Top = bordura.Top + (bordura.Height / 2) - (Image1.Height / 2)

End Sub

Private Sub Inainte_de_Click(Index As Integer)

If Index < 6 Then

If Explicatie(Index).Text = "" Then
MsgBox "Pentru ca sa vezi cum se aranjeaza pe interfata textul cu explicatiile aferente programului prezentat trebuie sa completezi casuta:" & UCase("Expicatii despre programul prezentat")
Explicatie(Index).BackColor = &HFF0000
Exit Sub
End If

If IMica(Index).Text = "" Then
MsgBox "Alege gif-ul (captura mica) pentru ca programul sa poata afisa captura programului prezentat."
IMica(Index).BackColor = &HFF0000
Exit Sub
End If

End If

If Index = 0 Then
PreFormular.InformatiiPrograme.Caption = Explicatie(Index).Text
PreFormular.Giful.LoadFromFile (IMica(Index).Text)
PreFormular.Show
End If

If Index = 1 Then
PreFormular.InformatiiPrograme.Caption = Explicatie(Index).Text
PreFormular.Giful.LoadFromFile (IMica(Index).Text)
PreFormular.Show
End If

If Index = 2 Then
PreFormular.InformatiiPrograme.Caption = Explicatie(Index).Text
PreFormular.Giful.LoadFromFile (IMica(Index).Text)
PreFormular.Show
End If

If Index = 3 Then
PreFormular.InformatiiPrograme.Caption = Explicatie(Index).Text
PreFormular.Giful.LoadFromFile (IMica(Index).Text)
PreFormular.Show
End If


If Index = 4 Then
PreFormular.InformatiiPrograme.Caption = Explicatie(Index).Text
PreFormular.Giful.LoadFromFile (IMica(Index).Text)
PreFormular.Show
End If


If Index = 5 Then
PreFormular.InformatiiPrograme.Caption = Explicatie(Index).Text
PreFormular.Giful.LoadFromFile (IMica(Index).Text)
PreFormular.Show
End If

'revista
If Index = 6 Then
ff = FreeFile
Open App.Path & "\Geneza\Revista.htm" For Output As #ff
Print #ff, revista1.Text & vbCrLf & Revista & vbCrLf & revista2.Text
Close #ff
PreVedere.Text_Imagine.Navigate (App.Path & "\Geneza\Revista.htm")
PreVedere.Show
End If

If Index = 7 Then

If CaleFundalIntro.Text = "" Then
MsgBox "Trebuie sa alegi imaginea de fundal (imaginea pentru reclama)!"
Exit Sub
End If

ff = FreeFile
Open App.Path & "\Geneza\Intrare.htm" For Output As #ff
lalala1 = "<DIV id=cade style=" & Chr(34) & "BACKGROUND-COLOR: #" & culoare.Text & "; HEIGHT:" & Inaltime.Text & _
"px; LEFT: 126px; POSITION: absolute; TOP: 100px; VISIBILITY: hidden;WIDTH:" & latime.Text & "px" & Chr(34) & ">"


lalala2 = "</DIV></tr></td></table>"

lala3 = "<table border=" & Chr(34) & borduraG.Text & Chr(34) & " cellpadding=" & Chr(34) & "0" & _
Chr(34) & " cellspacing=" & Chr(34) & "0" & Chr(34) & " style=" & Chr(34) & _
"border-collapse: collapse" & Chr(34) & " width=" & Chr(34) & "100%" & Chr(34) & _
" height=" & Chr(34) & "100%" & Chr(34) & "><tr><td valign=top align=right " & _
"width=" & Chr(34) & "100%" & Chr(34) & " background=" & Chr(34) & _
CaleFundalIntro.Text & Chr(34) & "height=100%><button onclick=" & Chr(34) & _
"Hai_Pa();return false" & Chr(34) & " style=" & Chr(34) & "height:20;width:20" & Chr(34) & _
"><FONT color=" & Chr(34) & "000000" & Chr(34) & " face=Arial size=1>x</FONT></button>"

proces = Proceseaza(Intro.Text)
Print #ff, Intro1.Text & vbCrLf & proces & vbCrLf & Intro2.Text & lalala1 & lala3 & Intro3.Text & lalala2
Close #ff
PreVedere.Text_Imagine.Navigate (App.Path & "\Geneza\Intrare.htm")
PreVedere.Show
End If

If Index = 8 Then

If CaleAjutor.Text = "" Then
MsgBox "Trebuie sa alegi imaginea de fundal!"
Exit Sub
End If

ff = FreeFile
Open App.Path & "\Geneza\Ajutor.htm" For Output As #ff

xxl = Proceseaza(Ajutor.Text)
xx1 = "<body bgcolor=white background=" & Chr(34) & CaleAjutor.Text & Chr(34) & "><font size=" & Chr(34) & FontMarime.Text & Chr(34) & " face=" & Chr(34) & Fontul.Text & Chr(34) & " color=" & Chr(34) & "#" & FontCuloare.Text & Chr(34) & ">"

Print #ff, Ajutor1.Text & vbCrLf & xx1 & xxl & "</FONT>"
Close #ff
PreVedere.Text_Imagine.Navigate (App.Path & "\Geneza\Ajutor.htm")
PreVedere.Show
End If

If Index = 9 Then

If D_Cale_text.Text = "" Then
MsgBox "Trebuie sa alegi imaginea de fundal(drivere)!"
Exit Sub
End If

For bulaD = 0 To 7
If DrivereTitlu(bulaD).Text <> "" Or DrivereExplicatii(bulaD).Text <> "" Or DrivereCale(bulaD).Text <> "" Then
GoTo este_una
Else

DrivereExplicatii(bulaD).BackColor = 16711680
DrivereTitlu(bulaD).BackColor = 16711680
DrivereCale(bulaD).BackColor = 16711680

MsgBox "Trebuie sa completezi cel putin o casuta ! (adica interfata trebuie sa prezinte cel putin un driver)"
Exit Sub
End If
Next bulaD
este_una:

For bulaD = 0 To 7
If DrivereTitlu(bulaD).Text <> "" And DrivereExplicatii(bulaD).Text <> "" And DrivereCale(bulaD).Text = "" Then
MsgBox "Pentru ca programul sa poata copia driver-ul in structura matritei trebuie sa introduci" & vbCrLf & _
"toate datele cerute intr-o casuta(nu trebuie lasata completata partial)"
DrivereCale(bulaD).BackColor = 16711680
Exit Sub
End If

If DrivereTitlu(bulaD).Text <> "" And DrivereExplicatii(bulaD).Text = "" And DrivereCale(bulaD).Text <> "" Then
MsgBox "Pentru ca programul sa poata copia driver-ul in structura matritei trebuie sa introduci" & vbCrLf & _
"toate datele cerute intr-o casuta(nu trebuie lasata completata partial)"
DrivereExplicatii(bulaD).BackColor = 16711680
Exit Sub
End If


If DrivereTitlu(bulaD).Text = "" And DrivereExplicatii(bulaD).Text <> "" And DrivereCale(bulaD).Text <> "" Then
MsgBox "Pentru ca programul sa poata copia driver-ul in structura matritei trebuie sa introduci" & vbCrLf & _
"toate datele cerute intr-o casuta(nu trebuie lasata completata partial)"
DrivereTitlu(bulaD).BackColor = 16711680
Exit Sub
End If


If DrivereTitlu(bulaD).Text <> "" And DrivereExplicatii(bulaD).Text = "" And DrivereCale(bulaD).Text = "" Then
MsgBox "Pentru ca programul sa poata copia driver-ul in structura matritei trebuie sa introduci" & vbCrLf & _
"toate datele cerute intr-o casuta(nu trebuie lasata completata partial)"
DrivereExplicatii(bulaD).BackColor = 16711680
DrivereCale(bulaD).BackColor = 16711680
Exit Sub
End If


If DrivereTitlu(bulaD).Text = "" And DrivereExplicatii(bulaD).Text <> "" And DrivereCale(bulaD).Text = "" Then
MsgBox "Pentru ca programul sa poata copia driver-ul in structura matritei trebuie sa introduci" & vbCrLf & _
"toate datele cerute intr-o casuta(nu trebuie lasata completata partial)"
DrivereTitlu(bulaD).BackColor = 16711680
DrivereCale(bulaD).BackColor = 16711680
Exit Sub
End If

If DrivereTitlu(bulaD).Text = "" And DrivereExplicatii(bulaD).Text = "" And DrivereCale(bulaD).Text <> "" Then
MsgBox "Pentru ca programul sa poata copia driver-ul in structura matritei trebuie sa introduci" & vbCrLf & _
"toate datele cerute intr-o casuta(nu trebuie lasata completata partial)"
DrivereTitlu(bulaD).BackColor = 16711680
DrivereExplicatii(bulaD).BackColor = 16711680
Exit Sub
End If

DoEvents

Next bulaD

ff = FreeFile
Open App.Path & "\Geneza\Drivere.htm" For Output As #ff

d333 = "<body scroll=no bgcolor=#ffffff background=" & Chr(34) & D_Cale_text.Text & Chr(34) & ">"

d222 = "<center><FONT style=" & Chr(34) & "font-family:Time New Roman;face:Time New Roman" & Chr(34) & " size=" & Chr(34) & "10" & Chr(34) & " color=#ffffff> Drivere </FONT><br><br></center>"

capulZulu = d333 & d222 & "<table border=" & Chr(34) & "0" & Chr(34) & " cellpadding=" & Chr(34) & "0" & Chr(34) & " cellspacing=" & Chr(34) & "0" & Chr(34) & " style=" & Chr(34) & "border-collapse:collapse" & Chr(34) & " width=" & Chr(34) & "100%" & Chr(34) & " id=" & Chr(34) & "Eu" & Chr(34) & ">"

bulaD = 0
For tt = 1 To 4
capulZulu = capulZulu & "<tr>"

For vv = 1 To 2
If DrivereTitlu(bulaD).Text = "" And DrivereExplicatii(bulaD).Text = "" And DrivereCale(bulaD).Text = "" Then
GoTo nimic
End If


capulZulu = capulZulu & "<td width=" & Chr(34) & "50%" & Chr(34) & " onmouseout=" & Chr(34) & "sterge()" & Chr(34) & "onmouseover=" & Chr(34) & "arata(" & Chr(39) & DrivereExplicatii(bulaD).Text & Chr(39) & ")" & Chr(34) & ">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"

capulZulu = capulZulu & "<a href=" & Chr(34) & DrivereCale(bulaD).Text & Chr(34) & _
" style=" & Chr(34) & "text-decoration:none" & Chr(34) & ">"

capulZulu = capulZulu & "<font size=" & Chr(34) & D_FontMarime.Text & Chr(34) & " face=" & _
Chr(34) & D_Font.Text & Chr(34) & " color=" & Chr(34) & "#" & D_FontCuloare.Text & Chr(34) & _
"><img src=" & Chr(34) & "IMG\pc2.GIF" & Chr(34) & " border=" & Chr(34) & "0" & _
Chr(34) & ">" & DrivereTitlu(bulaD).Text & "</font></a>"

capulZulu = capulZulu & "</td>"

nimic:
bulaD = bulaD + 1
Next vv
capulZulu = capulZulu & "</tr>"
Next tt

'MsgBox capulZulu
InPlus = "<font size=" & Chr(34) & EX_FontMarime.Text & Chr(34) & " face=" & Chr(34) & EX_Font.Text & Chr(34) & " color=" & Chr(34) & "#" & EX_FontCuloare.Text & Chr(34) & "><div align=left valign=top Id=" & Chr(34) & "CutiaNeagra" & Chr(34) & " style=" & Chr(34) & "position:absolute;top:13;left:20;width:100%;overflow:auto;height:50px" & Chr(34) & "></div></font>"

Print #ff, drivere1.Text & vbCrLf & capulZulu & Drivere & InPlus & vbCrLf & drivere2.Text
Close #ff
PreVedere.Text_Imagine.Navigate (App.Path & "\Geneza\Drivere.htm")
PreVedere.Show
End If

End Sub

Function Proceseaza(ByVal xx As String) As String
saty = xx
saty = Replace(saty, Chr(13), "<br>")

Proceseaza = saty
End Function

Private Sub kit_Click(Index As Integer)
On Error GoTo aa

Deschide.Filename = ""
Deschide.Filter = "Fisiere EXE (*.exe)|*.exe"
Deschide.ShowOpen

If Index = 0 Then
temp_Kit(0) = Deschide.Filename
cale2(0).Text = Deschide.Filename
End If

If Index = 1 Then
temp_Kit(1) = Deschide.Filename
cale2(1).Text = Deschide.Filename
End If

If Index = 2 Then
temp_Kit(2) = Deschide.Filename
cale2(2).Text = Deschide.Filename
End If

If Index = 3 Then
temp_Kit(3) = Deschide.Filename
cale2(3).Text = Deschide.Filename
End If

If Index = 4 Then
temp_Kit(4) = Deschide.Filename
cale2(4).Text = Deschide.Filename
End If

If Index = 5 Then
temp_Kit(5) = Deschide.Filename
cale2(5).Text = Deschide.Filename
End If

cale2(Index).BackColor = &H0&
aa:
End Sub

Private Sub kitZip_Click(Index As Integer)
On Error GoTo aa

Deschide.Filename = ""
Deschide.Filter = "Fisiere zip (*.zip)|*.zip"
Deschide.ShowOpen

If Index = 0 Then
temp_KitZip(0) = Deschide.Filename
calea(0).Text = Deschide.Filename
End If

If Index = 1 Then
temp_KitZip(1) = Deschide.Filename
calea(1).Text = Deschide.Filename
End If

If Index = 2 Then
temp_KitZip(2) = Deschide.Filename
calea(2).Text = Deschide.Filename
End If

If Index = 3 Then
temp_KitZip(3) = Deschide.Filename
calea(3).Text = Deschide.Filename
End If

If Index = 4 Then
temp_KitZip(4) = Deschide.Filename
calea(4).Text = Deschide.Filename
End If

If Index = 5 Then
temp_KitZip(5) = Deschide.Filename
calea(5).Text = Deschide.Filename
End If

calea(Index).BackColor = &H0&

aa:
End Sub

Private Sub ListaMare_Click(Index As Integer)
On Error Resume Next

EU_nobel = Mid(UT_Variabile_Nume(Index), InStr(UT_Variabile_Nume(Index), "|") + 1, Len(UT_Variabile_Nume(Index)))
Titlu(0).Text = Mid(EU_nobel, 1, InStr(EU_nobel, "|#") - 1)

EU_nobel = Mid(UT_Variabile_Explicatii(Index), InStr(UT_Variabile_Explicatii(Index), "]") + 1, Len(UT_Variabile_Explicatii(Index)))
Explicatie(0).Text = Mid(EU_nobel, 1, InStr(EU_nobel, "[STO") - 4) 'MM_Variabile_Explicatii(Index)

Citeste_Text(0) = UT_Citeste_ma(Index)

Imagine_Meniu(0).Picture = LoadPicture(UT_Img1(Index))
End Sub

Private Sub ListaMareAV_Click(Index As Integer)
On Error Resume Next

EU_nobel = Mid(AV_Variabile_Nume(Index), InStr(AV_Variabile_Nume(Index), "|") + 1, Len(AV_Variabile_Nume(Index)))
Titlu(4).Text = Mid(EU_nobel, 1, InStr(EU_nobel, "|#") - 1)

EU_nobel = Mid(AV_Variabile_Explicatii(Index), InStr(AV_Variabile_Explicatii(Index), "]") + 1, Len(AV_Variabile_Explicatii(Index)))
Explicatie(4).Text = Mid(EU_nobel, 1, InStr(EU_nobel, "[STO") - 4) 'MM_Variabile_Explicatii(Index)

Imagine_Meniu(4).Picture = LoadPicture(AV_Img1(Index))
End Sub

Private Sub ListaMareIN_Click(Index As Integer)
On Error Resume Next

EU_nobel = Mid(IN_Variabile_Nume(Index), InStr(IN_Variabile_Nume(Index), "|") + 1, Len(IN_Variabile_Nume(Index)))
Titlu(3).Text = Mid(EU_nobel, 1, InStr(EU_nobel, "|#") - 1)

EU_nobel = Mid(IN_Variabile_Explicatii(Index), InStr(IN_Variabile_Explicatii(Index), "]") + 1, Len(IN_Variabile_Explicatii(Index)))
Explicatie(3).Text = Mid(EU_nobel, 1, InStr(EU_nobel, "[STO") - 4) 'MM_Variabile_Explicatii(Index)

Imagine_Meniu(3).Picture = LoadPicture(IN_Img1(Index))
End Sub

Private Sub ListaMareJC_Click(Index As Integer)
On Error Resume Next

EU_nobel = Mid(JC_Variabile_Nume(Index), InStr(JC_Variabile_Nume(Index), "|") + 1, Len(JC_Variabile_Nume(Index)))
Titlu(2).Text = Mid(EU_nobel, 1, InStr(EU_nobel, "|#") - 1)

EU_nobel = Mid(JC_Variabile_Explicatii(Index), InStr(JC_Variabile_Explicatii(Index), "]") + 1, Len(JC_Variabile_Explicatii(Index)))
Explicatie(2).Text = Mid(EU_nobel, 1, InStr(EU_nobel, "[STO") - 4) 'MM_Variabile_Explicatii(Index)

Imagine_Meniu(2).Picture = LoadPicture(JC_Img1(Index))
End Sub

Private Sub ListaMareMM_Click(Index As Integer)
On Error Resume Next

EU_nobel = Mid(MM_Variabile_Nume(Index), InStr(MM_Variabile_Nume(Index), "|") + 1, Len(MM_Variabile_Nume(Index)))
Titlu(1).Text = Mid(EU_nobel, 1, InStr(EU_nobel, "|#") - 1)

EU_nobel = Mid(MM_Variabile_Explicatii(Index), InStr(MM_Variabile_Explicatii(Index), "]") + 1, Len(MM_Variabile_Explicatii(Index)))
Explicatie(1).Text = Mid(EU_nobel, 1, InStr(EU_nobel, "[STO") - 4) 'MM_Variabile_Explicatii(Index)

Imagine_Meniu(1).Picture = LoadPicture(MM_Img1(Index))

End Sub

Private Sub ListaMarePR_Click(Index As Integer)
On Error Resume Next

EU_nobel = Mid(PR_Variabile_Nume(Index), InStr(PR_Variabile_Nume(Index), "|") + 1, Len(PR_Variabile_Nume(Index)))
Titlu(5).Text = Mid(EU_nobel, 1, InStr(EU_nobel, "|#") - 1)

EU_nobel = Mid(PR_Variabile_Explicatii(Index), InStr(PR_Variabile_Explicatii(Index), "]") + 1, Len(PR_Variabile_Explicatii(Index)))
Explicatie(5).Text = Mid(EU_nobel, 1, InStr(EU_nobel, "[STO") - 4) 'MM_Variabile_Explicatii(Index)

Imagine_Meniu(5).Picture = LoadPicture(PR_Img1(Index))

End Sub

Private Sub Pachet_Click()

Compilare_CD.Text = ""

If UT_Variabile_Nume(0) = "" Then
MsgBox "In sectiunea UTILITARE nu a fost prezentat nici un program !" & vbCrLf & _
"Dupa introducerea datelor pentru prezentarea unui program trebuie apasat butonul " & _
Chr(34) & "Introdu datele in lista de setari" & Chr(34)
Master_Control.Tab = 0
Exit Sub
End If

If MM_Variabile_Nume(0) = "" Then
MsgBox "In sectiunea MULTIMEDIA nu a fost prezentat nici un program !" & vbCrLf & _
"Dupa introducerea datelor pentru prezentarea unui program trebuie apasat butonul " & _
Chr(34) & "Introdu datele in lista de setari" & Chr(34)
Master_Control.Tab = 1
Exit Sub
End If

If JC_Variabile_Nume(0) = "" Then
MsgBox "In sectiunea JOCURI nu a fost prezentat nici un program !" & vbCrLf & _
"Dupa introducerea datelor pentru prezentarea unui program trebuie apasat butonul " & _
Chr(34) & "Introdu datele in lista de setari" & Chr(34)
Master_Control.Tab = 2
Exit Sub
End If

If IN_Variabile_Nume(0) = "" Then
MsgBox "In sectiunea INTERNET nu a fost prezentat nici un program !" & vbCrLf & _
"Dupa introducerea datelor pentru prezentarea unui program trebuie apasat butonul " & _
Chr(34) & "Introdu datele in lista de setari" & Chr(34)
Master_Control.Tab = 3
Exit Sub
End If

If AV_Variabile_Nume(0) = "" Then
MsgBox "In sectiunea ANTIVIRUS nu a fost prezentat nici un program !" & vbCrLf & _
"Dupa introducerea datelor pentru prezentarea unui program trebuie apasat butonul " & _
Chr(34) & "Introdu datele in lista de setari" & Chr(34)
Master_Control.Tab = 4
Exit Sub
End If

If PR_Variabile_Nume(0) = "" Then
MsgBox "In sectiunea PERMANENTE nu a fost prezentat nici un program !" & vbCrLf & _
"Dupa introducerea datelor pentru prezentarea unui program trebuie apasat butonul " & _
Chr(34) & "Introdu datele in lista de setari" & Chr(34)
Master_Control.Tab = 5
Exit Sub
End If

If CaleFundalIntro.Text = "" Then
MsgBox "Trebuie sa alegi imaginea de fundal pentru sectiunea INTRO!" & vbCrLf & _
"Imaginea pentru reclama de care imi spuneai la telefon ! (desenezi un baner ... si il salvezi ca fisier GIF)"
Master_Control.Tab = 7
Exit Sub
End If

If CaleAjutor.Text = "" Then
MsgBox "Trebuie sa alegi imaginea de fundal pentru sectiunea Ajutor!"
Master_Control.Tab = 8
Exit Sub
End If

If Ar_text.Text = "" Then
MsgBox "Trebuie sa alegi fisierul XLS pentru arhiva PC World!"
Master_Control.Tab = 10
Exit Sub
End If

If cale_sunet.Text = "" Then
MsgBox "Trebuie sa alegi WAV-ul ciclic de fundal ! (melodia de fundal)"
Master_Control.Tab = 10
Exit Sub
End If

'evitarea caracterelor critice ca : |[]""''#

For vaca = 0 To 5

If InStr(Titlu(vaca).Text, "]") <> 0 Or InStr(Titlu(vaca).Text, "[") <> 0 Or InStr(Titlu(vaca).Text, Chr(39)) <> 0 Or InStr(Titlu(vaca).Text, Chr(34)) <> 0 Or InStr(Titlu(vaca).Text, "#") <> 0 Or InStr(Titlu(vaca).Text, "|") <> 0 Then
MsgBox "Caracterele: <|><[><]><#><" & Chr(39) & "><" & Chr(34) & "> sunt nepermise. " & vbCrLf & _
"Greseala este in sectiunea - " & sat(vaca) & ", la casuta " & Chr(34) & "Titlul programului prezentat" & Chr(34)
Master_Control.Tab = vaca
Titlu(vaca).BackColor = &HFF0000
Exit Sub
End If

If InStr(Explicatie(vaca).Text, "]") <> 0 Or InStr(Explicatie(vaca).Text, "[") <> 0 Or InStr(Explicatie(vaca).Text, Chr(39)) <> 0 Or InStr(Explicatie(vaca).Text, Chr(34)) <> 0 Or InStr(Explicatie(vaca).Text, "#") <> 0 Or InStr(Explicatie(vaca).Text, "|") <> 0 Then
MsgBox "Caracterele: <|><[><]><#><" & Chr(39) & "><" & Chr(34) & "> sunt nepermise. " & vbCrLf & _
"Greseala este in sectiunea - " & sat(vaca) & ", la casuta " & Chr(34) & "Expicatii despre programul prezentat" & Chr(34)
Explicatie(vaca).BackColor = &HFF0000
Master_Control.Tab = vaca
Exit Sub
End If

Next vaca

'***************************************************************************
'DRIVERE

For bulaD = 0 To 7
If DrivereTitlu(bulaD).Text <> "" Or DrivereExplicatii(bulaD).Text <> "" Or DrivereCale(bulaD).Text <> "" Then
GoTo este_una
Else

Master_Control.Tab = 9

DrivereExplicatii(bulaD).BackColor = 16711680
DrivereTitlu(bulaD).BackColor = 16711680
DrivereCale(bulaD).BackColor = 16711680

MsgBox "Trebuie sa completezi cel putin o casuta ! (adica interfata trebuie sa prezinte cel putin un driver)"
Exit Sub
End If
Next bulaD
este_una:

For bulaD = 0 To 7
If DrivereTitlu(bulaD).Text <> "" And DrivereExplicatii(bulaD).Text <> "" And DrivereCale(bulaD).Text = "" Then
Master_Control.Tab = 9
MsgBox "Pentru ca programul sa poata copia driver-ul in structura matritei trebuie sa introduci" & vbCrLf & _
"toate datele cerute intr-o casuta(nu trebuie lasata completata partial)"
DrivereCale(bulaD).BackColor = 16711680
Exit Sub
End If

If DrivereTitlu(bulaD).Text <> "" And DrivereExplicatii(bulaD).Text = "" And DrivereCale(bulaD).Text <> "" Then
Master_Control.Tab = 9
MsgBox "Pentru ca programul sa poata copia driver-ul in structura matritei trebuie sa introduci" & vbCrLf & _
"toate datele cerute intr-o casuta(nu trebuie lasata completata partial)"
DrivereExplicatii(bulaD).BackColor = 16711680
Exit Sub
End If


If DrivereTitlu(bulaD).Text = "" And DrivereExplicatii(bulaD).Text <> "" And DrivereCale(bulaD).Text <> "" Then
Master_Control.Tab = 9
MsgBox "Pentru ca programul sa poata copia driver-ul in structura matritei trebuie sa introduci" & vbCrLf & _
"toate datele cerute intr-o casuta(nu trebuie lasata completata partial)"
DrivereTitlu(bulaD).BackColor = 16711680
Exit Sub
End If


If DrivereTitlu(bulaD).Text <> "" And DrivereExplicatii(bulaD).Text = "" And DrivereCale(bulaD).Text = "" Then
Master_Control.Tab = 9
MsgBox "Pentru ca programul sa poata copia driver-ul in structura matritei trebuie sa introduci" & vbCrLf & _
"toate datele cerute intr-o casuta(nu trebuie lasata completata partial)"
DrivereExplicatii(bulaD).BackColor = 16711680
DrivereCale(bulaD).BackColor = 16711680
Exit Sub
End If


If DrivereTitlu(bulaD).Text = "" And DrivereExplicatii(bulaD).Text <> "" And DrivereCale(bulaD).Text = "" Then
Master_Control.Tab = 9
MsgBox "Pentru ca programul sa poata copia driver-ul in structura matritei trebuie sa introduci" & vbCrLf & _
"toate datele cerute intr-o casuta(nu trebuie lasata completata partial)"
DrivereTitlu(bulaD).BackColor = 16711680
DrivereCale(bulaD).BackColor = 16711680
Exit Sub
End If

If DrivereTitlu(bulaD).Text = "" And DrivereExplicatii(bulaD).Text = "" And DrivereCale(bulaD).Text <> "" Then
Master_Control.Tab = 9
MsgBox "Pentru ca programul sa poata copia driver-ul in structura matritei trebuie sa introduci" & vbCrLf & _
"toate datele cerute intr-o casuta(nu trebuie lasata completata partial)"
DrivereTitlu(bulaD).BackColor = 16711680
DrivereExplicatii(bulaD).BackColor = 16711680
Exit Sub
End If

DoEvents

Next bulaD


'***************************************************************************
Master_Control.Tab = 11

For ddsx = 0 To 10
Master_Control.TabEnabled(ddsx) = False
Next ddsx
' **************************** Titluri ***********************************************
For ffg = 0 To 18
If UT_Variabile_Nume(ffg) = "" Then
Else
lala_UT = lala_UT & vbCrLf & UT_Variabile_Nume(ffg)
lala_UT_E = lala_UT_E & vbCrLf & UT_Variabile_Explicatii(ffg)

End If
Next ffg
Sectiuni_meniu_final(0) = vbCrLf & "[UTILITARE]" & lala_UT & vbCrLf & "[UT-STOP]"
Sectiuni_explicatii_final(0) = "[UTILITARE-EXPLICATII]" & lala_UT_E & vbCrLf & "[UTILITARE-STOP]" & vbCrLf
Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Utilitare - titlul programului si explicatii = OK"

For ffg = 0 To 18
If MM_Variabile_Nume(ffg) = "" Then
Else
lala_MM = lala_MM & vbCrLf & MM_Variabile_Nume(ffg)
lala_MM_E = lala_MM_E & vbCrLf & MM_Variabile_Explicatii(ffg)
End If
Next ffg
Sectiuni_meniu_final(1) = vbCrLf & "[MULTIMEDIA]" & lala_MM & vbCrLf & "[MM-STOP]"
Sectiuni_explicatii_final(1) = "[MULTIMEDIA-EXPLICATII]" & lala_MM_E & vbCrLf & "[MULTIMEDIA-STOP]" & vbCrLf
Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Multimedia - titlul programului si explicatii = OK"

For ffg = 0 To 18
If JC_Variabile_Nume(ffg) = "" Then
Else
lala_JC = lala_JC & vbCrLf & JC_Variabile_Nume(ffg)
lala_JC_E = lala_JC_E & vbCrLf & JC_Variabile_Explicatii(ffg)
End If
Next ffg
Sectiuni_meniu_final(2) = vbCrLf & "[JOCURI]" & lala_JC & vbCrLf & "[JC-STOP]"
Sectiuni_explicatii_final(2) = "[JOCURI-EXPLICATII]" & lala_JC_E & vbCrLf & "[JOCURI-STOP]" & vbCrLf
Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Jocuri - titlul programului si explicatii = OK"


For ffg = 0 To 18
If IN_Variabile_Nume(ffg) = "" Then
Else
lala_IN = lala_IN & vbCrLf & IN_Variabile_Nume(ffg)
lala_IN_E = lala_IN_E & vbCrLf & IN_Variabile_Explicatii(ffg)
End If
Next ffg
Sectiuni_meniu_final(3) = vbCrLf & "[INTERNET]" & lala_IN & vbCrLf & "[IN-STOP]"
Sectiuni_explicatii_final(3) = "[INTERNET-EXPLICATII]" & lala_IN_E & vbCrLf & "[INTERNET-STOP]" & vbCrLf
Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Internet - titlul programului si explicatii = OK"


For ffg = 0 To 18
If AV_Variabile_Nume(ffg) = "" Then
Else
lala_AV = lala_AV & vbCrLf & AV_Variabile_Nume(ffg)
lala_AV_E = lala_AV_E & vbCrLf & AV_Variabile_Explicatii(ffg)
End If
Next ffg
Sectiuni_meniu_final(4) = vbCrLf & "[ANTIVIRUS]" & lala_AV & vbCrLf & "[AV-STOP]"
Sectiuni_explicatii_final(4) = "[ANTIVIRUS-EXPLICATII]" & lala_AV_E & vbCrLf & "[ANTIVIRUS-STOP]" & vbCrLf
Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Antivirus - titlul programului si explicatii = OK"


For ffg = 0 To 18
If PR_Variabile_Nume(ffg) = "" Then
Else
lala_PR = lala_PR & vbCrLf & PR_Variabile_Nume(ffg)
lala_PR_E = lala_PR_E & vbCrLf & PR_Variabile_Explicatii(ffg)
End If
Next ffg
Sectiuni_meniu_final(5) = vbCrLf & "[PERMANENTE]" & lala_PR & vbCrLf & "[PR-STOP]"
Sectiuni_explicatii_final(5) = "[PERMANENTE-EXPLICATII]" & lala_PR_E & vbCrLf & "[PERMANENTE-STOP]"
Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Permanente - titlul programului si explicatii = OK"

'*********************************  explicatii  **********************************************

Radacina_cap = "***** Copyright by Paul Gagniuc *****" & vbCrLf & "[MENIURI]"
Radacina_mijloc = vbCrLf & "[MENIURI-STOP]" & vbCrLf & "[Rupere-de-nori]" & vbCrLf
Radacina_coada = vbCrLf & "[Rupere-de-nori-STOP]"

For rrt = 0 To 5 '6
Meniuri_general = Meniuri_general & Sectiuni_meniu_final(rrt)
Next rrt

For rrt = 0 To 5 '6
Explicatii_general = Explicatii_general & Sectiuni_explicatii_final(rrt)
Next rrt

Partea1 = Radacina_cap & Meniuri_general & Radacina_mijloc
Partea2 = Explicatii_general & Radacina_coada

Gata_Tataie = Partea1 & Partea2

Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Imbinare si generare structuri ..."
'MsgBox Gata_Tataie
director (Cale_matrita.Text & "\Matrita")
director (Cale_matrita.Text & "\Matrita\PC_World")

ff = FreeFile
Open App.Path & "\Geneza\biohazard.zulu" For Output As #ff
Print #ff, Gata_Tataie
Close #ff

Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "biohazard.zulu a fost generat si copiat !"

'revista
ff = FreeFile
Open App.Path & "\Geneza\Revista.htm" For Output As #ff
Print #ff, revista1.Text & vbCrLf & Revista & vbCrLf & revista2.Text
Close #ff

'Intro
ff = FreeFile
Open App.Path & "\Geneza\Intrare.htm" For Output As #ff
lalala1 = "<DIV id=cade style=" & Chr(34) & "BACKGROUND-COLOR: #" & culoare.Text & "; HEIGHT:" & Inaltime.Text & _
"px; LEFT: 126px; POSITION: absolute; TOP: 100px; VISIBILITY: hidden;WIDTH:" & latime.Text & "px" & Chr(34) & ">"


lalala2 = "</DIV></tr></td></table>"

lala3 = "<table border=" & Chr(34) & borduraG.Text & Chr(34) & " cellpadding=" & Chr(34) & "0" & _
Chr(34) & " cellspacing=" & Chr(34) & "0" & Chr(34) & " style=" & Chr(34) & _
"border-collapse: collapse" & Chr(34) & " width=" & Chr(34) & "100%" & Chr(34) & _
" height=" & Chr(34) & "100%" & Chr(34) & "><tr><td valign=top align=right " & _
"width=" & Chr(34) & "100%" & Chr(34) & " background=" & Chr(34) & _
CaleFundalIntro.Text & Chr(34) & "height=100%><button onclick=" & Chr(34) & _
"Hai_Pa();return false" & Chr(34) & " style=" & Chr(34) & "height:20;width:20" & Chr(34) & _
"><FONT color=" & Chr(34) & "000000" & Chr(34) & " face=Arial size=1>x</FONT></button>"

proces = Proceseaza(Intro.Text)
Print #ff, Intro1.Text & vbCrLf & proces & vbCrLf & Intro2.Text & lalala1 & lala3 & Intro3.Text & lalala2
Close #ff

'Ajutor
ff = FreeFile
Open App.Path & "\Geneza\Ajutor.htm" For Output As #ff

xxl = Proceseaza(Ajutor.Text)
xx1 = "<body bgcolor=white background=" & Chr(34) & CaleAjutor.Text & Chr(34) & "><font size=" & Chr(34) & FontMarime.Text & Chr(34) & " face=" & Chr(34) & Fontul.Text & Chr(34) & " color=" & Chr(34) & "#" & FontCuloare.Text & Chr(34) & ">"

Print #ff, Ajutor1.Text & vbCrLf & xx1 & xxl & "</FONT>"
Close #ff

'Driver
ff = FreeFile
Open App.Path & "\Geneza\Drivere.htm" For Output As #ff

d333 = "<body scroll=no bgcolor=#ffffff background=" & Chr(34) & "IMG\fundal7.jpg" & Chr(34) & ">"
d222 = "<center><FONT style=" & Chr(34) & "font-family:Time New Roman;face:Time New Roman" & Chr(34) & " size=" & Chr(34) & "10" & Chr(34) & " color=#ffffff> Drivere </FONT><br><br></center>"

capulZulu = d333 & d222 & "<table border=" & Chr(34) & "0" & Chr(34) & " cellpadding=" & Chr(34) & "0" & Chr(34) & " cellspacing=" & Chr(34) & "0" & Chr(34) & " style=" & Chr(34) & "border-collapse:collapse" & Chr(34) & " width=" & Chr(34) & "100%" & Chr(34) & " id=" & Chr(34) & "Eu" & Chr(34) & ">"

bulaD = 0
For tt = 1 To 4
capulZulu = capulZulu & "<tr>"

For vv = 1 To 2
If DrivereTitlu(bulaD).Text = "" And DrivereExplicatii(bulaD).Text = "" And DrivereCale(bulaD).Text = "" Then
GoTo nimic
End If

capulZulu = capulZulu & "<td width=" & Chr(34) & "50%" & Chr(34) & " onmouseout=" & Chr(34) & "sterge()" & Chr(34) & "onmouseover=" & Chr(34) & "arata(" & Chr(39) & DrivereExplicatii(bulaD).Text & Chr(39) & ")" & Chr(34) & ">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"

capulZulu = capulZulu & "<a href=" & Chr(34) & DrivereCale(bulaD).Text & Chr(34) & _
" style=" & Chr(34) & "text-decoration:none" & Chr(34) & ">"

capulZulu = capulZulu & "<font size=" & Chr(34) & D_FontMarime.Text & Chr(34) & " face=" & _
Chr(34) & D_Font.Text & Chr(34) & " color=" & Chr(34) & "#" & D_FontCuloare.Text & Chr(34) & _
"><img src=" & Chr(34) & "IMG\pc2.GIF" & Chr(34) & " border=" & Chr(34) & "0" & _
Chr(34) & ">" & DrivereTitlu(bulaD).Text & "</font></a>"

capulZulu = capulZulu & "</td>"

nimic:
bulaD = bulaD + 1
Next vv
capulZulu = capulZulu & "</tr>"
Next tt

InPlus = "<font size=" & Chr(34) & EX_FontMarime.Text & Chr(34) & " face=" & Chr(34) & EX_Font.Text & Chr(34) & " color=" & Chr(34) & "#" & EX_FontCuloare.Text & Chr(34) & "><div align=left valign=top Id=" & Chr(34) & "CutiaNeagra" & Chr(34) & " style=" & Chr(34) & "position:absolute;top:13;left:20;width:100%;overflow:auto;height:50px" & Chr(34) & "></div></font>"

Print #ff, drivere1.Text & vbCrLf & capulZulu & Drivere & InPlus & vbCrLf & drivere2.Text
Close #ff

Call Fa_directoare

Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Structura matritei a fost COMPILATA !!!"
Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Bine-mi pare, in gradina am o floare ..."
Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "GATA !!!"

For ddsx = 0 To 10
Master_Control.TabEnabled(ddsx) = True
Next ddsx

End Sub

Function director(ByVal yo As String)
DoEvents
MkDir (yo)
DoEvents
End Function

Function Fa_directoare()
Dim Miracol(0 To 20) As String
Dim Misiune(1 To 3) As String

Miracol(0) = "UT"
Miracol(1) = "MM"
Miracol(2) = "JC"
Miracol(3) = "IN"
Miracol(4) = "AV"
Miracol(5) = "PR"

Miracol(6) = "Kit"
Miracol(7) = "Negativ"
Miracol(8) = "IMG"


Misiune(1) = "Kit"
Misiune(2) = "_Instalare"
Misiune(3) = "_Rulare"

Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Este creata structura de directoare ..."

director (Cale_matrita.Text & "\Matrita\PC_World\aferent")
director (Cale_matrita.Text & "\Matrita\PC_World\aferent\Drivere")
director (Cale_matrita.Text & "\Matrita\PC_World\aferent\Revista")

For dirr = 0 To 8
director (Cale_matrita.Text & "\Matrita\PC_World\aferent\" & Miracol(dirr))
Next dirr

For dirr = 0 To 5
director (Cale_matrita.Text & "\Matrita\PC_World\aferent\Kit\" & Miracol(dirr))

' rindurile de mai jos ar trebui sa fie mai sus la 1 to 8

If Miracol(dirr) = "UT" Then
On Error GoTo zuluAlfa
director (Cale_matrita.Text & "\Matrita\PC_World\aferent\UT\img")
zuluAlfa:

ggg = 0
Do While UT_Variabile_Nume(ggg) <> ""
FileCopy UT_Img1(ggg), Cale_matrita.Text & "\Matrita\PC_World\aferent\UT\" & ggg & ".gif"
FileCopy UT_Img2(ggg), Cale_matrita.Text & "\Matrita\PC_World\aferent\UT\img\" & ggg & ".gif"
ggg = ggg + 1
Loop
Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Copiez capturi - utilitare"
End If

If Miracol(dirr) = "MM" Then
On Error GoTo zuluAlfa2
director (Cale_matrita.Text & "\Matrita\PC_World\aferent\MM\img")
zuluAlfa2:
ggg = 0
Do While MM_Variabile_Nume(ggg) <> ""
FileCopy MM_Img1(ggg), Cale_matrita.Text & "\Matrita\PC_World\aferent\MM\" & ggg & ".gif"
FileCopy MM_Img2(ggg), Cale_matrita.Text & "\Matrita\PC_World\aferent\MM\img\" & ggg & ".gif"
ggg = ggg + 1
Loop
Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Copiez capturi - multimedia"
End If

If Miracol(dirr) = "JC" Then
On Error GoTo zuluAlfa3
director (Cale_matrita.Text & "\Matrita\PC_World\aferent\JC\img")
zuluAlfa3:

ggg = 0
Do While JC_Variabile_Nume(ggg) <> ""
FileCopy JC_Img1(ggg), Cale_matrita.Text & "\Matrita\PC_World\aferent\JC\" & ggg & ".gif"
FileCopy JC_Img2(ggg), Cale_matrita.Text & "\Matrita\PC_World\aferent\JC\img\" & ggg & ".gif"

ggg = ggg + 1
Loop
Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Copiez capturi - jocuri"
End If

If Miracol(dirr) = "IN" Then
On Error GoTo zuluAlfa4
director (Cale_matrita.Text & "\Matrita\PC_World\aferent\IN\img")
zuluAlfa4:
ggg = 0
Do While IN_Variabile_Nume(ggg) <> ""
FileCopy IN_Img1(ggg), Cale_matrita.Text & "\Matrita\PC_World\aferent\IN\" & ggg & ".gif"
FileCopy IN_Img2(ggg), Cale_matrita.Text & "\Matrita\PC_World\aferent\IN\img\" & ggg & ".gif"

ggg = ggg + 1
Loop
Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Copiez capturi - internet"
End If

If Miracol(dirr) = "AV" Then
On Error GoTo zuluAlfa5
director (Cale_matrita.Text & "\Matrita\PC_World\aferent\AV\img")
zuluAlfa5:
ggg = 0
Do While AV_Variabile_Nume(ggg) <> ""
FileCopy AV_Img1(ggg), Cale_matrita.Text & "\Matrita\PC_World\aferent\AV\" & ggg & ".gif"
FileCopy AV_Img2(ggg), Cale_matrita.Text & "\Matrita\PC_World\aferent\AV\img\" & ggg & ".gif"

ggg = ggg + 1
Loop
Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Copiez capturi - antivirus"
End If


If Miracol(dirr) = "PR" Then
On Error GoTo zuluAlfa6
director (Cale_matrita.Text & "\Matrita\PC_World\aferent\PR\img")
zuluAlfa6:
ggg = 0
Do While PR_Variabile_Nume(ggg) <> ""
FileCopy PR_Img1(ggg), Cale_matrita.Text & "\Matrita\PC_World\aferent\PR\" & ggg & ".gif"
FileCopy PR_Img2(ggg), Cale_matrita.Text & "\Matrita\PC_World\aferent\PR\img\" & ggg & ".gif"

ggg = ggg + 1
Loop
Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Copiez capturi - permanente"
End If
'************************************************************************************************

'If dirr = 0 Then
'ggg = 1
'Do While UT_Variabile_Nume(ggg) <> ""
'ggg = ggg + 1
'Loop
'If ggg >= 18 Then
'Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Maxim 18 programe/sectiune"
'Exit Function
'End If
'End If

'If dirr = 1 Then
'ggg = 0
'Do While MM_Variabile_Nume(ggg) <> ""
'ggg = ggg + 1
'Loop
'If ggg >= 18 Then
'Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Maxim 18 programe/sectiune"
'Exit Function
'End If
'End If

'If dirr = 2 Then
'ggg = 0
'Do While JC_Variabile_Nume(ggg) <> ""
'ggg = ggg + 1
'Loop
'If ggg >= 18 Then
'Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Maxim 18 programe/sectiune"
'Exit Function
'End If
'End If

'If dirr = 3 Then
'ggg = 0
'Do While IN_Variabile_Nume(ggg) <> ""
'ggg = ggg + 1
'Loop
'If ggg >= 18 Then
'Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Maxim 18 programe/sectiune"
'Exit Function
'End If
'End If

'If dirr = 4 Then
'ggg = 0
'Do While AV_Variabile_Nume(ggg) <> ""
'ggg = ggg + 1
'Loop
'If ggg >= 18 Then
'Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Maxim 18 programe/sectiune"
'Exit Function
'End If
'End If

'If dirr = 5 Then
'ggg = 0
'Do While PR_Variabile_Nume(ggg) <> ""
'ggg = ggg + 1
'Loop

'If ggg >= 18 Then
'Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Maxim 18 programe/sectiune"
'Exit Function
'End If
'End If
'jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj
For dirr1 = 0 To 18 'ggg
director (Cale_matrita.Text & "\Matrita\PC_World\aferent\Kit\" & Miracol(dirr) & "\" & dirr1)

For dirr2 = 1 To 3
If dirr2 = 1 Then
director (Cale_matrita.Text & "\Matrita\PC_World\aferent\Kit\" & Miracol(dirr) & "\" & dirr1 & "\" & Misiune(dirr2))


If Miracol(dirr) = "UT" Then
If UT_Citeste_ma(dirr1) <> "" Then
Call ScrieIn(Cale_matrita.Text & "\Matrita\PC_World\aferent\Kit\" & Miracol(dirr) & "\" & dirr1 & "\Citeste_ma.txt", UT_Citeste_ma(dirr1))

If UT_KitZip(dirr1) <> "" Then
FileCopy UT_KitZip(dirr1), Cale_matrita.Text & "\Matrita\PC_World\aferent\Kit\" & Miracol(dirr) & "\" & dirr1 & "\" & Misiune(dirr2) & "\Kit.zip"
End If

End If
End If

If Miracol(dirr) = "MM" Then
If MM_Citeste_ma(dirr1) <> "" Then
Call ScrieIn(Cale_matrita.Text & "\Matrita\PC_World\aferent\Kit\" & Miracol(dirr) & "\" & dirr1 & "\Citeste_ma.txt", MM_Citeste_ma(dirr1))

If MM_KitZip(dirr1) <> "" Then
FileCopy MM_KitZip(dirr1), Cale_matrita.Text & "\Matrita\PC_World\aferent\Kit\" & Miracol(dirr) & "\" & dirr1 & "\" & Misiune(dirr2) & "\Kit.zip"
End If

End If
End If

If Miracol(dirr) = "JC" Then
If JC_Citeste_ma(dirr1) <> "" Then
Call ScrieIn(Cale_matrita.Text & "\Matrita\PC_World\aferent\Kit\" & Miracol(dirr) & "\" & dirr1 & "\Citeste_ma.txt", JC_Citeste_ma(dirr1))

If JC_KitZip(dirr1) <> "" Then
FileCopy JC_KitZip(dirr1), Cale_matrita.Text & "\Matrita\PC_World\aferent\Kit\" & Miracol(dirr) & "\" & dirr1 & "\" & Misiune(dirr2) & "\Kit.zip"
End If

End If
End If

If Miracol(dirr) = "IN" Then
If IN_Citeste_ma(dirr1) <> "" Then
Call ScrieIn(Cale_matrita.Text & "\Matrita\PC_World\aferent\Kit\" & Miracol(dirr) & "\" & dirr1 & "\Citeste_ma.txt", IN_Citeste_ma(dirr1))

If IN_KitZip(dirr1) <> "" Then
FileCopy IN_KitZip(dirr1), Cale_matrita.Text & "\Matrita\PC_World\aferent\Kit\" & Miracol(dirr) & "\" & dirr1 & "\" & Misiune(dirr2) & "\Kit.zip"
End If

End If
End If


If Miracol(dirr) = "AV" Then
If AV_Citeste_ma(dirr1) <> "" Then
Call ScrieIn(Cale_matrita.Text & "\Matrita\PC_World\aferent\Kit\" & Miracol(dirr) & "\" & dirr1 & "\Citeste_ma.txt", AV_Citeste_ma(dirr1))

If AV_KitZip(dirr1) <> "" Then
FileCopy AV_KitZip(dirr1), Cale_matrita.Text & "\Matrita\PC_World\aferent\Kit\" & Miracol(dirr) & "\" & dirr1 & "\" & Misiune(dirr2) & "\Kit.zip"
End If

End If
End If

If Miracol(dirr) = "PR" Then
If PR_Citeste_ma(dirr1) <> "" Then
Call ScrieIn(Cale_matrita.Text & "\Matrita\PC_World\aferent\Kit\" & Miracol(dirr) & "\" & dirr1 & "\Citeste_ma.txt", PR_Citeste_ma(dirr1))

If PR_KitZip(dirr1) <> "" Then
FileCopy PR_KitZip(dirr1), Cale_matrita.Text & "\Matrita\PC_World\aferent\Kit\" & Miracol(dirr) & "\" & dirr1 & "\" & Misiune(dirr2) & "\Kit.zip"
End If

End If
End If


Else
'MsgBox App.Path & "\aferent\Kit\" & Miracol(dirr) & "\" & dirr1 & "\" & dirr1 & Misiune(dirr2)
director (Cale_matrita.Text & "\Matrita\PC_World\aferent\Kit\" & Miracol(dirr) & "\" & dirr1 & "\" & dirr1 & Misiune(dirr2))


If dirr2 = 2 Then


If Miracol(dirr) = "UT" Then

If UT_Kit(dirr1) <> "" Then
FileCopy UT_Kit(dirr1), Cale_matrita.Text & "\Matrita\PC_World\aferent\Kit\" & Miracol(dirr) & "\" & dirr1 & "\" & dirr1 & Misiune(dirr2) & "\setup.exe"
End If

End If

If Miracol(dirr) = "MM" Then

If MM_Kit(dirr1) <> "" Then
FileCopy MM_Kit(dirr1), Cale_matrita.Text & "\Matrita\PC_World\aferent\Kit\" & Miracol(dirr) & "\" & dirr1 & "\" & dirr1 & Misiune(dirr2) & "\setup.exe"
End If

End If

If Miracol(dirr) = "JC" Then

If JC_Kit(dirr1) <> "" Then
FileCopy JC_Kit(dirr1), Cale_matrita.Text & "\Matrita\PC_World\aferent\Kit\" & Miracol(dirr) & "\" & dirr1 & "\" & dirr1 & Misiune(dirr2) & "\setup.exe"
End If

End If

If Miracol(dirr) = "IN" Then

If IN_Kit(dirr1) <> "" Then
FileCopy IN_Kit(dirr1), Cale_matrita.Text & "\Matrita\PC_World\aferent\Kit\" & Miracol(dirr) & "\" & dirr1 & "\" & dirr1 & Misiune(dirr2) & "\setup.exe"
End If

End If


If Miracol(dirr) = "AV" Then

If AV_Kit(dirr1) <> "" Then
FileCopy AV_Kit(dirr1), Cale_matrita.Text & "\Matrita\PC_World\aferent\Kit\" & Miracol(dirr) & "\" & dirr1 & "\" & dirr1 & Misiune(dirr2) & "\setup.exe"
End If

End If

If Miracol(dirr) = "PR" Then

If PR_Kit(dirr1) <> "" Then
FileCopy PR_Kit(dirr1), Cale_matrita.Text & "\Matrita\PC_World\aferent\Kit\" & Miracol(dirr) & "\" & dirr1 & "\" & dirr1 & Misiune(dirr2) & "\setup.exe"
End If

End If

End If ' de la dirr2 = 2




End If ' terminarea de la dirr2 = 1
Next dirr2


Next dirr1
Next dirr

Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Structura directoare = OK"
Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Copiere capturi = OK"
'Aici se umple fiecare director ... cu fisiere

director (Cale_matrita.Text & "\Matrita\PC_World\aferent\Negativ\voce")

Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Incepe copierea fisiere dinamice."
DoEvents
FileCopy App.Path & "\Geneza\biohazard.zulu", Cale_matrita.Text & "\Matrita\PC_World\aferent\biohazard.zulu"
FileCopy App.Path & "\Geneza\PC.ico", Cale_matrita.Text & "\Matrita\PC_World\aferent\PC.ico"

FileCopy App.Path & "\Geneza\Ajutor.htm", Cale_matrita.Text & "\Matrita\PC_World\aferent\Ajutor.htm"
FileCopy App.Path & "\Geneza\Intrare.htm", Cale_matrita.Text & "\Matrita\PC_World\aferent\Intrare.htm"
FileCopy App.Path & "\Geneza\Revista.htm", Cale_matrita.Text & "\Matrita\PC_World\aferent\Revista.htm"
FileCopy App.Path & "\Geneza\Drivere.htm", Cale_matrita.Text & "\Matrita\PC_World\aferent\Drivere.htm"
FileCopy App.Path & "\Geneza\Internet.htm", Cale_matrita.Text & "\Matrita\PC_World\aferent\Internet.htm"

FileCopy App.Path & "\Geneza\Cruce.ani", Cale_matrita.Text & "\Matrita\PC_World\aferent\Cruce.ani"
DoEvents

FileCopy App.Path & "\Geneza\IMG\fundal4.jpg", Cale_matrita.Text & "\Matrita\PC_World\aferent\IMG\fundal4.jpg"

'8888888888888888888888888888888888888888888888888888888888888888888888888888888888
FileCopy D_Cale_text.Text, Cale_matrita.Text & "\Matrita\PC_World\aferent\IMG\fundal7.jpg"
'8888888888888888888888888888888888888888888888888888888888888888888888888888888888

FileCopy App.Path & "\Geneza\IMG\fundal.jpg", Cale_matrita.Text & "\Matrita\PC_World\aferent\IMG\fundal.jpg"
FileCopy App.Path & "\Geneza\IMG\fundal-c.gif", Cale_matrita.Text & "\Matrita\PC_World\aferent\IMG\fundal-c.gif"
FileCopy App.Path & "\Geneza\IMG\pc.gif", Cale_matrita.Text & "\Matrita\PC_World\aferent\IMG\pc.gif"
FileCopy App.Path & "\Geneza\IMG\revista.gif", Cale_matrita.Text & "\Matrita\PC_World\aferent\IMG\revista.gif"
FileCopy App.Path & "\Geneza\IMG\wallpaper.bmp", Cale_matrita.Text & "\Matrita\PC_World\aferent\IMG\wallpaper.bmp"
FileCopy App.Path & "\Geneza\IMG\pc2.GIF", Cale_matrita.Text & "\Matrita\PC_World\aferent\IMG\pc2.GIF"
FileCopy CaleFundalIntro.Text, Cale_matrita.Text & "\Matrita\PC_World\aferent\IMG\fundal_reclama.gif"

For xxc = 0 To 7

If DrivereCale(xxc).Text = "" Then
'Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Kit-ul driver-ului " & DrivereTitlu(xxc).Text & " nu poate fi copiat !"
GoTo xxzulu
End If

FileCopy DrivereCale(xxc).Text, Cale_matrita.Text & "\Matrita\PC_World\aferent\Drivere\" & numeDriver(xxc)
xxzulu:
Next xxc

FileCopy App.Path & "\Geneza\Negativ\Negativ.GIF", Cale_matrita.Text & "\Matrita\PC_World\aferent\Negativ\Negativ.GIF"
FileCopy App.Path & "\Geneza\Negativ\fundal.gif", Cale_matrita.Text & "\Matrita\PC_World\aferent\Negativ\fundal.gif"
FileCopy App.Path & "\Geneza\Negativ\cafeluta.gif", Cale_matrita.Text & "\Matrita\PC_World\aferent\Negativ\cafeluta.gif"
FileCopy App.Path & "\Geneza\Negativ\nimic.htm", Cale_matrita.Text & "\Matrita\PC_World\aferent\Negativ\nimic.htm"
FileCopy App.Path & "\Geneza\Negativ\S0.htm", Cale_matrita.Text & "\Matrita\PC_World\aferent\Negativ\S0.htm"
FileCopy App.Path & "\Geneza\Negativ\S1.htm", Cale_matrita.Text & "\Matrita\PC_World\aferent\Negativ\S1.htm"
FileCopy App.Path & "\Geneza\Negativ\Voce1.htm", Cale_matrita.Text & "\Matrita\PC_World\aferent\Negativ\Voce1.htm"
FileCopy App.Path & "\Geneza\Negativ\Voce2.htm", Cale_matrita.Text & "\Matrita\PC_World\aferent\Negativ\Voce2.htm"

Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Fisierele dinamice au fost copiate."
DoEvents
Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Incepe copierea fisierelor audio."
DoEvents
FileCopy App.Path & "\Geneza\Negativ\Revista.wav", Cale_matrita.Text & "\Matrita\PC_World\aferent\Negativ\Revista.wav"
FileCopy App.Path & "\Geneza\Negativ\Buton.wav", Cale_matrita.Text & "\Matrita\PC_World\aferent\Negativ\Buton.wav"
FileCopy App.Path & "\Geneza\Negativ\Negativ.wav", Cale_matrita.Text & "\Matrita\PC_World\aferent\Negativ\Negativ.wav"

If cale_sunet.Text = "" Then
FileCopy App.Path & "\Geneza\Negativ\S_fundal.wav", Cale_matrita.Text & "\Matrita\PC_World\aferent\Negativ\S_fundal.wav"
Else
FileCopy cale_sunet.Text, Cale_matrita.Text & "\Matrita\PC_World\aferent\Negativ\S_fundal.wav"
End If


FileCopy App.Path & "\Geneza\Negativ\ScurtCircuit.wav", Cale_matrita.Text & "\Matrita\PC_World\aferent\Negativ\ScurtCircuit.wav"

FileCopy App.Path & "\Geneza\Negativ\voce\afara.wav", Cale_matrita.Text & "\Matrita\PC_World\aferent\Negativ\voce\afara.wav"
FileCopy App.Path & "\Geneza\Negativ\voce\apasa.WAV", Cale_matrita.Text & "\Matrita\PC_World\aferent\Negativ\voce\apasa.WAV"
FileCopy App.Path & "\Geneza\Negativ\voce\citeste.wav", Cale_matrita.Text & "\Matrita\PC_World\aferent\Negativ\voce\citeste.wav"
FileCopy App.Path & "\Geneza\Negativ\voce\copiaza_in.wav", Cale_matrita.Text & "\Matrita\PC_World\aferent\Negativ\voce\copiaza_in.wav"
FileCopy App.Path & "\Geneza\Negativ\voce\copiere.wav", Cale_matrita.Text & "\Matrita\PC_World\aferent\Negativ\voce\copiere.wav"
FileCopy App.Path & "\Geneza\Negativ\voce\Eu.wav", Cale_matrita.Text & "\Matrita\PC_World\aferent\Negativ\voce\Eu.wav"
FileCopy App.Path & "\Geneza\Negativ\voce\instalare.wav", Cale_matrita.Text & "\Matrita\PC_World\aferent\Negativ\voce\instalare.wav"
FileCopy App.Path & "\Geneza\Negativ\voce\rulare.wav", Cale_matrita.Text & "\Matrita\PC_World\aferent\Negativ\voce\rulare.wav"
DoEvents
Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Copierea fisierelor audio a fost facuta."
Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Incepe copierea fisierelor de dependenta."

FileCopy App.Path & "\Geneza\dep\B074000D.TTF", Cale_matrita.Text & "\Matrita\PC_World\B074000D.TTF"
FileCopy App.Path & "\Geneza\dep\G034000D.TTF", Cale_matrita.Text & "\Matrita\PC_World\G034000D.TTF"
FileCopy App.Path & "\Geneza\dep\olepro32.dll", Cale_matrita.Text & "\Matrita\PC_World\olepro32.dll"
FileCopy App.Path & "\Geneza\dep\VBA6.DLL", Cale_matrita.Text & "\Matrita\PC_World\VBA6.DLL"
FileCopy App.Path & "\Geneza\dep\msvbvm60.dll", Cale_matrita.Text & "\Matrita\PC_World\msvbvm60.dll"
FileCopy App.Path & "\Geneza\dep\shdocvw.dll", Cale_matrita.Text & "\Matrita\PC_World\shdocvw.dll"
FileCopy App.Path & "\Geneza\dep\winmm.dll", Cale_matrita.Text & "\Matrita\PC_World\winmm.dll"
FileCopy Ar_text.Text, Cale_matrita.Text & "\Matrita\PC_World\arhiva.xls"

DoEvents
Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Copierea fisierelor de dependenta a fost facuta."
DoEvents
Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Incepe copierea aplicatiei."
FileCopy App.Path & "\Geneza\CD.exe", Cale_matrita.Text & "\Matrita\PC_World\CD.exe"
Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Copierea aplicatiei a fost facuta."
FileCopy App.Path & "\Geneza\AUTORUN.INF", Cale_matrita.Text & "\Matrita\AUTORUN.INF"
Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "AUTORUN.INF a fost generat."

End Function

Function ScrieIn(ByVal cale As String, ByVal info As String)
ff = FreeFile
Open cale For Output As #ff
Print #ff, info
Close #ff

End Function

Private Sub Sterge_Click(Index As Integer)
'Public UT_Variabile_Nume(0 To 18) As String
'Public UT_Variabile_Explicatii(0 To 18) As String
'Public UT_Citeste_ma(0 To 18) As String

'Public UT_KitZip(0 To 18) As String
'Public UT_Kit(0 To 18) As String

'Public UT_Img1(0 To 18) As String
'Public UT_Img2(0 To 18) As String

'Public temp_KitZip(0 To 5) As String
'Public temp_Kit(0 To 5) As String
If Index = 0 Then
For vacuum = 0 To 17
UT_Variabile_Nume(vacuum) = Empty
UT_Variabile_Explicatii(vacuum) = Empty
UT_Citeste_ma(vacuum) = Empty
UT_KitZip(vacuum) = Empty
UT_Kit(vacuum) = Empty
UT_Img1(vacuum) = Empty
UT_Img2(vacuum) = Empty
ListaMare(vacuum).Caption = Empty
Next vacuum
End If


If Index = 1 Then
For vacuum = 0 To 17
MM_Variabile_Nume(vacuum) = Empty
MM_Variabile_Explicatii(vacuum) = Empty
MM_Citeste_ma(vacuum) = Empty
MM_KitZip(vacuum) = Empty
MM_Kit(vacuum) = Empty
MM_Img1(vacuum) = Empty
MM_Img2(vacuum) = Empty
ListaMareMM(vacuum).Caption = Empty
Next vacuum
End If

If Index = 2 Then
For vacuum = 0 To 17
JC_Variabile_Nume(vacuum) = Empty
JC_Variabile_Explicatii(vacuum) = Empty
JC_Citeste_ma(vacuum) = Empty
JC_KitZip(vacuum) = Empty
JC_Kit(vacuum) = Empty
JC_Img1(vacuum) = Empty
JC_Img2(vacuum) = Empty
ListaMareJC(vacuum).Caption = Empty
Next vacuum
End If


If Index = 3 Then
For vacuum = 0 To 17
IN_Variabile_Nume(vacuum) = Empty
IN_Variabile_Explicatii(vacuum) = Empty
IN_Citeste_ma(vacuum) = Empty
IN_KitZip(vacuum) = Empty
IN_Kit(vacuum) = Empty
IN_Img1(vacuum) = Empty
IN_Img2(vacuum) = Empty
ListaMareIN(vacuum).Caption = Empty
Next vacuum
End If

If Index = 4 Then
For vacuum = 0 To 17
AV_Variabile_Nume(vacuum) = Empty
AV_Variabile_Explicatii(vacuum) = Empty
AV_Citeste_ma(vacuum) = Empty
AV_KitZip(vacuum) = Empty
AV_Kit(vacuum) = Empty
AV_Img1(vacuum) = Empty
AV_Img2(vacuum) = Empty
ListaMareAV(vacuum).Caption = Empty
Next vacuum
End If


If Index = 5 Then
For vacuum = 0 To 17
PR_Variabile_Nume(vacuum) = Empty
PR_Variabile_Explicatii(vacuum) = Empty
PR_Citeste_ma(vacuum) = Empty
PR_KitZip(vacuum) = Empty
PR_Kit(vacuum) = Empty
PR_Img1(vacuum) = Empty
PR_Img2(vacuum) = Empty
ListaMarePR(vacuum).Caption = Empty
Next vacuum
End If

Titlu(Index).Text = ""
Explicatie(Index).Text = ""
Citeste_Text(Index).Text = ""
IMica(Index).Text = ""
IMare(Index).Text = ""
calea(Index).Text = ""
cale2(Index).Text = ""

End Sub

Private Sub StergeDriver_Click()
For fgh = 0 To 7
DrivereTitlu(fgh).Text = ""
DrivereCale(fgh).Text = ""
DrivereExplicatii(fgh).Text = ""


DrivereTitlu(fgh).BackColor = &H0&
DrivereCale(fgh).BackColor = &H0&
DrivereExplicatii(fgh).BackColor = &H0&

Next fgh
End Sub

Private Sub sunetul_Click()
On Error GoTo aa
sunetEu.Filter = "Fisiere wav (*.wav)|*.wav"
sunetEu.ShowOpen
cale_sunet.Text = sunetEu.Filename
aa:
End Sub

Private Sub Titlu_GotFocus(Index As Integer)
Titlu(Index).BackColor = &H0&
End Sub
