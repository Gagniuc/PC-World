Attribute VB_Name = "Functii"
Option Explicit
Public Declare Function BitBlt Lib "gdi32" (ByVal hDestDC As Long, ByVal x As Long, ByVal y As Long, ByVal nWidth As Long, ByVal nHeight As Long, ByVal hSrcDC As Long, ByVal xSrc As Long, ByVal ySrc As Long, ByVal dwRop As Long) As Long
Public Declare Function StretchBlt Lib "gdi32" (ByVal hDC As Long, ByVal x As Long, ByVal y As Long, ByVal nWidth As Long, ByVal nHeight As Long, ByVal hSrcDC As Long, ByVal xSrc As Long, ByVal ySrc As Long, ByVal nSrcWidth As Long, ByVal nSrcHeight As Long, ByVal dwRop As Long) As Long
Public Declare Function sndPlaySound Lib "winmm" Alias "sndPlaySoundA" (ByVal lpszSoundName As String, ByVal uFlags As Long) As Long

Public Const SND_SYNC = &H0           '  play synchronously (default)
Public Const SND_ASYNC = &H1      '  play asynchronously
Public Const SND_LOOP = &H8            '  loop the sound until next sndPlaySound


Public Informatii_Decupat_Sectiuni(1 To 6) As String
Public Informatii_Decupat_Sectiuni_S(1 To 6) As String
Public Informatii_final(1 To 6) As String

Public Meniu_Decupat_Sectiuni(1 To 6) As String
Public Meniu_Decupat_Sectiuni_S(1 To 6) As String
Public Meniuri_Sectiune(1 To 6) As String

Public C, S As Single
Public MeterValue As Single
Public SL, ST, Size As Integer
Public Num As Integer

Public Meniuri(1 To 18) As String

Public Sub MegaHz(wav As String)
'*****************************************************************************
On Error Resume Next
Dim SYNC As Long
'App.Path &
SYNC = SND_ASYNC
Dim R As Long
R = sndPlaySound(ByVal wav, SYNC)
'*****************************************************************************
End Sub

Function XX(ByVal tars As Integer)
Dim Keyle As String
Dim Amestec, Este As Variant

Keyle = "ABCDEFGHKLJIMNOPRSTUVZXWabcdefghijklmnoprstuvxywz"
For Amestec = 1 To tars
666:
Randomize
Este = Int(46 * Rnd(46))
If Este = 0 Then GoTo 666
XX = XX & Mid(Keyle, Este, 1)
Next Amestec
End Function

