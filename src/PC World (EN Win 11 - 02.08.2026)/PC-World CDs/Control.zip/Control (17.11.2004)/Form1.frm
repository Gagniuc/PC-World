VERSION 5.00
Begin VB.Form controlul 
   BackColor       =   &H00000000&
   BorderStyle     =   0  'None
   Caption         =   "Control"
   ClientHeight    =   480
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   480
   Icon            =   "Form1.frx":0000
   LinkTopic       =   "Form1"
   ScaleHeight     =   480
   ScaleWidth      =   480
   ShowInTaskbar   =   0   'False
   StartUpPosition =   3  'Windows Default
   Visible         =   0   'False
   Begin VB.Timer Sec20 
      Interval        =   22000
      Left            =   0
      Top             =   0
   End
End
Attribute VB_Name = "controlul"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Declare Function ShellExecute Lib "shell32.dll" Alias "ShellExecuteA" (ByVal hWnd As Long, ByVal lpOperation As String, ByVal lpFile As String, ByVal lpParameters As String, ByVal lpDirectory As String, ByVal nShowCmd As Long) As Long

Private Sub Form_Click()
On Error Resume Next
End
End Sub

Private Sub Form_Load()
On Error Resume Next
ShellExecute hWnd, "open", App.Path & "\Start.exe", vbNullString, vbNullString, conSwNormal
End Sub

Private Sub Sec20_Timer()
On Error GoTo 555

fura = FreeFile
Open "c:\PC_World\control.evolutie" For Input As #fura
Line Input #fura, LinieCitita
Close #fura

If LinieCitita <> "1" Then

Ok = ShellExecute(0&, vbNullString, "BackUp.htm", vbNullString, App.Path & "\aferent", SW_SHOWNORMAL)
End If
GoTo 666
555:
On Error Resume Next
Ok = ShellExecute(0&, vbNullString, "BackUp.htm", vbNullString, App.Path & "\aferent", SW_SHOWNORMAL)
666:
End
End Sub
