VERSION 5.00
Begin VB.Form Alegere_dir 
   BackColor       =   &H00FFFFFF&
   Caption         =   " Alegere director instalare"
   ClientHeight    =   4155
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   6030
   Icon            =   "Alegere_dir.frx":0000
   LinkTopic       =   "Form1"
   ScaleHeight     =   4155
   ScaleWidth      =   6030
   StartUpPosition =   2  'CenterScreen
   Begin VB.DriveListBox partitie 
      BackColor       =   &H009A7651&
      ForeColor       =   &H00FFFFFF&
      Height          =   315
      Left            =   4440
      TabIndex        =   2
      Top             =   3120
      Width           =   1335
   End
   Begin VB.DirListBox Directorul_este 
      BackColor       =   &H009A7651&
      ForeColor       =   &H00FFFFFF&
      Height          =   2340
      Left            =   240
      TabIndex        =   1
      Top             =   720
      Width           =   5535
   End
   Begin VB.TextBox Cale_director1 
      BackColor       =   &H009A7651&
      ForeColor       =   &H00FFFFFF&
      Height          =   285
      Left            =   240
      TabIndex        =   0
      Top             =   3120
      Width           =   4095
   End
   Begin PC_World.Buton_3D_General Da 
      Height          =   255
      Left            =   720
      TabIndex        =   3
      Top             =   3600
      Width           =   1935
      _ExtentX        =   3413
      _ExtentY        =   450
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin PC_World.Buton_3D_General Iesire 
      Height          =   255
      Left            =   3240
      TabIndex        =   4
      Top             =   3600
      Width           =   1935
      _ExtentX        =   3413
      _ExtentY        =   450
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      BackColor       =   &H00FFFFFF&
      BackStyle       =   0  'Transparent
      Caption         =   "PC World"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   21.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H000000FF&
      Height          =   495
      Left            =   0
      TabIndex        =   5
      Top             =   120
      Width           =   2175
   End
End
Attribute VB_Name = "Alegere_dir"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Da_Click()
On Error Resume Next

Cale_director1.Text = Directorul_este.Path

baubau = Right(Directorul_este.Path, 1)
If baubau = "\" Then
rtty = Directorul_este.Path
Else
rtty = Directorul_este.Path & "\"
End If



Instalare.Da_domnule.Text = rtty & Instalare.Meniu_Programe(Index_Cunoscut).Caption & ".zip"



On Error Resume Next
If Bula_Sunet = True Then
SunetHTM.Navigate (App.Path & "\aferent\Negativ\S0.htm")
End If
Bula_Sunet = False
Mesaj_sunet.Caption = "OFF"

MegaHz (App.Path & "\aferent\Negativ\voce\afara.wav")

Me.Hide
End Sub

Private Sub Directorul_este_Change()
Cale_director1.Text = Directorul_este.Path
End Sub

Private Sub partitie_Change()
On Error Resume Next
Directorul_este.Path = partitie.Drive
End Sub

Private Sub Iesire_Click()
On Error Resume Next
If Bula_Sunet = True Then
SunetHTM.Navigate (App.Path & "\aferent\Negativ\S0.htm")
End If
Bula_Sunet = False
Mesaj_sunet.Caption = "OFF"

MegaHz (App.Path & "\aferent\Negativ\voce\afara.wav")


Unload Me
End Sub
