VERSION 5.00
Begin VB.Form Intrare 
   BackColor       =   &H00000080&
   BorderStyle     =   0  'None
   Caption         =   "Intrare_Verificare_Integritate_CD"
   ClientHeight    =   2910
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   4830
   Icon            =   "Intrare.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   Picture         =   "Intrare.frx":2982
   ScaleHeight     =   2910
   ScaleWidth      =   4830
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Begin VB.Timer Lupta_finala 
      Interval        =   10
      Left            =   120
      Top             =   3000
   End
   Begin VB.Timer Dai_tui_mama_lui 
      Interval        =   20
      Left            =   5160
      Top             =   120
   End
   Begin VB.PictureBox MeterBox 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      BackColor       =   &H00000040&
      DrawWidth       =   2
      FillColor       =   &H00000040&
      FillStyle       =   0  'Solid
      ForeColor       =   &H00000000&
      Height          =   2055
      Left            =   120
      ScaleHeight     =   135
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   303
      TabIndex        =   0
      Top             =   720
      Width           =   4575
      Begin VB.Label Mesagerie 
         Alignment       =   2  'Center
         BackStyle       =   0  'Transparent
         Caption         =   "Verificarea integritatii programului"
         ForeColor       =   &H00FFFFFF&
         Height          =   255
         Left            =   0
         TabIndex        =   4
         Top             =   1800
         Width           =   4575
      End
      Begin VB.Shape MeterShape 
         BackColor       =   &H0000FFFF&
         BorderColor     =   &H000000FF&
         FillColor       =   &H008080FF&
         Height          =   1455
         Left            =   1560
         Shape           =   3  'Circle
         Top             =   240
         Visible         =   0   'False
         Width           =   1575
      End
      Begin VB.Label MeterPos 
         Alignment       =   2  'Center
         BackStyle       =   0  'Transparent
         Caption         =   "0%"
         BeginProperty Font 
            Name            =   "System"
            Size            =   9.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H008080FF&
         Height          =   255
         Left            =   2160
         TabIndex        =   1
         Top             =   840
         Width           =   495
      End
   End
   Begin VB.Label Label1 
      BackStyle       =   0  'Transparent
      Caption         =   "PC World  - Octombrie 2004"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   18
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H000000FF&
      Height          =   495
      Left            =   200
      TabIndex        =   3
      Top             =   80
      Width           =   4575
   End
   Begin VB.Label Label3 
      BackStyle       =   0  'Transparent
      Caption         =   "PC World  - Octombrie 2004"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   18
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H000000C0&
      Height          =   495
      Left            =   240
      TabIndex        =   2
      Top             =   120
      Width           =   4575
   End
End
Attribute VB_Name = "Intrare"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False


Private Sub Dai_tui_mama_lui_Timer()
SetMeter -1, Intrare


If MeterPos.Caption = "100%" Then
Dai_tui_mama_lui.Enabled = False
Me.Hide
Instalare.Show
End If

End Sub

Private Sub Form_Load()
On Error Resume Next
Instalare.Hide
DoEvents

Instalare.SunetHTM.Offline = True
Instalare.Text_Imagine.Offline = True
Instalare.Voce.Offline = True
Instalare.Informatii.Offline = True

LoadMeter Intrare, RGB(1, 0, 0), RGB(255, 255, 255), True

On Error Resume Next
Instalare.Informatii.Navigate (App.Path & "\aferent\Negativ\Negativ.htm")
Instalare.Text_Imagine.Navigate (App.Path & "\aferent\Intrare.htm")
Instalare.SunetHTM.Navigate (App.Path & "\aferent\Negativ\S1.htm")
Instalare.Voce.Navigate (App.Path & "\aferent\Negativ\nimic.htm")
DoEvents

Me.Show


End Sub

Private Sub Lupta_finala_Timer()
If MeterPos.Caption = "30%" Then Mesagerie.Caption = "Verificarea integritatii fisierelor aferente programului"
If MeterPos.Caption = "40%" Then Mesagerie.Caption = "Verificarea integritatii directoarelor"
If MeterPos.Caption = "60%" Then Mesagerie.Caption = "Verificarea integritatii fisierelor de prezentare"
If MeterPos.Caption = "75%" Then Mesagerie.Caption = "Verificarea integritatii fisierelor imagine"
If MeterPos.Caption = "86%" Then
Mesagerie.Caption = "Programul este operational"
Lupta_finala.Enabled = False
End If
End Sub
