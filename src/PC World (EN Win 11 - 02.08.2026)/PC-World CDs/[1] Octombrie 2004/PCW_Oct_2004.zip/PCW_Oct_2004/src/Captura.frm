VERSION 5.00
Begin VB.Form Captura 
   BackColor       =   &H00000000&
   BorderStyle     =   0  'None
   Caption         =   "Captura"
   ClientHeight    =   7455
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   10095
   Icon            =   "Captura.frx":0000
   LinkTopic       =   "Form1"
   ScaleHeight     =   497
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   673
   StartUpPosition =   2  'CenterScreen
   Begin PC_World.Listare_Tip_GIF EcranMare 
      Height          =   6855
      Left            =   120
      Top             =   480
      Width           =   9855
      _ExtentX        =   17383
      _ExtentY        =   12091
      BackColor       =   0
   End
   Begin PC_World.Buton_3D_General Micro 
      Height          =   255
      Left            =   9360
      TabIndex        =   1
      Top             =   60
      Width           =   255
      _ExtentX        =   450
      _ExtentY        =   450
      Caption         =   "_"
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   12879428
   End
   Begin PC_World.Buton_3D_General X_Iesire 
      Height          =   255
      Left            =   9720
      TabIndex        =   2
      Top             =   60
      Width           =   255
      _ExtentX        =   450
      _ExtentY        =   450
      Caption         =   "X"
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   12879428
   End
   Begin VB.Shape Shape2 
      BackColor       =   &H00000000&
      BorderColor     =   &H00E0B693&
      Height          =   7455
      Left            =   0
      Top             =   0
      Width           =   10095
   End
   Begin VB.Line Line8 
      BorderColor     =   &H00FFFFFF&
      X1              =   736
      X2              =   0
      Y1              =   24
      Y2              =   24
   End
   Begin VB.Label Bara_principal 
      BackColor       =   &H00C48644&
      Caption         =   " PC World    CD - Octombrie 2004"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   18
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   375
      Left            =   0
      TabIndex        =   0
      Top             =   0
      Width           =   10095
   End
End
Attribute VB_Name = "Captura"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Declare Function SendMessage Lib "user32" Alias "SendMessageA" (ByVal hWnd As Long, ByVal wMsg As Long, ByVal wParam As Long, lParam As Any) As Long
Private Declare Sub ReleaseCapture Lib "user32" ()

Const WM_NCLBUTTONDOWN = &HA1
Const HTCAPTION = 2

Private Sub Bara_principal_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
If Button = 1 Then
Call ReleaseCapture
lngReturnValue = SendMessage(Me.hWnd, WM_NCLBUTTONDOWN, HTCAPTION, 0&)
End If
End Sub

Private Sub EcranMare_Click()
On Error Resume Next
If Bula_Sunet = True Then
SunetHTM.Navigate (App.Path & "\aferent\Negativ\S0.htm")
End If
Bula_Sunet = False
Mesaj_sunet.Caption = "OFF"

MegaHz (App.Path & "\aferent\Negativ\voce\afara.wav")

Unload Me
End Sub

Private Sub Micro_Click()
Me.WindowState = 1
End Sub

Private Sub X_Iesire_Click()
Unload Me
End Sub
