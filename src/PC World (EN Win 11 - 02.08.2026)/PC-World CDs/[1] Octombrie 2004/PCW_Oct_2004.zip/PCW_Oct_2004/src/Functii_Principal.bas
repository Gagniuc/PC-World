Attribute VB_Name = "Functii"
Option Explicit

Public Declare Function sndPlaySound Lib "winmm" Alias "sndPlaySoundA" (ByVal lpszSoundName As String, ByVal uFlags As Long) As Long

Public Const SND_SYNC = &H0           '  play synchronously (default)
Public Const SND_ASYNC = &H1      '  play asynchronously
Public Const SND_LOOP = &H8            '  loop the sound until next sndPlaySound



Declare Function GetPixel Lib "gdi32" (ByVal hDC As Long, ByVal X As Long, ByVal Y As Long) As Long
Declare Function SetPixel Lib "gdi32" (ByVal hDC As Long, ByVal X As Long, ByVal Y As Long, ByVal crColor As Long) As Long

Dim R, g, b As Integer
Dim LastNum As Integer
Dim I As Long
Dim X, Y As Long
Dim SelCol As String
Dim RainBowCol As Boolean

Public C, S As Single
Public MeterValue As Single
Public SL, ST, Size As Integer
Public Num As Integer

Public Sub MegaHz(wav As String)
'*****************************************************************************
'On Error Resume Next
Dim SYNC As Long
'App.Path &
SYNC = SND_ASYNC
Dim R As Long
R = sndPlaySound(ByVal wav, SYNC)
'*****************************************************************************
End Sub

Public Function LoadMeter(CurForm As Form, BarColor As Long, PercentColor As Long, RainBow As Boolean)
'To Make RainBow Call Either a R, G, B Color In BarColor
On Error GoTo Error
'Basic Numbers
SL = CurForm.MeterShape.Left + CurForm.MeterShape.Width / 2
ST = CurForm.MeterShape.Top + CurForm.MeterShape.Height / 2
Size = CurForm.MeterShape.Width / 2
CurForm.MeterBox.Circle (SL, ST), CurForm.MeterShape.Width / 2 + 1, &H80&
CurForm.MeterBox.Picture = CurForm.MeterBox.Image
'MeterPos
CurForm.MeterPos.Caption = "0%"
CurForm.MeterPos.Left = 0
CurForm.MeterPos.Width = CurForm.MeterBox.ScaleWidth
CurForm.MeterPos.Top = CurForm.MeterShape.Top + CurForm.MeterShape.Height / 2 - CurForm.MeterPos.Height / 2
CurForm.MeterPos.ForeColor = PercentColor
'Meter
If RainBow = False Then
    CurForm.MeterBox.ForeColor = BarColor
Else
    RainBowCol = True
    R = BarColor Mod &H100
    g = (BarColor \ &H100) Mod &H100
    b = (BarColor \ &H10000) Mod &H100
    If R > g And R > b Then
        R = 1
        g = 0
        b = 0
        GoTo Finish
        End If
    If g > R And g > b Then
        R = 0
        g = 1
        b = 0
        GoTo Finish
        End If
    If b > R And b > g Then
        R = 0
        g = 0
        b = 1
        GoTo Finish
        End If
    If R = g Then
        R = 1
        g = 1
        b = 0
        GoTo Finish
        End If
    If R = b Then
        R = 1
        g = 0
        b = 1
        GoTo Finish
        End If
    If g = b Then
        R = 0
        g = 1
        b = 1
        GoTo Finish
        End If
End If
Finish:
SetMeter 0, Intrare
Exit Function
Error:
MsgBox Err.Description
End Function

Public Function SetMeter(SetNum As Single, CurForm As Form)
On Error GoTo Error
Dim MeterNum As Single
'Checks if SetNum for Certain Values
SetNum = Round(SetNum)
Select Case SetNum
Case Is <= -3
    SetNum = 0
Case -1
    'Go Up One
    SetNum = LastNum + 1
    If SetNum >= 100 Then
        SetNum = 100
        End If
Case -2
    'Go Down One
    SetNum = LastNum - 1
    If SetNum < 0 Then
        SetNum = 0
        End If
Case Is > 100
    Exit Function
End Select

'Sets the Circle Bar
CurForm.MeterBox.Cls
For I = 0 To Round(SetNum * 3.6, 0)
    C = I
    S = I
    C = Cos(C * (3.14159 / 180))
    S = Sin(S * (3.14159 / 180))
    
    If RainBowCol = True Then
        CurForm.MeterBox.ForeColor = RGB(I / 1.4 * R, I / 1.4 * g, I / 1.4 * b)
        End If

    '***ClockWise Progress
    'CurForm.MeterBox.Line (SL, ST)-(S * Size + SL, -C * Size + ST)
    
    '***Counter-ClockWise Progress
    'CurForm.MeterBox.Line (SL, ST)-(-S * Size + SL, -C * Size + ST)
    
    '***Upside Down ClockWise Progress
    'CurForm.MeterBox.Line (SL, ST)-(S * Size + SL, C * Size + ST)
    
    '***Upside Down Counter-ClockWise Progress
    'CurForm.MeterBox.Line (SL, ST)-(-S * Size + SL, C * Size + ST)
    
    '***45 Degrees Progress ClockWise
    'CurForm.MeterBox.Line (SL, ST)-(C * Size + SL, S * Size + ST)
    
    '***45 Degrees Progress Counter-ClockWise
    CurForm.MeterBox.Line (SL, ST)-(C * Size + SL, -S * Size + ST)
    
    '***135 Degress Progress ClockWise
    'CurForm.MeterBox.Line (SL, ST)-(-C * Size + SL, -S * Size + ST)
    
    '***135 Degress Progress Counter-CloseWise
    'CurForm.MeterBox.Line (SL, ST)-(-C * Size + SL, S * Size + ST)
Next I
CurForm.MeterBox.Refresh
CurForm.MeterPos.Caption = SetNum & "%"
LastNum = SetNum
Exit Function
Error:
MsgBox Err.Description
End Function

Public Function GetMeter(CurForm As Form)
MeterValue = LastNum
End Function

Function XX(ByVal tars As Integer)
Dim Keyle As String
Dim Amestec, Este As Variant

Keyle = "ABCDEFGHKLJIMNOPRSTUVZXWabcdefghijklmnoprstuvxywz"
For Amestec = 1 To tars
666:
Randomize
Este = Int(46 * Rnd(46))
If Este = 0 Then GoTo 666
XX = XX & Mid(Keyle, Este, 1)
Next Amestec
End Function

