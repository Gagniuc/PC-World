VERSION 5.00
Object = "{EAB22AC0-30C1-11CF-A7EB-0000C05BAE0B}#1.1#0"; "shdocvw.dll"
Begin VB.Form Instalare 
   BackColor       =   &H009A7651&
   BorderStyle     =   0  'None
   Caption         =   "PC World"
   ClientHeight    =   8280
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   11310
   Icon            =   "CD.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   Picture         =   "CD.frx":030A
   ScaleHeight     =   552
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   754
   StartUpPosition =   2  'CenterScreen
   Begin PC_World.Buton_3D_General B_Sunet 
      Height          =   495
      Left            =   240
      TabIndex        =   62
      ToolTipText     =   "Sunet on/off"
      Top             =   7560
      Width           =   495
      _ExtentX        =   873
      _ExtentY        =   873
      Caption         =   ""
      ButtonStyle     =   3
      Picture         =   "CD.frx":3917
      PictureWidth    =   25
      PictureHeight   =   26
      PictureSize     =   2
      OriginalPicSizeW=   25
      OriginalPicSizeH=   26
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      XPColor_Pressed =   0
      XPColor_Hover   =   0
      BackColor       =   4194304
   End
   Begin SHDocVwCtl.WebBrowser SunetHTM 
      Height          =   1335
      Left            =   2040
      TabIndex        =   61
      Top             =   8400
      Width           =   1335
      ExtentX         =   2355
      ExtentY         =   2355
      ViewMode        =   0
      Offline         =   0
      Silent          =   0
      RegisterAsBrowser=   0
      RegisterAsDropTarget=   1
      AutoArrange     =   0   'False
      NoClientEdge    =   0   'False
      AlignLeft       =   0   'False
      NoWebView       =   0   'False
      HideFileNames   =   0   'False
      SingleClick     =   0   'False
      SingleSelection =   0   'False
      NoFolders       =   0   'False
      Transparent     =   0   'False
      ViewID          =   "{0057D0E0-3573-11CF-AE69-08002B2E1262}"
      Location        =   "http:///"
   End
   Begin VB.Timer Arata_La_suta 
      Enabled         =   0   'False
      Interval        =   10
      Left            =   840
      Top             =   8880
   End
   Begin VB.PictureBox Bara_copiere 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      BackColor       =   &H00004040&
      ForeColor       =   &H80000008&
      Height          =   255
      Left            =   6360
      Picture         =   "CD.frx":3F23
      ScaleHeight     =   15
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   311
      TabIndex        =   57
      Top             =   7800
      Visible         =   0   'False
      Width           =   4695
   End
   Begin VB.PictureBox Picture4 
      BackColor       =   &H00A67645&
      FillColor       =   &H009A7651&
      Height          =   15
      Left            =   6600
      ScaleHeight     =   15
      ScaleWidth      =   255
      TabIndex        =   47
      Top             =   5340
      Width           =   255
   End
   Begin VB.PictureBox Picture3 
      BackColor       =   &H00A67645&
      FillColor       =   &H009A7651&
      Height          =   15
      Left            =   6600
      ScaleHeight     =   15
      ScaleWidth      =   255
      TabIndex        =   46
      Top             =   1860
      Width           =   255
   End
   Begin VB.PictureBox Picture2 
      BackColor       =   &H00A67645&
      FillColor       =   &H009A7651&
      Height          =   3615
      Left            =   6590
      ScaleHeight     =   3615
      ScaleWidth      =   15
      TabIndex        =   45
      Top             =   1800
      Width           =   15
   End
   Begin VB.PictureBox Picture1 
      BackColor       =   &H00A67645&
      FillColor       =   &H009A7651&
      Height          =   3735
      Left            =   6840
      ScaleHeight     =   3735
      ScaleWidth      =   15
      TabIndex        =   44
      Top             =   1800
      Width           =   15
   End
   Begin VB.Frame Crater_UMJIA2 
      BackColor       =   &H00A67645&
      BorderStyle     =   0  'None
      Caption         =   "Frame1"
      Height          =   1695
      Left            =   4920
      TabIndex        =   12
      Top             =   5880
      Width           =   6135
      Begin VB.TextBox Da_domnule 
         Appearance      =   0  'Flat
         BackColor       =   &H00C48644&
         ForeColor       =   &H00FFFFFF&
         Height          =   285
         Left            =   1920
         TabIndex        =   55
         Text            =   "C:\PC_World\Kit.zip"
         Top             =   480
         Visible         =   0   'False
         Width           =   4215
      End
      Begin PC_World.Buton_3D_General Instalare 
         Height          =   375
         Left            =   0
         TabIndex        =   19
         Top             =   0
         Width           =   1455
         _ExtentX        =   2566
         _ExtentY        =   661
         Caption         =   "Instaleaza"
         ButtonStyle     =   3
         OriginalPicSizeW=   0
         OriginalPicSizeH=   0
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "GlaserSteD"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         MousePointer    =   99
         XPColor_Pressed =   16777215
         XPColor_Hover   =   16777215
         BackColor       =   4194304
         ForeColor       =   16777215
         SoundOver       =   ".\aferent\Negativ\Buton.wav"
      End
      Begin PC_World.Buton_3D_General Copiere 
         Height          =   375
         Left            =   1560
         TabIndex        =   20
         Top             =   0
         Width           =   1455
         _ExtentX        =   2566
         _ExtentY        =   661
         Caption         =   "Copiaza"
         ButtonStyle     =   3
         OriginalPicSizeW=   0
         OriginalPicSizeH=   0
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "GlaserSteD"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         MousePointer    =   99
         BackColor       =   4194304
         ForeColor       =   16777215
         SoundOver       =   ".\aferent\Negativ\Buton.wav"
      End
      Begin PC_World.Buton_3D_General Rulare 
         Height          =   375
         Left            =   3120
         TabIndex        =   21
         Top             =   0
         Width           =   1455
         _ExtentX        =   2566
         _ExtentY        =   661
         Caption         =   "Ruleaza"
         ButtonStyle     =   3
         OriginalPicSizeW=   0
         OriginalPicSizeH=   0
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "GlaserSteD"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         MousePointer    =   99
         BackColor       =   4194304
         ForeColor       =   16777215
         SoundOver       =   ".\aferent\Negativ\Buton.wav"
      End
      Begin PC_World.Buton_3D_General Citire 
         Height          =   375
         Left            =   4680
         TabIndex        =   22
         Top             =   0
         Width           =   1455
         _ExtentX        =   2566
         _ExtentY        =   661
         Caption         =   "Citeste-ma"
         ButtonStyle     =   3
         OriginalPicSizeW=   0
         OriginalPicSizeH=   0
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "GlaserSteD"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         MousePointer    =   99
         BackColor       =   4194304
         ForeColor       =   16777215
         SoundOver       =   ".\aferent\Negativ\Buton.wav"
      End
      Begin PC_World.Buton_3D_General Unde 
         Height          =   375
         Left            =   0
         TabIndex        =   56
         Top             =   480
         Visible         =   0   'False
         Width           =   1815
         _ExtentX        =   3201
         _ExtentY        =   661
         Caption         =   "Copiaza in ..."
         ButtonStyle     =   3
         OriginalPicSizeW=   0
         OriginalPicSizeH=   0
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "GlaserSteD"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         MousePointer    =   99
         XPColor_Pressed =   16777215
         XPColor_Hover   =   16777215
         BackColor       =   12879428
         ForeColor       =   0
         SoundOver       =   ".\aferent\Negativ\Buton.wav"
      End
      Begin VB.Line Line12 
         BorderColor     =   &H00000000&
         X1              =   6120
         X2              =   120
         Y1              =   840
         Y2              =   840
      End
      Begin VB.Image Image3 
         Height          =   480
         Left            =   600
         Picture         =   "CD.frx":89ED
         Top             =   960
         Width           =   435
      End
      Begin VB.Label Sectiune 
         BackStyle       =   0  'Transparent
         Caption         =   "Sectiune - Intro"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   18
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FFFFFF&
         Height          =   495
         Index           =   1
         Left            =   1320
         TabIndex        =   42
         Top             =   1080
         Width           =   4095
      End
      Begin VB.Label Sectiune 
         BackStyle       =   0  'Transparent
         Caption         =   "Sectiune - Intro"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   18
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00E0B693&
         Height          =   495
         Index           =   0
         Left            =   1440
         TabIndex        =   41
         Top             =   960
         Width           =   4695
      End
   End
   Begin VB.Frame Crater_UMJIA 
      BackColor       =   &H00A67645&
      BorderStyle     =   0  'None
      Caption         =   "Ecuatie_Formular"
      Height          =   4515
      Left            =   220
      TabIndex        =   10
      Top             =   1260
      Width           =   10815
      Begin VB.PictureBox Picture8 
         BackColor       =   &H009A7651&
         FillColor       =   &H009A7651&
         Height          =   15
         Left            =   2760
         ScaleHeight     =   15
         ScaleWidth      =   3615
         TabIndex        =   54
         Top             =   600
         Width           =   3615
      End
      Begin VB.PictureBox Picture7 
         BackColor       =   &H009A7651&
         FillColor       =   &H009A7651&
         Height          =   15
         Left            =   2760
         ScaleHeight     =   15
         ScaleWidth      =   3615
         TabIndex        =   53
         Top             =   4080
         Width           =   3615
      End
      Begin VB.PictureBox Picture6 
         BackColor       =   &H009A7651&
         FillColor       =   &H009A7651&
         Height          =   3495
         Left            =   2760
         ScaleHeight     =   3495
         ScaleWidth      =   15
         TabIndex        =   52
         Top             =   600
         Width           =   15
      End
      Begin VB.PictureBox Picture5 
         Appearance      =   0  'Flat
         BackColor       =   &H00A67645&
         ForeColor       =   &H80000008&
         Height          =   3495
         Left            =   6360
         ScaleHeight     =   3465
         ScaleWidth      =   240
         TabIndex        =   48
         Top             =   600
         Width           =   265
      End
      Begin SHDocVwCtl.WebBrowser Informatii 
         Height          =   3495
         Left            =   2760
         TabIndex        =   11
         Top             =   600
         Width           =   3865
         ExtentX         =   6817
         ExtentY         =   6165
         ViewMode        =   0
         Offline         =   0
         Silent          =   0
         RegisterAsBrowser=   0
         RegisterAsDropTarget=   1
         AutoArrange     =   0   'False
         NoClientEdge    =   0   'False
         AlignLeft       =   0   'False
         NoWebView       =   0   'False
         HideFileNames   =   0   'False
         SingleClick     =   0   'False
         SingleSelection =   0   'False
         NoFolders       =   0   'False
         Transparent     =   0   'False
         ViewID          =   "{0057D0E0-3573-11CF-AE69-08002B2E1262}"
         Location        =   "http:///"
      End
      Begin PC_World.Buton_3D_General Meniu_Programe 
         Height          =   255
         Index           =   0
         Left            =   0
         TabIndex        =   18
         Top             =   0
         Width           =   2535
         _ExtentX        =   4471
         _ExtentY        =   450
         Caption         =   "Gol"
         OriginalPicSizeW=   0
         OriginalPicSizeH=   0
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         MousePointer    =   99
         ShowFocusRect   =   0   'False
         XPColor_Pressed =   4194304
         XPColor_Hover   =   14737632
         BackColor       =   10909253
         ForeColor       =   16777215
      End
      Begin PC_World.Buton_3D_General Meniu_Programe 
         Height          =   255
         Index           =   1
         Left            =   0
         TabIndex        =   24
         Top             =   480
         Width           =   2535
         _ExtentX        =   4471
         _ExtentY        =   450
         Caption         =   "Gol"
         OriginalPicSizeW=   0
         OriginalPicSizeH=   0
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         MousePointer    =   99
         ShowFocusRect   =   0   'False
         XPColor_Pressed =   4194304
         XPColor_Hover   =   14737632
         BackColor       =   10909253
         ForeColor       =   16777215
      End
      Begin PC_World.Buton_3D_General Meniu_Programe 
         Height          =   255
         Index           =   2
         Left            =   0
         TabIndex        =   25
         Top             =   240
         Width           =   2535
         _ExtentX        =   4471
         _ExtentY        =   450
         Caption         =   "Gol"
         OriginalPicSizeW=   0
         OriginalPicSizeH=   0
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         MousePointer    =   99
         ShowFocusRect   =   0   'False
         XPColor_Pressed =   4194304
         XPColor_Hover   =   14737632
         BackColor       =   10909253
         ForeColor       =   16777215
      End
      Begin PC_World.Buton_3D_General Meniu_Programe 
         Height          =   255
         Index           =   3
         Left            =   0
         TabIndex        =   26
         Top             =   720
         Width           =   2535
         _ExtentX        =   4471
         _ExtentY        =   450
         Caption         =   "Gol"
         OriginalPicSizeW=   0
         OriginalPicSizeH=   0
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         MousePointer    =   99
         ShowFocusRect   =   0   'False
         XPColor_Pressed =   4194304
         XPColor_Hover   =   14737632
         BackColor       =   10909253
         ForeColor       =   16777215
      End
      Begin PC_World.Buton_3D_General Meniu_Programe 
         Height          =   255
         Index           =   4
         Left            =   0
         TabIndex        =   27
         Top             =   960
         Width           =   2535
         _ExtentX        =   4471
         _ExtentY        =   450
         Caption         =   "Gol"
         OriginalPicSizeW=   0
         OriginalPicSizeH=   0
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         MousePointer    =   99
         ShowFocusRect   =   0   'False
         XPColor_Pressed =   4194304
         XPColor_Hover   =   14737632
         BackColor       =   10909253
         ForeColor       =   16777215
      End
      Begin PC_World.Buton_3D_General Meniu_Programe 
         Height          =   255
         Index           =   5
         Left            =   0
         TabIndex        =   28
         Top             =   1200
         Width           =   2535
         _ExtentX        =   4471
         _ExtentY        =   450
         Caption         =   "Gol"
         OriginalPicSizeW=   0
         OriginalPicSizeH=   0
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         MousePointer    =   99
         ShowFocusRect   =   0   'False
         XPColor_Pressed =   4194304
         XPColor_Hover   =   14737632
         BackColor       =   10909253
         ForeColor       =   16777215
      End
      Begin PC_World.Buton_3D_General Meniu_Programe 
         Height          =   255
         Index           =   6
         Left            =   0
         TabIndex        =   29
         Top             =   1440
         Width           =   2535
         _ExtentX        =   4471
         _ExtentY        =   450
         Caption         =   "Gol"
         OriginalPicSizeW=   0
         OriginalPicSizeH=   0
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         MousePointer    =   99
         ShowFocusRect   =   0   'False
         XPColor_Pressed =   4194304
         XPColor_Hover   =   14737632
         BackColor       =   10909253
         ForeColor       =   16777215
      End
      Begin PC_World.Buton_3D_General Meniu_Programe 
         Height          =   255
         Index           =   7
         Left            =   0
         TabIndex        =   30
         Top             =   1680
         Width           =   2535
         _ExtentX        =   4471
         _ExtentY        =   450
         Caption         =   "Gol"
         OriginalPicSizeW=   0
         OriginalPicSizeH=   0
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         MousePointer    =   99
         ShowFocusRect   =   0   'False
         XPColor_Pressed =   4194304
         XPColor_Hover   =   14737632
         BackColor       =   10909253
         ForeColor       =   16777215
      End
      Begin PC_World.Buton_3D_General Meniu_Programe 
         Height          =   255
         Index           =   8
         Left            =   0
         TabIndex        =   31
         Top             =   1920
         Width           =   2535
         _ExtentX        =   4471
         _ExtentY        =   450
         Caption         =   "Gol"
         OriginalPicSizeW=   0
         OriginalPicSizeH=   0
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         MousePointer    =   99
         ShowFocusRect   =   0   'False
         XPColor_Pressed =   4194304
         XPColor_Hover   =   14737632
         BackColor       =   10909253
         ForeColor       =   16777215
      End
      Begin PC_World.Buton_3D_General Meniu_Programe 
         Height          =   255
         Index           =   9
         Left            =   0
         TabIndex        =   32
         Top             =   2160
         Width           =   2535
         _ExtentX        =   4471
         _ExtentY        =   450
         Caption         =   "Gol"
         OriginalPicSizeW=   0
         OriginalPicSizeH=   0
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         MousePointer    =   99
         ShowFocusRect   =   0   'False
         XPColor_Pressed =   4194304
         XPColor_Hover   =   14737632
         BackColor       =   10909253
         ForeColor       =   16777215
      End
      Begin PC_World.Buton_3D_General Meniu_Programe 
         Height          =   255
         Index           =   10
         Left            =   0
         TabIndex        =   33
         Top             =   2400
         Width           =   2535
         _ExtentX        =   4471
         _ExtentY        =   450
         Caption         =   "Gol"
         OriginalPicSizeW=   0
         OriginalPicSizeH=   0
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         MousePointer    =   99
         ShowFocusRect   =   0   'False
         XPColor_Pressed =   4194304
         XPColor_Hover   =   14737632
         BackColor       =   10909253
         ForeColor       =   16777215
      End
      Begin PC_World.Buton_3D_General Meniu_Programe 
         Height          =   255
         Index           =   11
         Left            =   0
         TabIndex        =   34
         Top             =   2640
         Width           =   2535
         _ExtentX        =   4471
         _ExtentY        =   450
         Caption         =   "Gol"
         OriginalPicSizeW=   0
         OriginalPicSizeH=   0
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         MousePointer    =   99
         ShowFocusRect   =   0   'False
         XPColor_Pressed =   4194304
         XPColor_Hover   =   14737632
         BackColor       =   10909253
         ForeColor       =   16777215
      End
      Begin PC_World.Buton_3D_General Meniu_Programe 
         Height          =   255
         Index           =   12
         Left            =   0
         TabIndex        =   35
         Top             =   2880
         Width           =   2535
         _ExtentX        =   4471
         _ExtentY        =   450
         Caption         =   "Gol"
         OriginalPicSizeW=   0
         OriginalPicSizeH=   0
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         MousePointer    =   99
         ShowFocusRect   =   0   'False
         XPColor_Pressed =   4194304
         XPColor_Hover   =   14737632
         BackColor       =   10909253
         ForeColor       =   16777215
      End
      Begin PC_World.Buton_3D_General Meniu_Programe 
         Height          =   255
         Index           =   13
         Left            =   0
         TabIndex        =   36
         Top             =   3120
         Width           =   2535
         _ExtentX        =   4471
         _ExtentY        =   450
         Caption         =   "Gol"
         OriginalPicSizeW=   0
         OriginalPicSizeH=   0
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         MousePointer    =   99
         ShowFocusRect   =   0   'False
         XPColor_Pressed =   4194304
         XPColor_Hover   =   14737632
         BackColor       =   10909253
         ForeColor       =   16777215
      End
      Begin PC_World.Buton_3D_General Meniu_Programe 
         Height          =   255
         Index           =   14
         Left            =   0
         TabIndex        =   37
         Top             =   3360
         Width           =   2535
         _ExtentX        =   4471
         _ExtentY        =   450
         Caption         =   "Gol"
         OriginalPicSizeW=   0
         OriginalPicSizeH=   0
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         MousePointer    =   99
         ShowFocusRect   =   0   'False
         XPColor_Pressed =   4194304
         XPColor_Hover   =   14737632
         BackColor       =   10909253
         ForeColor       =   16777215
      End
      Begin PC_World.Buton_3D_General Meniu_Programe 
         Height          =   255
         Index           =   15
         Left            =   0
         TabIndex        =   38
         Top             =   3600
         Width           =   2535
         _ExtentX        =   4471
         _ExtentY        =   450
         Caption         =   "Gol"
         OriginalPicSizeW=   0
         OriginalPicSizeH=   0
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         MousePointer    =   99
         ShowFocusRect   =   0   'False
         XPColor_Pressed =   4194304
         XPColor_Hover   =   14737632
         BackColor       =   10909253
         ForeColor       =   16777215
      End
      Begin PC_World.Buton_3D_General Meniu_Programe 
         Height          =   255
         Index           =   16
         Left            =   0
         TabIndex        =   39
         Top             =   3840
         Width           =   2535
         _ExtentX        =   4471
         _ExtentY        =   450
         Caption         =   "Gol"
         OriginalPicSizeW=   0
         OriginalPicSizeH=   0
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         MousePointer    =   99
         ShowFocusRect   =   0   'False
         XPColor_Pressed =   4194304
         XPColor_Hover   =   14737632
         BackColor       =   10909253
         ForeColor       =   16777215
      End
      Begin PC_World.Buton_3D_General Meniu_Programe 
         Height          =   255
         Index           =   17
         Left            =   0
         TabIndex        =   40
         Top             =   4080
         Width           =   2535
         _ExtentX        =   4471
         _ExtentY        =   450
         Caption         =   "Gol"
         OriginalPicSizeW=   0
         OriginalPicSizeH=   0
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         MousePointer    =   99
         ShowFocusRect   =   0   'False
         XPColor_Pressed =   4194304
         XPColor_Hover   =   14737632
         BackColor       =   10909253
         ForeColor       =   16777215
      End
      Begin PC_World.Listare_Tip_GIF Listare_Tip_GIF1 
         Height          =   3495
         Left            =   6720
         Top             =   600
         Width           =   4095
         _ExtentX        =   7223
         _ExtentY        =   6165
         BackColor       =   10909253
      End
      Begin PC_World.Buton_3D_General Meniu_Programe 
         Height          =   255
         Index           =   18
         Left            =   0
         TabIndex        =   60
         Top             =   4320
         Width           =   2535
         _ExtentX        =   4471
         _ExtentY        =   450
         Caption         =   "Gol"
         OriginalPicSizeW=   0
         OriginalPicSizeH=   0
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         MousePointer    =   99
         ShowFocusRect   =   0   'False
         XPColor_Pressed =   4194304
         XPColor_Hover   =   14737632
         BackColor       =   10909253
         ForeColor       =   16777215
      End
      Begin VB.Label Sectiune 
         Alignment       =   2  'Center
         BackStyle       =   0  'Transparent
         Caption         =   "Captura"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   18
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FFFFFF&
         Height          =   375
         Index           =   4
         Left            =   7320
         TabIndex        =   50
         Top             =   0
         Width           =   3135
      End
      Begin VB.Label Sectiune 
         Alignment       =   2  'Center
         BackStyle       =   0  'Transparent
         Caption         =   "Explicatii"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   18
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FFFFFF&
         Height          =   375
         Index           =   3
         Left            =   3240
         TabIndex        =   49
         Top             =   0
         Width           =   2655
      End
      Begin VB.Line Line11 
         BorderColor     =   &H00FFFFFF&
         X1              =   2640
         X2              =   2640
         Y1              =   4560
         Y2              =   0
      End
      Begin VB.Line Line10 
         BorderColor     =   &H00FFFFFF&
         X1              =   10800
         X2              =   2760
         Y1              =   4320
         Y2              =   4320
      End
      Begin VB.Line Line9 
         BorderColor     =   &H00FFFFFF&
         X1              =   10800
         X2              =   2760
         Y1              =   480
         Y2              =   480
      End
   End
   Begin VB.Timer Sunet 
      Enabled         =   0   'False
      Interval        =   2000
      Left            =   360
      Top             =   8880
   End
   Begin PC_World.Buton_3D_General IntroEU 
      Height          =   255
      Left            =   240
      TabIndex        =   0
      ToolTipText     =   "Micsorare"
      Top             =   6360
      Width           =   2175
      _ExtentX        =   3836
      _ExtentY        =   450
      Caption         =   "Intro"
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin PC_World.Buton_3D_General Iesire 
      Height          =   255
      Left            =   1560
      TabIndex        =   1
      ToolTipText     =   "Iesire"
      Top             =   7800
      Width           =   3495
      _ExtentX        =   6165
      _ExtentY        =   450
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin PC_World.Buton_3D_General Micsorare 
      Height          =   255
      Left            =   1200
      TabIndex        =   2
      ToolTipText     =   "Intro"
      Top             =   7440
      Width           =   3255
      _ExtentX        =   5741
      _ExtentY        =   450
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin PC_World.Buton_3D_General Internet 
      Height          =   375
      Left            =   4680
      TabIndex        =   3
      ToolTipText     =   "Internet"
      Top             =   720
      Width           =   1215
      _ExtentX        =   2143
      _ExtentY        =   661
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "GlaserSteD"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin PC_World.Buton_3D_General Multimedia 
      Height          =   375
      Left            =   2040
      TabIndex        =   4
      ToolTipText     =   "Multimedia"
      Top             =   720
      Width           =   1215
      _ExtentX        =   2143
      _ExtentY        =   661
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "GlaserSteD"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin PC_World.Buton_3D_General Utilitare 
      Height          =   375
      Left            =   720
      TabIndex        =   5
      ToolTipText     =   "Utilitare"
      Top             =   720
      Width           =   1215
      _ExtentX        =   2143
      _ExtentY        =   661
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "GlaserSteD"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin PC_World.Buton_3D_General PaulGagniuc_OnLine 
      Height          =   255
      Left            =   600
      TabIndex        =   6
      ToolTipText     =   "Legatura directa -  www.pcworld.ro"
      Top             =   6720
      Width           =   2415
      _ExtentX        =   4260
      _ExtentY        =   450
      Caption         =   "PC World - OnLine"
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      XPColor_Hover   =   16711680
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin PC_World.Buton_3D_General Micro 
      Height          =   255
      Left            =   10560
      TabIndex        =   7
      Top             =   120
      Width           =   255
      _ExtentX        =   450
      _ExtentY        =   450
      Caption         =   "_"
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   12879428
   End
   Begin PC_World.Buton_3D_General X_Iesire 
      Height          =   255
      Left            =   10920
      TabIndex        =   8
      Top             =   120
      Width           =   255
      _ExtentX        =   450
      _ExtentY        =   450
      Caption         =   "X"
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   12879428
   End
   Begin PC_World.Buton_3D_General Despre 
      Height          =   375
      Left            =   10080
      TabIndex        =   9
      ToolTipText     =   "Despre"
      Top             =   720
      Width           =   1095
      _ExtentX        =   1931
      _ExtentY        =   661
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "GlaserSteD"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin PC_World.Buton_3D_General Antivirus 
      Height          =   375
      Left            =   6000
      TabIndex        =   13
      ToolTipText     =   "Antivirus"
      Top             =   720
      Width           =   1215
      _ExtentX        =   2143
      _ExtentY        =   661
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "GlaserSteD"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin PC_World.Buton_3D_General Revista 
      Height          =   375
      Left            =   8760
      TabIndex        =   14
      ToolTipText     =   "Revista"
      Top             =   720
      Width           =   1215
      _ExtentX        =   2143
      _ExtentY        =   661
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "GlaserSteD"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin PC_World.Buton_3D_General Permanente 
      Height          =   375
      Left            =   7320
      TabIndex        =   15
      ToolTipText     =   "Permanente"
      Top             =   720
      Width           =   1335
      _ExtentX        =   2355
      _ExtentY        =   661
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "GlaserSteD"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin PC_World.Buton_3D_General Jocuri 
      Height          =   375
      Left            =   3360
      TabIndex        =   16
      ToolTipText     =   "Jocuri"
      Top             =   720
      Width           =   1215
      _ExtentX        =   2143
      _ExtentY        =   661
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "GlaserSteD"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin PC_World.Buton_3D_General Ajutorul 
      Height          =   255
      Left            =   840
      TabIndex        =   23
      ToolTipText     =   "Ajutor"
      Top             =   7080
      Width           =   2775
      _ExtentX        =   4895
      _ExtentY        =   450
      Caption         =   "Ajutor"
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin SHDocVwCtl.WebBrowser Text_Imagine 
      Height          =   4335
      Left            =   240
      TabIndex        =   43
      Top             =   1320
      Width           =   10695
      ExtentX         =   18865
      ExtentY         =   7646
      ViewMode        =   0
      Offline         =   0
      Silent          =   0
      RegisterAsBrowser=   0
      RegisterAsDropTarget=   1
      AutoArrange     =   0   'False
      NoClientEdge    =   0   'False
      AlignLeft       =   0   'False
      NoWebView       =   0   'False
      HideFileNames   =   0   'False
      SingleClick     =   0   'False
      SingleSelection =   0   'False
      NoFolders       =   0   'False
      Transparent     =   0   'False
      ViewID          =   "{0057D0E0-3573-11CF-AE69-08002B2E1262}"
      Location        =   "http:///"
   End
   Begin SHDocVwCtl.WebBrowser Voce 
      Height          =   1335
      Left            =   3600
      TabIndex        =   63
      Top             =   8400
      Width           =   1335
      ExtentX         =   2355
      ExtentY         =   2355
      ViewMode        =   0
      Offline         =   0
      Silent          =   0
      RegisterAsBrowser=   0
      RegisterAsDropTarget=   1
      AutoArrange     =   0   'False
      NoClientEdge    =   0   'False
      AlignLeft       =   0   'False
      NoWebView       =   0   'False
      HideFileNames   =   0   'False
      SingleClick     =   0   'False
      SingleSelection =   0   'False
      NoFolders       =   0   'False
      Transparent     =   0   'False
      ViewID          =   "{0057D0E0-3573-11CF-AE69-08002B2E1262}"
      Location        =   "http:///"
   End
   Begin PC_World.Buton_3D_General Driver 
      Height          =   255
      Left            =   5880
      TabIndex        =   65
      ToolTipText     =   "Despre"
      Top             =   120
      Width           =   4215
      _ExtentX        =   7435
      _ExtentY        =   450
      Caption         =   "Drivere"
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "GlaserSteD"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin VB.Image Image4 
      Height          =   240
      Left            =   5520
      Picture         =   "CD.frx":8F7B
      Top             =   120
      Width           =   165
   End
   Begin VB.Label Mesaj_sunet 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "ON"
      BeginProperty Font 
         Name            =   "Small Fonts"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   255
      Left            =   240
      TabIndex        =   64
      Top             =   7320
      Width           =   495
   End
   Begin VB.Image Baner 
      Height          =   1665
      Index           =   1
      Left            =   5640
      Picture         =   "CD.frx":9339
      Top             =   5880
      Width           =   4455
   End
   Begin VB.Line Linie 
      BorderColor     =   &H00FFFFFF&
      X1              =   190.667
      X2              =   190.667
      Y1              =   416
      Y2              =   384
   End
   Begin VB.Label Dimensiune 
      Height          =   255
      Left            =   1320
      TabIndex        =   59
      Top             =   8880
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Label Eu_la_suta 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "0 %"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   14.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   5520
      TabIndex        =   58
      Top             =   7800
      Visible         =   0   'False
      Width           =   855
   End
   Begin VB.Label Sectiune69 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "www.pcworld.ro"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   18
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   375
      Index           =   2
      Left            =   8520
      TabIndex        =   51
      Top             =   7680
      Width           =   2535
   End
   Begin VB.Image Image2 
      Height          =   360
      Left            =   240
      Picture         =   "CD.frx":2163F
      Top             =   720
      Width           =   360
   End
   Begin VB.Line Line8 
      BorderColor     =   &H00FFFFFF&
      X1              =   744
      X2              =   8
      Y1              =   32
      Y2              =   32
   End
   Begin VB.Image Ajutaj 
      Height          =   240
      Left            =   10200
      Picture         =   "CD.frx":217B9
      Top             =   120
      Width           =   240
   End
   Begin VB.Label Bara_principal 
      BackStyle       =   0  'Transparent
      Caption         =   "PC World    CD - Octombrie 2004"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   18
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   495
      Left            =   120
      TabIndex        =   17
      Top             =   60
      Width           =   5415
   End
End
Attribute VB_Name = "Instalare"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'*******************************************************************************************

'                       Software & Copyright by Paul Gagniuc Aurelian

'*******************************************************************************************

Private Declare Function ShellExecute Lib "shell32.dll" Alias "ShellExecuteA" (ByVal hWnd As Long, ByVal lpOperation As String, ByVal lpFile As String, ByVal lpParameters As String, ByVal lpDirectory As String, ByVal nShowCmd As Long) As Long

Private Declare Function LoadCursorFromFile Lib "user32" Alias "LoadCursorFromFileA" (ByVal lpFileName As String) As Long
Private Declare Function SetClassLong Lib "user32" Alias "SetClassLongA" (ByVal hWnd As Long, ByVal nIndex As Long, ByVal dwNewLong As Long) As Long

Private Declare Function SendMessage Lib "user32" Alias "SendMessageA" (ByVal hWnd As Long, ByVal wMsg As Long, ByVal wParam As Long, lParam As Any) As Long
Private Declare Sub ReleaseCapture Lib "user32" ()

Private Declare Function mciExecute Lib "winmm.dll" (ByVal lpstrCommand As String) As Long


Const WM_NCLBUTTONDOWN = &HA1
Const HTCAPTION = 2

Private Const Mouse_eu = (-12)
Private Incarca_mouse_Vechi As Long

Public Directorul_este As String
Public Index_Cunoscut As String

Dim Paul_BTest As Variant
Dim Paul_FSize As Variant

Public GeneralSunet As Boolean
Public Voce_Revista_Sunet As Boolean

Public Bula_Sunet As Boolean

Private Sub Ajutaj_Click()
Ajutorul_Click
End Sub

Private Sub Ajutorul_Click()
On Error Resume Next
Sterge_tot

DoEvents
Text_Imagine.Navigate (App.Path & "\aferent\Ajutor.htm")
DoEvents

Picture1.Visible = False
Picture2.Visible = False
Picture3.Visible = False
Picture4.Visible = False
Linie.Visible = False

Crater_UMJIA.Visible = False
Crater_UMJIA2.Visible = False



End Sub

Private Sub Arata_La_suta_Timer()
Eu_la_suta.Caption = (100 - Int(100 * Paul_BTest / Paul_FSize)) & " %"
End Sub

Private Sub B_Sunet_Click()

If Bula_Sunet = False Then
SunetHTM.Navigate (App.Path & "\aferent\Negativ\S1.htm")
Bula_Sunet = True
Mesaj_sunet.Caption = "ON"
Else
Bula_Sunet = False
SunetHTM.Navigate (App.Path & "\aferent\Negativ\S0.htm")
Mesaj_sunet.Caption = "OFF"
End If

End Sub

Private Sub Bara_principal_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
If Button = 1 Then
Call ReleaseCapture
lngReturnValue = SendMessage(Me.hWnd, WM_NCLBUTTONDOWN, HTCAPTION, 0&)
End If
End Sub

Private Sub Copiere_Click()
Dim Mesterul_Manole As String
On Error Resume Next

On Error Resume Next
If Bula_Sunet = True Then
SunetHTM.Navigate (App.Path & "\aferent\Negativ\S0.htm")
End If
Bula_Sunet = False
Mesaj_sunet.Caption = "OFF"

MegaHz (App.Path & "\aferent\Negativ\voce\copiere.wav")

Mesterul_Manole = App.Path & "\aferent\Kit\" & Directorul_este & "\" & Index_Cunoscut & "\" & "Kit\Kit.zip"

Bara_copiere.Visible = True
Eu_la_suta.Visible = True
Sectiune69(2).Visible = False

'Da_domnule.Text = "C:\PC_World\" & Meniu_Programe(Index_Cunoscut).Caption & ".zip"

Dimensiune.Caption = Copiere_Fisier(Mesterul_Manole, Da_domnule.Text)

Bara_copiere.Visible = False
Eu_la_suta.Visible = False
Sectiune69(2).Visible = True


'Da_domnule.Text = "C:\PC_World\Kit(_" & XX(6) & "_).zip"
End Sub

Private Sub Despre_Click()
On Error Resume Next
DespreYO.Show

If Bula_Sunet = True Then
SunetHTM.Navigate (App.Path & "\aferent\Negativ\S0.htm")
End If
Bula_Sunet = False
Mesaj_sunet.Caption = "OFF"

MegaHz (App.Path & "\aferent\Negativ\voce\Eu.wav")


End Sub

Private Sub Driver_Click()
On Error Resume Next
Sterge_tot

DoEvents
Text_Imagine.Navigate (App.Path & "\aferent\Drivere.htm")
DoEvents

Picture1.Visible = False
Picture2.Visible = False
Picture3.Visible = False
Picture4.Visible = False
Linie.Visible = False

Crater_UMJIA.Visible = False
Crater_UMJIA2.Visible = False



Index_Cunoscut = ""

End Sub

Private Sub Form_Load()
Dim Mouse_nou As Long
On Error Resume Next
If App.PrevInstance Then End

Sterge_tot

Picture1.Visible = False
Picture2.Visible = False
Picture3.Visible = False
Picture4.Visible = False
Linie.Visible = False

Crater_UMJIA.Visible = False
Crater_UMJIA2.Visible = False

'Text_Imagine.Navigate (App.Path & "\aferent\Intrare.htm")

Mouse_nou = LoadCursorFromFile(App.Path & "\aferent\Cruce.ani")
Incarca_mouse_Vechi = SetClassLong(Me.hWnd, Mouse_eu, Mouse_nou)


Listare_Tip_GIF1.LoadFromFile (App.Path & "\YesNo.GIF")
Listare_Tip_GIF1.Play

'Sunet.Enabled = True

Da_domnule.Text = "C:\PC_World\Kit_(" & XX(5) & ").zip"

On Error Resume Next

MkDir ("c:\PC_World")


For DaQ = 1 To 18
Meniu_Programe(DaQ).Top = Meniu_Programe(DaQ - 1).Top + Meniu_Programe(DaQ - 1).Height
DoEvents
Next DaQ

On Error Resume Next
Voce.Navigate (App.Path & "\aferent\Negativ\nimic.htm")
Informatii.Navigate (App.Path & "\aferent\Negativ\Negativ.htm")

Listare_Tip_GIF1.LoadFromFile (App.Path & "\aferent\Negativ\Negativ.gif")
Listare_Tip_GIF1.Play

Voce_Revista_Sunet = True
GeneralSunet = True
Bula_Sunet = True

End Sub


Private Sub Form_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)

If Button = 1 Then
Call ReleaseCapture
lngReturnValue = SendMessage(hWnd, WM_NCLBUTTONDOWN, HTCAPTION, 0&)
End If

End Sub

Private Sub Iesire_Click()
Unload Me
End
End Sub

Private Sub Citire_Click()
'ShellExecute hWnd, "open", App.Path & "\aferent\Kit\" & Directorul_este & "\" & Index_Cunoscut & "\Citeste_ma.txt", vbNullString, vbNullString, conSwNormal
On Error Resume Next

fura = FreeFile

Citeste.Show
DoEvents

If Bula_Sunet = True Then
DoEvents
SunetHTM.Navigate (App.Path & "\aferent\Negativ\S0.htm")
DoEvents
End If
Bula_Sunet = False
Mesaj_sunet.Caption = "OFF"

DoEvents
MegaHz (App.Path & "\aferent\Negativ\voce\citeste.wav")

Open App.Path & "\aferent\Kit\" & Directorul_este & "\" & Index_Cunoscut & "\Citeste_ma.txt" For Input As #fura

Do While Not EOF(fura)
Line Input #fura, LinieCitita
DoEvents
Citeste.Formular_citire.Text = Citeste.Formular_citire.Text & vbCrLf & LinieCitita

Loop

Close #fura

End Sub

Private Sub Listare_Tip_GIF1_Click()
On Error Resume Next
If Index_Cunoscut = "" Then Exit Sub

Captura.Bara_principal.Caption = " PC World  -  " & Meniu_Programe(Index_Cunoscut).Caption
Captura.EcranMare.LoadFromFile (App.Path & "\aferent\" & Directorul_este & "\img\" & Index_Cunoscut & ".gif")
Captura.EcranMare.Play
Captura.Show

On Error Resume Next
If Bula_Sunet = True Then
SunetHTM.Navigate (App.Path & "\aferent\Negativ\S0.htm")
End If
Bula_Sunet = False
Mesaj_sunet.Caption = "OFF"

MegaHz (App.Path & "\aferent\Negativ\voce\copiaza_in.wav")
End Sub

Private Sub Rulare_Click()

On Error Resume Next
If Bula_Sunet = True Then
SunetHTM.Navigate (App.Path & "\aferent\Negativ\S0.htm")
End If
Bula_Sunet = False
Mesaj_sunet.Caption = "OFF"


MegaHz (App.Path & "\aferent\Negativ\voce\rulare.wav")
ShellExecute hWnd, "open", App.Path & "\aferent\Kit\" & Directorul_este & "\" & Index_Cunoscut & "\" & Index_Cunoscut & "_Rulare\Aplicatie.exe", vbNullString, vbNullString, conSwNormal
End Sub


Private Sub Instalare_Click()

On Error Resume Next
If Bula_Sunet = True Then
SunetHTM.Navigate (App.Path & "\aferent\Negativ\S0.htm")
End If
Bula_Sunet = False
Mesaj_sunet.Caption = "OFF"

MegaHz (App.Path & "\aferent\Negativ\voce\instalare.wav")
ShellExecute hWnd, "open", App.Path & "\aferent\Kit\" & Directorul_este & "\" & Index_Cunoscut & "\" & Index_Cunoscut & "_Instalare\setup.exe", vbNullString, vbNullString, conSwNormal
End Sub

Private Sub IntroEU_Click()
On Error Resume Next
Sterge_tot

DoEvents
Text_Imagine.Navigate (App.Path & "\aferent\Intrare.htm")
DoEvents

Picture1.Visible = False
Picture2.Visible = False
Picture3.Visible = False
Picture4.Visible = False
Linie.Visible = False

Crater_UMJIA.Visible = False
Crater_UMJIA2.Visible = False



Index_Cunoscut = ""

End Sub

Private Sub Meniu_Programe_MouseOut(Index As Integer, Shift As Integer)
Meniu_Programe(Index).ForeColor = 16777215
End Sub

Private Sub Meniu_Programe_MouseIn(Index As Integer, Shift As Integer)
Meniu_Programe(Index).ForeColor = &H0&
End Sub

Private Sub Meniu_Programe_Click(Index As Integer)
On Error Resume Next
Index_Cunoscut = Index

Da_domnule.Text = "C:\PC_World\" & Meniu_Programe(Index_Cunoscut).Caption & ".zip"

DoEvents
Informatii.Navigate (App.Path & "\aferent\" & Directorul_este & "\" & Index & ".htm")
DoEvents

Listare_Tip_GIF1.LoadFromFile (App.Path & "\aferent\" & Directorul_este & "\" & Index & ".gif")
Listare_Tip_GIF1.Play

zulu_alfa_eu (Index)

End Sub

Private Sub zulu_alfa_eu(ByVal numar As Variant)

If FileExist(App.Path & "\aferent\Kit\" & Directorul_este & "\" & Index_Cunoscut & "\" & Index_Cunoscut & "_Instalare\setup.exe") = True Then
Instalare.Enabled = True
Else
Instalare.Enabled = False
End If

If FileExist(App.Path & "\aferent\Kit\" & Directorul_este & "\" & Index_Cunoscut & "\" & Index_Cunoscut & "_Rulare\Aplicatie.exe") = True Then
Rulare.Enabled = True
Else
Rulare.Enabled = False
End If

If FileExist(App.Path & "\aferent\Kit\" & Directorul_este & "\" & Index_Cunoscut & "\" & "Kit\Kit.zip") = True Then
Copiere.Enabled = True

Unde.Visible = True
Da_domnule.Visible = True

Else
Copiere.Enabled = False

Unde.Visible = False
Da_domnule.Visible = False
Unload Alegere_dir

End If

If FileExist(App.Path & "\aferent\Kit\" & Directorul_este & "\" & Index_Cunoscut & "\Citeste_ma.txt") = True Then
Citire.Enabled = True
Else
Citire.Enabled = False
End If

End Sub


Private Sub Micro_Click()
Me.WindowState = 1
End Sub

Private Sub Micsorare_Click()
On Error Resume Next
Me.WindowState = 1
End Sub

Private Sub PaulGagniuc_OnLine_Click()
On Error Resume Next
ShellExecute hWnd, "open", "http://www.pcworld.ro", vbNullString, vbNullString, conSwNormal
End Sub

Private Sub Sectiune69_Click(Index As Integer)
ShellExecute hWnd, "open", "http://www.pcworld.ro", vbNullString, vbNullString, conSwNormal
End Sub

Private Sub Sunet_Timer()

Dim X

X = mciExecute("Play " & App.Path & "\aferent\S_fundal.wav")

Sunet.Enabled = False

'MsgBox App.Path & "\aferent\S_fundal.wav"
End Sub

Private Sub Sterge_tot()
For zulu = 0 To 18
DoEvents
Meniu_Programe(zulu).Visible = False
Next zulu
End Sub


Function Deschide_citeste(ByVal fisierEU As String)
fura = FreeFile
warza = 0

Open App.Path & fisierEU For Input As #fura

Do While Not EOF(fura)
Line Input #fura, LinieButon

MasterProces = LinieButon

alfa = 0

1:
Khazadum = InStr(MasterProces, "|")
Textmeniu = Mid(MasterProces, 1, Khazadum - 1)
MasterProces = Mid(MasterProces, InStr(MasterProces, "|") + 1, Len(MasterProces))



'MsgBox Textmeniu

If alfa = 0 Then
ConditieHTML = Textmeniu
End If

If alfa = 1 Then
Meniu_Programe(warza).Caption = Textmeniu
Meniu_Programe(warza).Visible = True
End If

If alfa = 2 Then

End If

alfa = alfa + 1

If MasterProces = "" Then GoTo 2

GoTo 1

2:



warza = warza + 1

Loop

Close #fura

End Function

Private Sub Unde_Click()

On Error Resume Next

Alegere_dir.Show

If Bula_Sunet = True Then
SunetHTM.Navigate (App.Path & "\aferent\Negativ\S0.htm")
End If
Bula_Sunet = False
Mesaj_sunet.Caption = "OFF"

MegaHz (App.Path & "\aferent\Negativ\voce\copiaza_in.wav")


End Sub

Private Sub Utilitare_Click()
On Error Resume Next
Sterge_tot

Informatii.Navigate (App.Path & "\aferent\Negativ\Negativ.htm")
Listare_Tip_GIF1.LoadFromFile (App.Path & "\aferent\Negativ\Negativ.gif")
Listare_Tip_GIF1.Play


Unde.Visible = False
Da_domnule.Visible = False
Unload Alegere_dir

Instalare.Enabled = False
Rulare.Enabled = False
Citire.Enabled = False
Copiere.Enabled = False

Picture1.Visible = True
Picture2.Visible = True
Picture3.Visible = True
Picture4.Visible = True
Linie.Visible = True

Crater_UMJIA.Visible = True
Crater_UMJIA2.Visible = True

Index_Cunoscut = ""

Directorul_este = "UT"

Deschide_citeste ("/aferent/UT.zulu")

Sectiune(0).Caption = "Utilitare"
Sectiune(1).Caption = "Utilitare"

Voce_Meniuri
End Sub

Private Sub Multimedia_Click()
On Error Resume Next
Sterge_tot

Informatii.Navigate (App.Path & "\aferent\Negativ\Negativ.htm")
Listare_Tip_GIF1.LoadFromFile (App.Path & "\aferent\Negativ\Negativ.gif")
Listare_Tip_GIF1.Play


Unde.Visible = False
Da_domnule.Visible = False
Unload Alegere_dir

Instalare.Enabled = False
Rulare.Enabled = False
Citire.Enabled = False
Copiere.Enabled = False

Picture1.Visible = True
Picture2.Visible = True
Picture3.Visible = True
Picture4.Visible = True
Linie.Visible = True

Crater_UMJIA.Visible = True
Crater_UMJIA2.Visible = True

Index_Cunoscut = ""

Directorul_este = "MM"

Deschide_citeste ("/aferent/MM.zulu")

Sectiune(0).Caption = "Multimedia"
Sectiune(1).Caption = "Multimedia"

Voce_Meniuri
End Sub


Private Sub Jocuri_Click()
On Error Resume Next
Sterge_tot

Informatii.Navigate (App.Path & "\aferent\Negativ\Negativ.htm")
Listare_Tip_GIF1.LoadFromFile (App.Path & "\aferent\Negativ\Negativ.gif")
Listare_Tip_GIF1.Play


Unde.Visible = False
Da_domnule.Visible = False
Unload Alegere_dir

Instalare.Enabled = False
Rulare.Enabled = False
Citire.Enabled = False
Copiere.Enabled = False

Picture1.Visible = True
Picture2.Visible = True
Picture3.Visible = True
Picture4.Visible = True
Linie.Visible = True

Crater_UMJIA.Visible = True
Crater_UMJIA2.Visible = True

Index_Cunoscut = ""

Directorul_este = "JC"

Deschide_citeste ("/aferent/JC.zulu")

Sectiune(0).Caption = "Jocuri"
Sectiune(1).Caption = "Jocuri"

Voce_Meniuri
End Sub

Private Sub Internet_Click()
On Error Resume Next
Sterge_tot

Informatii.Navigate (App.Path & "\aferent\Negativ\Negativ.htm")
Listare_Tip_GIF1.LoadFromFile (App.Path & "\aferent\Negativ\Negativ.gif")
Listare_Tip_GIF1.Play

Unde.Visible = False
Da_domnule.Visible = False
Unload Alegere_dir

Instalare.Enabled = False
Rulare.Enabled = False
Citire.Enabled = False
Copiere.Enabled = False

Picture1.Visible = True
Picture2.Visible = True
Picture3.Visible = True
Picture4.Visible = True
Linie.Visible = True

Crater_UMJIA.Visible = True
Crater_UMJIA2.Visible = True

Index_Cunoscut = ""

Directorul_este = "IN"

Deschide_citeste ("/aferent/IN.zulu")

Sectiune(0).Caption = "Internet"
Sectiune(1).Caption = "Internet"

Voce_Meniuri
End Sub


Private Sub Antivirus_Click()
On Error Resume Next
Sterge_tot

Informatii.Navigate (App.Path & "\aferent\Negativ\Negativ.htm")
Listare_Tip_GIF1.LoadFromFile (App.Path & "\aferent\Negativ\Negativ.gif")
Listare_Tip_GIF1.Play

Unde.Visible = False
Da_domnule.Visible = False
Unload Alegere_dir

Instalare.Enabled = False
Rulare.Enabled = False
Citire.Enabled = False
Copiere.Enabled = False

Picture1.Visible = True
Picture2.Visible = True
Picture3.Visible = True
Picture4.Visible = True
Linie.Visible = True

Crater_UMJIA.Visible = True
Crater_UMJIA2.Visible = True

Index_Cunoscut = ""

Directorul_este = "AV"

Deschide_citeste ("/aferent/AV.zulu")

Sectiune(0).Caption = "Antivirus"
Sectiune(1).Caption = "Antivirus"

Voce_Meniuri
End Sub

Private Sub Permanente_Click()
On Error Resume Next
Sterge_tot

Informatii.Navigate (App.Path & "\aferent\Negativ\Negativ.htm")
Listare_Tip_GIF1.LoadFromFile (App.Path & "\aferent\Negativ\Negativ.gif")
Listare_Tip_GIF1.Play

Unde.Visible = False
Da_domnule.Visible = False
Unload Alegere_dir

Instalare.Enabled = False
Rulare.Enabled = False
Citire.Enabled = False
Copiere.Enabled = False

Picture1.Visible = True
Picture2.Visible = True
Picture3.Visible = True
Picture4.Visible = True
Linie.Visible = True

Crater_UMJIA.Visible = True
Crater_UMJIA2.Visible = True

Index_Cunoscut = ""

Directorul_este = "PR"

Deschide_citeste ("/aferent/PR.zulu")

Sectiune(0).Caption = "Permanente"
Sectiune(1).Caption = "Permanente"

Voce_Meniuri
End Sub




Private Sub Voce_Revista()

If Bula_Sunet = False Then
If Voce_Revista_Sunet = True Then
Voce.Navigate (App.Path & "\aferent\Negativ\Voce2.htm")
End If
End If

Voce_Revista_Sunet = False
End Sub

Private Sub Voce_Meniuri()

If Bula_Sunet = False Then
If GeneralSunet = True Then
Voce.Navigate (App.Path & "\aferent\Negativ\Voce1.htm")
End If
End If

GeneralSunet = False
End Sub

Private Sub Revista_Click()
On Error Resume Next
Sterge_tot

DoEvents
Text_Imagine.Navigate (App.Path & "\aferent\Revista.htm")
DoEvents

Picture1.Visible = False
Picture2.Visible = False
Picture3.Visible = False
Picture4.Visible = False
Linie.Visible = False

Crater_UMJIA.Visible = False
Crater_UMJIA2.Visible = False

Index_Cunoscut = ""

Sectiune(0).Caption = "Revista"
Sectiune(1).Caption = "Revista"

Voce_Revista
DoEvents
End Sub

Private Sub X_Iesire_Click()
Unload Me
End
End Sub
'Success = ShellExecute(0&, vbNullString, "mailto:" & email, vbNullString, "C:\", SW_SHOWNORMAL)



Public Function FileExist(aFile As String) As Boolean
On Error GoTo 23

If aFile = "" Then
FileExist = False
Exit Function
End If

If Dir$(aFile) = "" Then
If Dir$(aFile, vbHidden) = "" Then
FileExist = False
Else
FileExist = True
End If
Else
FileExist = True
End If
Exit Function
23:
FileExist = False
'KillPC
End Function

Function Copiere_Fisier(src As String, dst As String) As Single
On Error Resume Next
 Static Buf$
 Dim BTest!, FSize!
 Dim Chunk%, F1%, F2%

 Const BUFSIZE = 1024

'Un buffer mai mare e mai bun dar nu tre' sa depasesc 64k

   If Dir(src) = "" Then MsgBox "Fisierul nu a fost gasit": Exit Function
   If Len(Dir(dst)) Then
      If MsgBox(UCase(dst) & Chr(13) & Chr(10) & "Fisierul exista ! " & vbCrLf & vbCrLf & "Suprascriem fisierul?", 4) <> 6 Then Exit Function
      Kill dst
   End If
 
 Bara_copiere.Cls
 
 Arata_La_suta.Enabled = True
 
   On Error GoTo Eruare
   F1 = FreeFile
   Open src For Binary As F1
   F2 = FreeFile
   Open dst For Binary As F2
 
   FSize = LOF(F1)
   BTest = FSize - LOF(F2)
   Do
      If BTest < BUFSIZE Then
         Chunk = BTest
      Else
         Chunk = BUFSIZE
      End If
      Buf = String(Chunk, " ")
      Get F1, , Buf
      Put F2, , Buf
      BTest = FSize - LOF(F2)

zz = (Bara_copiere.ScaleWidth / 100) * (100 - Int(100 * BTest / FSize))
Bara_copiere.Line (0, 0)-(zz, 20), &HFFFF&, BF

Paul_BTest = BTest
Paul_FSize = FSize

DoEvents
   Loop Until BTest = 0
   Close F1
   Close F2

   Copiere_Fisier = FSize
   Exit Function

Eruare:
   MsgBox "Copierea fisierului nu a putut fi facuta !"
   Close F1
   Close F2
   
   Arata_La_suta.Enabled = False
   
   Exit Function
End Function
