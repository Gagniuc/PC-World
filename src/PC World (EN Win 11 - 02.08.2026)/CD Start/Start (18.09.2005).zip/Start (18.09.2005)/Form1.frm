VERSION 5.00
Begin VB.Form YO 
   BackColor       =   &H00000000&
   BorderStyle     =   0  'None
   Caption         =   "Film-PCW"
   ClientHeight    =   8265
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   11220
   Icon            =   "Form1.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   Picture         =   "Form1.frx":57E2
   ScaleHeight     =   551
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   748
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Begin VB.Timer Hai_pa 
      Enabled         =   0   'False
      Interval        =   4500
      Left            =   3840
      Top             =   8400
   End
   Begin VB.CommandButton Stop 
      Caption         =   "Stop"
      Height          =   375
      Left            =   5640
      TabIndex        =   1
      Top             =   8400
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.CommandButton Hai 
      Caption         =   "Play"
      Height          =   375
      Left            =   4320
      TabIndex        =   0
      Top             =   8400
      Visible         =   0   'False
      Width           =   1215
   End
End
Attribute VB_Name = "YO"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Declare Function mciSendString Lib "winmm.dll" Alias "mciSendStringA" (ByVal lpstrCommand As String, ByVal lpstrReturnString As String, ByVal uReturnLength As Long, ByVal hwndCallback As Long) As Long
Private Declare Function GetShortPathName Lib "kernel32" Alias "GetShortPathNameA" (ByVal lpszLongPath As String, ByVal lpszShortPath As String, ByVal cchBuffer As Long) As Long
Private Declare Function GetActiveWindow Lib "user32" () As Long
Private Declare Function SetWindowText Lib "user32" Alias "SetWindowTextA" (ByVal hWnd As Long, ByVal lpString As String) As Long

Private Declare Function ShellExecute Lib "shell32.dll" Alias "ShellExecuteA" (ByVal hWnd As Long, ByVal lpOperation As String, ByVal lpFile As String, ByVal lpParameters As String, ByVal lpDirectory As String, ByVal nShowCmd As Long) As Long


Dim wHandler As Long
Dim TrackLength As String * 60
Dim a As Integer, cou As Integer
Dim tt As Boolean


Public Function GetShortName(ByVal sLongFileName As String) As String
On Error Resume Next
    Dim lRetVal As Long
    Dim sShortPathName As String
    Dim iLen As Integer
    sShortPathName = Space(255)
    iLen = Len(sShortPathName)
    lRetVal = GetShortPathName(sLongFileName, sShortPathName, iLen)
    GetShortName = Left(sShortPathName, lRetVal)
End Function

Private Sub Form_Load()
On Error Resume Next

Hai_Click
Hai_pa.Enabled = True
ShellExecute hWnd, "open", App.Path & "\Control.exe", vbNullString, vbNullString, conSwNormal
End Sub

Private Sub Form_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
End
End Sub

Private Sub Form_Unload(Cancel As Integer)
On Error Resume Next
mciSendString "close all", vbNullString, 0, 0
ShellExecute hWnd, "open", App.Path & "\CD.exe", vbNullString, vbNullString, conSwNormal
End Sub

Private Sub Hai_Click()
    On Error Resume Next
    
    fShortName = GetShortName(App.Path & "\aferent\Start.avi")
    
    
    mciSendString "close all", vbNullString, 0, 0
    mciSendString "open " & fShortName & " type MPEGVideo style child alias mpeg parent " & Me.hWnd, vbNullString, 0, 0
    
    mciSendString "status mpeg length", TrackLength, Len(TrackLength), 0
    
    mciSendString "put mpeg window at 0 0 748 560", 0&, 0, 0
    mciSendString "set window show maximized", vbNullString, 0, 0
    
    mciSendString "play mpeg", vbNullString, 0, 0
    'mciSendString "play mpeg fullscreen", vbNullString, 0, 0
    
      
    
    'mciSendString(MOV_SEEK_TO_START, NULL, 0, NULL);
    'mciSendString(MOV_SOURCE, achRect, sizeof(achRect), NULL);
    'mciSendString(MOV_REVERSE, NULL, 0, hWnd);
    'mciSendString(MOV_FORWARD, NULL, 0, hWnd);
    'mciSendString(MOV_PAUSE, NULL, 0, NULL);
    'mciSendString(MOV_SEEK_TO_START, NULL, 0, NULL);
    'mciSendString(MOV_SEEK_TO_END, NULL, 0, NULL);
    '
    'mciSendString(MOV_FORWARD_STEP, NULL, 0, NULL)
    'mciSendString(MOV_REVERSE_STEP, NULL,0, NULL);

End Sub

Private Sub Hai_pa_Timer()
Unload Me
End Sub

Private Sub Stop_Click()
    mciSendString "stop mpeg", vbNullString, 0, 0
    mciSendString "close all", vbNullString, 0, 0
End Sub
