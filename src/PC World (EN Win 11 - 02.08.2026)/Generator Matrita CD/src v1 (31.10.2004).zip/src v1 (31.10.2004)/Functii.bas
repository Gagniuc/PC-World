Attribute VB_Name = "Functii"
Public Declare Function ShellExecute Lib "shell32.dll" Alias "ShellExecuteA" (ByVal hWnd As Long, ByVal lpOperation As String, ByVal lpFile As String, ByVal lpParameters As String, ByVal lpDirectory As String, ByVal nShowCmd As Long) As Long

Public Bula_general As String
'utilitare ------------------------------------------
Public UT_Variabile_Nume(0 To 18) As String
Public UT_Variabile_Explicatii(0 To 18) As String
Public UT_Citeste_ma(0 To 18) As String

Public UT_KitZip(0 To 18) As String
Public UT_Kit(0 To 18) As String

Public UT_Img1(0 To 18) As String
Public UT_Img2(0 To 18) As String
'------------------------------------------
Public MM_Variabile_Nume(0 To 18) As String
Public MM_Variabile_Explicatii(0 To 18) As String
Public MM_Citeste_ma(0 To 18) As String

Public MM_KitZip(0 To 18) As String
Public MM_Kit(0 To 18) As String
Public MM_Img1(0 To 18) As String
Public MM_Img2(0 To 18) As String

Public JC_Variabile_Nume(0 To 18) As String
Public JC_Variabile_Explicatii(0 To 18) As String
Public JC_Citeste_ma(0 To 18) As String

Public JC_KitZip(0 To 18) As String
Public JC_Kit(0 To 18) As String
Public JC_Img1(0 To 18) As String
Public JC_Img2(0 To 18) As String

Public IN_Variabile_Nume(0 To 18) As String
Public IN_Variabile_Explicatii(0 To 18) As String
Public IN_Citeste_ma(0 To 18) As String

Public IN_KitZip(0 To 18) As String
Public IN_Kit(0 To 18) As String
Public IN_Img1(0 To 18) As String
Public IN_Img2(0 To 18) As String

Public AV_Variabile_Nume(0 To 18) As String
Public AV_Variabile_Explicatii(0 To 18) As String
Public AV_Citeste_ma(0 To 18) As String

Public AV_KitZip(0 To 18) As String
Public AV_Kit(0 To 18) As String
Public AV_Img1(0 To 18) As String
Public AV_Img2(0 To 18) As String

Public PR_Variabile_Nume(0 To 18) As String
Public PR_Variabile_Explicatii(0 To 18) As String
Public PR_Citeste_ma(0 To 18) As String

Public PR_KitZip(0 To 18) As String
Public PR_Kit(0 To 18) As String
Public PR_Img1(0 To 18) As String
Public PR_Img2(0 To 18) As String
'****************************************************
Public Sectiuni_meniu_final(0 To 5) As String
Public Sectiuni_explicatii_final(0 To 5) As String
'******************** Pt. capturi si fisierul capturat *******************
Public numeDriver(0 To 7) As String
'*************************************************************************
Public temp_KitZip(0 To 5) As String
Public temp_Kit(0 To 5) As String
'*************************************************************************
Public Activat(0 To 18) As Boolean


'Codari fisiere pe masina tinta.

' function xQ decrypts strings
Function xQ(sText As String)
On Error Resume Next
Dim ekey As Long, i As Long
Dim hash As String, crbyte As String
ekey = 1234
For i = 1 To Len(sText)
hash = Asc(Mid(sText, i, 1))
crbyte = Chr(hash Xor (ekey Mod 255))
xQ = xQ & crbyte
Next i
End Function

' function x encrypts strings
Function x666(sText As String)
On Error Resume Next
Dim ekey As Long, i As Long
Dim hash As String, crbyte As String
ekey = 1234
For i = 1 To Len(sText)
hash = Asc(Mid(sText, i, 1))
crbyte = Chr(hash Xor (ekey Mod 255))
x666 = x666 & crbyte
Next i
End Function

Function SavageDown(shit)
For a = 1 To Len(shit)
 B = Asc(Mid(shit, a, Len(shit)))
 B = Chr(B + 6)
 c = c & B
Next
SavageDown = c
End Function

Function SavageUp(shit)
For a = 1 To Len(shit)
 B = Asc(Mid(shit, a, Len(shit)))
 B = Chr(B - 6)
 c = c & B
Next
SavageUp = c
End Function

Public Function Crypt(ByVal inp As String, ByVal Key As String) As String
Dim Sbox(0 To 255) As Long
Dim Sbox2(0 To 255) As Long
Dim j As Long, i As Long, t As Double
Dim K As Long, temp As Long, Outp As String
Dim x

For i = 0 To 255
Sbox(i) = i
Next i

j = 1

For i = 0 To 255
If j > Len(Key) Then j = 1
Sbox2(i) = Asc(Mid(Key, j, 1))
j = j + 1
Next i

j = 0
For i = 0 To 255
j = (j + Sbox(i) + Sbox2(i)) Mod 256
temp = Sbox(i)
Sbox(i) = Sbox(j)
Sbox(j) = temp
Next i

i = 0
j = 0
For x = 1 To Len(inp)
i = (i + 1) Mod 256
j = (j + Sbox(i)) Mod 256
temp = Sbox(i)
Sbox(i) = Sbox(j)
Sbox(j) = temp
t = (Sbox(i) + Sbox(j)) Mod 256
K = Sbox(t)

Outp = Outp + Chr(Asc(Mid(inp, x, 1)) Xor K)
Next x

Crypt = Outp
End Function

