VERSION 5.00
Object = "{BDC217C8-ED16-11CD-956C-0000C04E4C0A}#1.1#0"; "TABCTL32.OCX"
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "COMDLG32.OCX"
Object = "{EAB22AC0-30C1-11CF-A7EB-0000C05BAE0B}#1.1#0"; "shdocvw.dll"
Begin VB.Form Geneza 
   Caption         =   "Matrita CD - PC World  [Versiunea 0.2] - program de Paul Gagniuc [octombrie 2004]"
   ClientHeight    =   10095
   ClientLeft      =   60
   ClientTop       =   450
   ClientWidth     =   12570
   Icon            =   "Form1.frx":0000
   LinkTopic       =   "Form1"
   ScaleHeight     =   673
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   838
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton Command1 
      Caption         =   "Command1"
      Height          =   375
      Left            =   8160
      TabIndex        =   420
      Top             =   120
      Width           =   375
   End
   Begin GenerareMatrita.Buton_3D_General Pachet 
      Height          =   495
      Left            =   840
      TabIndex        =   388
      Top             =   9480
      Width           =   4335
      _ExtentX        =   7646
      _ExtentY        =   873
      Caption         =   "Compileaza - ( PCWorld- boot CD)"
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Times New Roman"
         Size            =   14.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin MSComDlg.CommonDialog Salveaza_Deschide 
      Left            =   4080
      Top             =   120
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
   End
   Begin VB.CommandButton Salveaza_fisier 
      Caption         =   "Salveaza sursa ..."
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   2400
      TabIndex        =   387
      Top             =   120
      Width           =   2175
   End
   Begin VB.CommandButton Deschide_Fisier 
      Caption         =   "Deschide sursa ..."
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   120
      TabIndex        =   386
      Top             =   120
      Width           =   2175
   End
   Begin VB.CommandButton Grafica 
      Caption         =   "Modificare GRAFICA"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   855
      Left            =   5040
      TabIndex        =   385
      Top             =   10560
      Width           =   3735
   End
   Begin VB.CommandButton Dezactivari 
      Caption         =   "DEZACTIVARI butoane interfata"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   4920
      TabIndex        =   384
      Top             =   120
      Width           =   3135
   End
   Begin VB.CommandButton Captura_Mare666 
      Caption         =   "...: Captura :.."
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   8760
      TabIndex        =   383
      Top             =   120
      Width           =   2175
   End
   Begin VB.CommandButton Capturare 
      Caption         =   "...: Despre :..."
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   11040
      TabIndex        =   382
      Top             =   120
      Width           =   1455
   End
   Begin MSComDlg.CommonDialog Salvare_matrita 
      Left            =   11400
      Top             =   10320
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
   End
   Begin VB.TextBox Cale_matrita 
      BackColor       =   &H00000000&
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   13.5
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H0000FF00&
      Height          =   435
      Left            =   7200
      TabIndex        =   200
      Text            =   "C:\PC_World"
      Top             =   9480
      Width           =   5295
   End
   Begin MSComDlg.CommonDialog Deschide 
      Left            =   12000
      Top             =   10320
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
   End
   Begin TabDlg.SSTab Master_Control 
      Height          =   8655
      Left            =   120
      TabIndex        =   0
      Top             =   600
      Width           =   12375
      _ExtentX        =   21828
      _ExtentY        =   15266
      _Version        =   393216
      Style           =   1
      Tabs            =   12
      TabsPerRow      =   12
      TabHeight       =   529
      TabCaption(0)   =   "Utilitare"
      TabPicture(0)   =   "Form1.frx":0D2A
      Tab(0).ControlEnabled=   -1  'True
      Tab(0).Control(0)=   "Label28(0)"
      Tab(0).Control(0).Enabled=   0   'False
      Tab(0).Control(1)=   "Line10(0)"
      Tab(0).Control(1).Enabled=   0   'False
      Tab(0).Control(2)=   "Line9(0)"
      Tab(0).Control(2).Enabled=   0   'False
      Tab(0).Control(3)=   "Line8(0)"
      Tab(0).Control(3).Enabled=   0   'False
      Tab(0).Control(4)=   "BorduraTemp(0)"
      Tab(0).Control(4).Enabled=   0   'False
      Tab(0).Control(5)=   "Label1"
      Tab(0).Control(5).Enabled=   0   'False
      Tab(0).Control(6)=   "Label2"
      Tab(0).Control(6).Enabled=   0   'False
      Tab(0).Control(7)=   "ListaMare(0)"
      Tab(0).Control(7).Enabled=   0   'False
      Tab(0).Control(8)=   "ListaMare(1)"
      Tab(0).Control(8).Enabled=   0   'False
      Tab(0).Control(9)=   "ListaMare(2)"
      Tab(0).Control(9).Enabled=   0   'False
      Tab(0).Control(10)=   "ListaMare(3)"
      Tab(0).Control(10).Enabled=   0   'False
      Tab(0).Control(11)=   "ListaMare(4)"
      Tab(0).Control(11).Enabled=   0   'False
      Tab(0).Control(12)=   "ListaMare(5)"
      Tab(0).Control(12).Enabled=   0   'False
      Tab(0).Control(13)=   "ListaMare(6)"
      Tab(0).Control(13).Enabled=   0   'False
      Tab(0).Control(14)=   "ListaMare(7)"
      Tab(0).Control(14).Enabled=   0   'False
      Tab(0).Control(15)=   "ListaMare(8)"
      Tab(0).Control(15).Enabled=   0   'False
      Tab(0).Control(16)=   "ListaMare(9)"
      Tab(0).Control(16).Enabled=   0   'False
      Tab(0).Control(17)=   "ListaMare(10)"
      Tab(0).Control(17).Enabled=   0   'False
      Tab(0).Control(18)=   "ListaMare(11)"
      Tab(0).Control(18).Enabled=   0   'False
      Tab(0).Control(19)=   "ListaMare(12)"
      Tab(0).Control(19).Enabled=   0   'False
      Tab(0).Control(20)=   "ListaMare(13)"
      Tab(0).Control(20).Enabled=   0   'False
      Tab(0).Control(21)=   "ListaMare(14)"
      Tab(0).Control(21).Enabled=   0   'False
      Tab(0).Control(22)=   "ListaMare(15)"
      Tab(0).Control(22).Enabled=   0   'False
      Tab(0).Control(23)=   "ListaMare(16)"
      Tab(0).Control(23).Enabled=   0   'False
      Tab(0).Control(24)=   "ListaMare(17)"
      Tab(0).Control(24).Enabled=   0   'False
      Tab(0).Control(25)=   "Label3"
      Tab(0).Control(25).Enabled=   0   'False
      Tab(0).Control(26)=   "Line1(0)"
      Tab(0).Control(26).Enabled=   0   'False
      Tab(0).Control(27)=   "Label4"
      Tab(0).Control(27).Enabled=   0   'False
      Tab(0).Control(28)=   "Line1(1)"
      Tab(0).Control(28).Enabled=   0   'False
      Tab(0).Control(29)=   "BorduraGata(0)"
      Tab(0).Control(29).Enabled=   0   'False
      Tab(0).Control(30)=   "Line18(0)"
      Tab(0).Control(30).Enabled=   0   'False
      Tab(0).Control(31)=   "Trebuie_completat(0)"
      Tab(0).Control(31).Enabled=   0   'False
      Tab(0).Control(32)=   "Trebuie_completat(1)"
      Tab(0).Control(32).Enabled=   0   'False
      Tab(0).Control(33)=   "Trebuie_completat(2)"
      Tab(0).Control(33).Enabled=   0   'False
      Tab(0).Control(34)=   "Trebuie_completat(3)"
      Tab(0).Control(34).Enabled=   0   'False
      Tab(0).Control(35)=   "Trebuie_completat(4)"
      Tab(0).Control(35).Enabled=   0   'False
      Tab(0).Control(36)=   "Trebuie_completat(6)"
      Tab(0).Control(36).Enabled=   0   'False
      Tab(0).Control(37)=   "Trebuie_completat(64)"
      Tab(0).Control(37).Enabled=   0   'False
      Tab(0).Control(38)=   "Titlu(0)"
      Tab(0).Control(38).Enabled=   0   'False
      Tab(0).Control(39)=   "Explicatie(0)"
      Tab(0).Control(39).Enabled=   0   'False
      Tab(0).Control(40)=   "calea(0)"
      Tab(0).Control(40).Enabled=   0   'False
      Tab(0).Control(41)=   "cale2(0)"
      Tab(0).Control(41).Enabled=   0   'False
      Tab(0).Control(42)=   "kitZip(0)"
      Tab(0).Control(42).Enabled=   0   'False
      Tab(0).Control(43)=   "kit(0)"
      Tab(0).Control(43).Enabled=   0   'False
      Tab(0).Control(44)=   "IN_Lista(0)"
      Tab(0).Control(44).Enabled=   0   'False
      Tab(0).Control(45)=   "Citeste_Text(0)"
      Tab(0).Control(45).Enabled=   0   'False
      Tab(0).Control(46)=   "Inainte_de(0)"
      Tab(0).Control(46).Enabled=   0   'False
      Tab(0).Control(47)=   "ImagineM(0)"
      Tab(0).Control(47).Enabled=   0   'False
      Tab(0).Control(48)=   "IMica(0)"
      Tab(0).Control(48).Enabled=   0   'False
      Tab(0).Control(49)=   "Imagine_Mare(0)"
      Tab(0).Control(49).Enabled=   0   'False
      Tab(0).Control(50)=   "IMare(0)"
      Tab(0).Control(50).Enabled=   0   'False
      Tab(0).Control(51)=   "Sterge(0)"
      Tab(0).Control(51).Enabled=   0   'False
      Tab(0).Control(52)=   "Imagine_Meniu(0)"
      Tab(0).Control(52).Enabled=   0   'False
      Tab(0).Control(53)=   "Pro_imagine(0)"
      Tab(0).Control(53).Enabled=   0   'False
      Tab(0).ControlCount=   54
      TabCaption(1)   =   "Multimedia"
      TabPicture(1)   =   "Form1.frx":0D46
      Tab(1).ControlEnabled=   0   'False
      Tab(1).Control(0)=   "Line10(3)"
      Tab(1).Control(1)=   "Line9(1)"
      Tab(1).Control(2)=   "Line8(1)"
      Tab(1).Control(3)=   "BorduraTemp(1)"
      Tab(1).Control(4)=   "Line1(2)"
      Tab(1).Control(5)=   "Label5"
      Tab(1).Control(6)=   "Label6"
      Tab(1).Control(7)=   "Label7"
      Tab(1).Control(8)=   "Label8"
      Tab(1).Control(9)=   "Line2"
      Tab(1).Control(10)=   "ListaMareMM(17)"
      Tab(1).Control(11)=   "ListaMareMM(16)"
      Tab(1).Control(12)=   "ListaMareMM(15)"
      Tab(1).Control(13)=   "ListaMareMM(14)"
      Tab(1).Control(14)=   "ListaMareMM(13)"
      Tab(1).Control(15)=   "ListaMareMM(12)"
      Tab(1).Control(16)=   "ListaMareMM(11)"
      Tab(1).Control(17)=   "ListaMareMM(10)"
      Tab(1).Control(18)=   "ListaMareMM(9)"
      Tab(1).Control(19)=   "ListaMareMM(8)"
      Tab(1).Control(20)=   "ListaMareMM(7)"
      Tab(1).Control(21)=   "ListaMareMM(6)"
      Tab(1).Control(22)=   "ListaMareMM(5)"
      Tab(1).Control(23)=   "ListaMareMM(4)"
      Tab(1).Control(24)=   "ListaMareMM(3)"
      Tab(1).Control(25)=   "ListaMareMM(2)"
      Tab(1).Control(26)=   "ListaMareMM(1)"
      Tab(1).Control(27)=   "ListaMareMM(0)"
      Tab(1).Control(28)=   "BorduraGata(1)"
      Tab(1).Control(29)=   "Label28(1)"
      Tab(1).Control(30)=   "Line18(1)"
      Tab(1).Control(31)=   "Trebuie_completat(5)"
      Tab(1).Control(32)=   "Trebuie_completat(7)"
      Tab(1).Control(33)=   "Trebuie_completat(8)"
      Tab(1).Control(34)=   "Trebuie_completat(9)"
      Tab(1).Control(35)=   "Trebuie_completat(10)"
      Tab(1).Control(36)=   "Trebuie_completat(11)"
      Tab(1).Control(37)=   "Trebuie_completat(12)"
      Tab(1).Control(38)=   "Pro_imagine(1)"
      Tab(1).Control(39)=   "Imagine_Meniu(1)"
      Tab(1).Control(40)=   "Citeste_Text(1)"
      Tab(1).Control(41)=   "Explicatie(1)"
      Tab(1).Control(42)=   "Titlu(1)"
      Tab(1).Control(43)=   "IN_Lista(1)"
      Tab(1).Control(44)=   "kit(1)"
      Tab(1).Control(45)=   "kitZip(1)"
      Tab(1).Control(46)=   "cale2(1)"
      Tab(1).Control(47)=   "calea(1)"
      Tab(1).Control(48)=   "Inainte_de(1)"
      Tab(1).Control(49)=   "ImagineM(1)"
      Tab(1).Control(50)=   "IMica(1)"
      Tab(1).Control(51)=   "Imagine_Mare(1)"
      Tab(1).Control(52)=   "IMare(1)"
      Tab(1).Control(53)=   "Sterge(1)"
      Tab(1).ControlCount=   54
      TabCaption(2)   =   "Jocuri"
      TabPicture(2)   =   "Form1.frx":0D62
      Tab(2).ControlEnabled=   0   'False
      Tab(2).Control(0)=   "Sterge(2)"
      Tab(2).Control(1)=   "IMare(2)"
      Tab(2).Control(2)=   "Imagine_Mare(2)"
      Tab(2).Control(3)=   "IMica(2)"
      Tab(2).Control(4)=   "ImagineM(2)"
      Tab(2).Control(5)=   "Inainte_de(2)"
      Tab(2).Control(6)=   "Citeste_Text(2)"
      Tab(2).Control(7)=   "Explicatie(2)"
      Tab(2).Control(8)=   "Titlu(2)"
      Tab(2).Control(9)=   "IN_Lista(2)"
      Tab(2).Control(10)=   "kit(2)"
      Tab(2).Control(11)=   "kitZip(2)"
      Tab(2).Control(12)=   "cale2(2)"
      Tab(2).Control(13)=   "calea(2)"
      Tab(2).Control(14)=   "Imagine_Meniu(2)"
      Tab(2).Control(15)=   "Pro_imagine(2)"
      Tab(2).Control(16)=   "Trebuie_completat(19)"
      Tab(2).Control(17)=   "Trebuie_completat(18)"
      Tab(2).Control(18)=   "Trebuie_completat(17)"
      Tab(2).Control(19)=   "Trebuie_completat(16)"
      Tab(2).Control(20)=   "Trebuie_completat(15)"
      Tab(2).Control(21)=   "Trebuie_completat(14)"
      Tab(2).Control(22)=   "Trebuie_completat(13)"
      Tab(2).Control(23)=   "Line18(2)"
      Tab(2).Control(24)=   "BorduraTemp(2)"
      Tab(2).Control(25)=   "Line1(3)"
      Tab(2).Control(26)=   "Label28(2)"
      Tab(2).Control(27)=   "BorduraGata(2)"
      Tab(2).Control(28)=   "Label12"
      Tab(2).Control(29)=   "Label11"
      Tab(2).Control(30)=   "Label10"
      Tab(2).Control(31)=   "Label9"
      Tab(2).Control(32)=   "Line3"
      Tab(2).Control(33)=   "ListaMareJC(17)"
      Tab(2).Control(34)=   "ListaMareJC(16)"
      Tab(2).Control(35)=   "ListaMareJC(15)"
      Tab(2).Control(36)=   "ListaMareJC(14)"
      Tab(2).Control(37)=   "ListaMareJC(13)"
      Tab(2).Control(38)=   "ListaMareJC(12)"
      Tab(2).Control(39)=   "ListaMareJC(11)"
      Tab(2).Control(40)=   "ListaMareJC(10)"
      Tab(2).Control(41)=   "ListaMareJC(9)"
      Tab(2).Control(42)=   "ListaMareJC(8)"
      Tab(2).Control(43)=   "ListaMareJC(7)"
      Tab(2).Control(44)=   "ListaMareJC(6)"
      Tab(2).Control(45)=   "ListaMareJC(5)"
      Tab(2).Control(46)=   "ListaMareJC(4)"
      Tab(2).Control(47)=   "ListaMareJC(3)"
      Tab(2).Control(48)=   "ListaMareJC(2)"
      Tab(2).Control(49)=   "ListaMareJC(1)"
      Tab(2).Control(50)=   "ListaMareJC(0)"
      Tab(2).Control(51)=   "Line8(2)"
      Tab(2).Control(52)=   "Line9(2)"
      Tab(2).Control(53)=   "Line10(1)"
      Tab(2).ControlCount=   54
      TabCaption(3)   =   "Internet"
      TabPicture(3)   =   "Form1.frx":0D7E
      Tab(3).ControlEnabled=   0   'False
      Tab(3).Control(0)=   "Sterge(3)"
      Tab(3).Control(1)=   "IMare(3)"
      Tab(3).Control(2)=   "Imagine_Mare(3)"
      Tab(3).Control(3)=   "IMica(3)"
      Tab(3).Control(4)=   "ImagineM(3)"
      Tab(3).Control(5)=   "Inainte_de(3)"
      Tab(3).Control(6)=   "Citeste_Text(3)"
      Tab(3).Control(7)=   "Explicatie(3)"
      Tab(3).Control(8)=   "Titlu(3)"
      Tab(3).Control(9)=   "IN_Lista(3)"
      Tab(3).Control(10)=   "kit(3)"
      Tab(3).Control(11)=   "kitZip(3)"
      Tab(3).Control(12)=   "cale2(3)"
      Tab(3).Control(13)=   "calea(3)"
      Tab(3).Control(14)=   "Imagine_Meniu(3)"
      Tab(3).Control(15)=   "Pro_imagine(3)"
      Tab(3).Control(16)=   "Trebuie_completat(26)"
      Tab(3).Control(17)=   "Trebuie_completat(25)"
      Tab(3).Control(18)=   "Trebuie_completat(24)"
      Tab(3).Control(19)=   "Trebuie_completat(23)"
      Tab(3).Control(20)=   "Trebuie_completat(22)"
      Tab(3).Control(21)=   "Trebuie_completat(21)"
      Tab(3).Control(22)=   "Trebuie_completat(20)"
      Tab(3).Control(23)=   "Line18(3)"
      Tab(3).Control(24)=   "BorduraTemp(3)"
      Tab(3).Control(25)=   "Line1(4)"
      Tab(3).Control(26)=   "Label28(3)"
      Tab(3).Control(27)=   "BorduraGata(3)"
      Tab(3).Control(28)=   "Label16"
      Tab(3).Control(29)=   "Label15"
      Tab(3).Control(30)=   "Label14"
      Tab(3).Control(31)=   "Label13"
      Tab(3).Control(32)=   "Line4"
      Tab(3).Control(33)=   "ListaMareIN(17)"
      Tab(3).Control(34)=   "ListaMareIN(16)"
      Tab(3).Control(35)=   "ListaMareIN(15)"
      Tab(3).Control(36)=   "ListaMareIN(14)"
      Tab(3).Control(37)=   "ListaMareIN(13)"
      Tab(3).Control(38)=   "ListaMareIN(12)"
      Tab(3).Control(39)=   "ListaMareIN(11)"
      Tab(3).Control(40)=   "ListaMareIN(10)"
      Tab(3).Control(41)=   "ListaMareIN(9)"
      Tab(3).Control(42)=   "ListaMareIN(8)"
      Tab(3).Control(43)=   "ListaMareIN(7)"
      Tab(3).Control(44)=   "ListaMareIN(6)"
      Tab(3).Control(45)=   "ListaMareIN(5)"
      Tab(3).Control(46)=   "ListaMareIN(4)"
      Tab(3).Control(47)=   "ListaMareIN(3)"
      Tab(3).Control(48)=   "ListaMareIN(2)"
      Tab(3).Control(49)=   "ListaMareIN(1)"
      Tab(3).Control(50)=   "ListaMareIN(0)"
      Tab(3).Control(51)=   "Line8(3)"
      Tab(3).Control(52)=   "Line9(3)"
      Tab(3).Control(53)=   "Line10(2)"
      Tab(3).ControlCount=   54
      TabCaption(4)   =   "Antivirus"
      TabPicture(4)   =   "Form1.frx":0D9A
      Tab(4).ControlEnabled=   0   'False
      Tab(4).Control(0)=   "Line10(4)"
      Tab(4).Control(1)=   "Line9(4)"
      Tab(4).Control(2)=   "Line8(4)"
      Tab(4).Control(3)=   "ListaMareAV(0)"
      Tab(4).Control(4)=   "ListaMareAV(1)"
      Tab(4).Control(5)=   "ListaMareAV(2)"
      Tab(4).Control(6)=   "ListaMareAV(3)"
      Tab(4).Control(7)=   "ListaMareAV(4)"
      Tab(4).Control(8)=   "ListaMareAV(5)"
      Tab(4).Control(9)=   "ListaMareAV(6)"
      Tab(4).Control(10)=   "ListaMareAV(7)"
      Tab(4).Control(11)=   "ListaMareAV(8)"
      Tab(4).Control(12)=   "ListaMareAV(9)"
      Tab(4).Control(13)=   "ListaMareAV(10)"
      Tab(4).Control(14)=   "ListaMareAV(11)"
      Tab(4).Control(15)=   "ListaMareAV(12)"
      Tab(4).Control(16)=   "ListaMareAV(13)"
      Tab(4).Control(17)=   "ListaMareAV(14)"
      Tab(4).Control(18)=   "ListaMareAV(15)"
      Tab(4).Control(19)=   "ListaMareAV(16)"
      Tab(4).Control(20)=   "ListaMareAV(17)"
      Tab(4).Control(21)=   "Line5"
      Tab(4).Control(22)=   "Label17"
      Tab(4).Control(23)=   "Label18"
      Tab(4).Control(24)=   "Label19"
      Tab(4).Control(25)=   "Label20"
      Tab(4).Control(26)=   "Line7"
      Tab(4).Control(27)=   "BorduraGata(4)"
      Tab(4).Control(28)=   "Label28(4)"
      Tab(4).Control(29)=   "BorduraTemp(4)"
      Tab(4).Control(30)=   "Line18(4)"
      Tab(4).Control(31)=   "Trebuie_completat(27)"
      Tab(4).Control(32)=   "Trebuie_completat(28)"
      Tab(4).Control(33)=   "Trebuie_completat(29)"
      Tab(4).Control(34)=   "Trebuie_completat(30)"
      Tab(4).Control(35)=   "Trebuie_completat(31)"
      Tab(4).Control(36)=   "Trebuie_completat(32)"
      Tab(4).Control(37)=   "Trebuie_completat(33)"
      Tab(4).Control(38)=   "Pro_imagine(4)"
      Tab(4).Control(39)=   "Imagine_Meniu(4)"
      Tab(4).Control(40)=   "calea(4)"
      Tab(4).Control(41)=   "cale2(4)"
      Tab(4).Control(42)=   "kitZip(4)"
      Tab(4).Control(43)=   "kit(4)"
      Tab(4).Control(44)=   "IN_Lista(4)"
      Tab(4).Control(45)=   "Titlu(4)"
      Tab(4).Control(46)=   "Explicatie(4)"
      Tab(4).Control(47)=   "Citeste_Text(4)"
      Tab(4).Control(48)=   "Inainte_de(4)"
      Tab(4).Control(49)=   "ImagineM(4)"
      Tab(4).Control(50)=   "IMica(4)"
      Tab(4).Control(51)=   "Imagine_Mare(4)"
      Tab(4).Control(52)=   "IMare(4)"
      Tab(4).Control(53)=   "Sterge(4)"
      Tab(4).ControlCount=   54
      TabCaption(5)   =   "Permanente"
      TabPicture(5)   =   "Form1.frx":0DB6
      Tab(5).ControlEnabled=   0   'False
      Tab(5).Control(0)=   "Sterge(5)"
      Tab(5).Control(1)=   "I_Mare_deschide"
      Tab(5).Control(2)=   "I_mica_deschide"
      Tab(5).Control(3)=   "IMare(5)"
      Tab(5).Control(4)=   "Imagine_Mare(5)"
      Tab(5).Control(5)=   "IMica(5)"
      Tab(5).Control(6)=   "ImagineM(5)"
      Tab(5).Control(7)=   "Inainte_de(5)"
      Tab(5).Control(8)=   "Citeste_Text(5)"
      Tab(5).Control(9)=   "Explicatie(5)"
      Tab(5).Control(10)=   "Titlu(5)"
      Tab(5).Control(11)=   "IN_Lista(5)"
      Tab(5).Control(12)=   "kit(5)"
      Tab(5).Control(13)=   "kitZip(5)"
      Tab(5).Control(14)=   "cale2(5)"
      Tab(5).Control(15)=   "calea(5)"
      Tab(5).Control(16)=   "Imagine_Meniu(5)"
      Tab(5).Control(17)=   "Pro_imagine(5)"
      Tab(5).Control(18)=   "Trebuie_completat(40)"
      Tab(5).Control(19)=   "Trebuie_completat(39)"
      Tab(5).Control(20)=   "Trebuie_completat(38)"
      Tab(5).Control(21)=   "Trebuie_completat(37)"
      Tab(5).Control(22)=   "Trebuie_completat(36)"
      Tab(5).Control(23)=   "Trebuie_completat(35)"
      Tab(5).Control(24)=   "Trebuie_completat(34)"
      Tab(5).Control(25)=   "Line18(5)"
      Tab(5).Control(26)=   "Line11"
      Tab(5).Control(27)=   "BorduraTemp(5)"
      Tab(5).Control(28)=   "Label28(5)"
      Tab(5).Control(29)=   "BorduraGata(5)"
      Tab(5).Control(30)=   "Label24"
      Tab(5).Control(31)=   "Label23"
      Tab(5).Control(32)=   "Label22"
      Tab(5).Control(33)=   "Label21"
      Tab(5).Control(34)=   "Line6"
      Tab(5).Control(35)=   "ListaMarePR(17)"
      Tab(5).Control(36)=   "ListaMarePR(16)"
      Tab(5).Control(37)=   "ListaMarePR(15)"
      Tab(5).Control(38)=   "ListaMarePR(14)"
      Tab(5).Control(39)=   "ListaMarePR(13)"
      Tab(5).Control(40)=   "ListaMarePR(12)"
      Tab(5).Control(41)=   "ListaMarePR(11)"
      Tab(5).Control(42)=   "ListaMarePR(10)"
      Tab(5).Control(43)=   "ListaMarePR(9)"
      Tab(5).Control(44)=   "ListaMarePR(8)"
      Tab(5).Control(45)=   "ListaMarePR(7)"
      Tab(5).Control(46)=   "ListaMarePR(6)"
      Tab(5).Control(47)=   "ListaMarePR(5)"
      Tab(5).Control(48)=   "ListaMarePR(4)"
      Tab(5).Control(49)=   "ListaMarePR(3)"
      Tab(5).Control(50)=   "ListaMarePR(2)"
      Tab(5).Control(51)=   "ListaMarePR(1)"
      Tab(5).Control(52)=   "ListaMarePR(0)"
      Tab(5).Control(53)=   "Line8(5)"
      Tab(5).Control(54)=   "Line9(5)"
      Tab(5).Control(55)=   "Line10(5)"
      Tab(5).ControlCount=   56
      TabCaption(6)   =   "Revista"
      TabPicture(6)   =   "Form1.frx":0DD2
      Tab(6).ControlEnabled=   0   'False
      Tab(6).Control(0)=   "Label44"
      Tab(6).Control(1)=   "Trebuie_completat(65)"
      Tab(6).Control(2)=   "Revista"
      Tab(6).Control(3)=   "Inainte_de(6)"
      Tab(6).Control(4)=   "revista1"
      Tab(6).Control(5)=   "revista2"
      Tab(6).ControlCount=   6
      TabCaption(7)   =   "INTRO"
      TabPicture(7)   =   "Form1.frx":0DEE
      Tab(7).ControlEnabled=   0   'False
      Tab(7).Control(0)=   "Trebuie_completat(41)"
      Tab(7).Control(1)=   "lalalalalala"
      Tab(7).Control(2)=   "Intro"
      Tab(7).Control(3)=   "Inainte_de(7)"
      Tab(7).Control(4)=   "Intro1"
      Tab(7).Control(5)=   "Intro2"
      Tab(7).Control(6)=   "AxaRotativa"
      Tab(7).Control(7)=   "Reclama_luna"
      Tab(7).Control(8)=   "IntroFaraReclama(0)"
      Tab(7).Control(9)=   "IntroFaraReclama(1)"
      Tab(7).Control(10)=   "IntroFaraReclama(2)"
      Tab(7).Control(11)=   "Mare_smecherie"
      Tab(7).ControlCount=   12
      TabCaption(8)   =   "Ajutor"
      TabPicture(8)   =   "Form1.frx":0E0A
      Tab(8).ControlEnabled=   0   'False
      Tab(8).Control(0)=   "Label35"
      Tab(8).Control(1)=   "Label36"
      Tab(8).Control(2)=   "Label37"
      Tab(8).Control(3)=   "Shape2"
      Tab(8).Control(4)=   "Line19"
      Tab(8).Control(5)=   "Line20"
      Tab(8).Control(6)=   "Line21"
      Tab(8).Control(7)=   "Line22"
      Tab(8).Control(8)=   "Label38"
      Tab(8).Control(9)=   "Shape3"
      Tab(8).Control(10)=   "Shape4"
      Tab(8).Control(11)=   "Trebuie_completat(48)"
      Tab(8).Control(12)=   "Trebuie_completat(49)"
      Tab(8).Control(13)=   "Trebuie_completat(50)"
      Tab(8).Control(14)=   "Trebuie_completat(51)"
      Tab(8).Control(15)=   "Trebuie_completat(66)"
      Tab(8).Control(16)=   "Ajutor"
      Tab(8).Control(17)=   "Inainte_de(8)"
      Tab(8).Control(18)=   "Ajutor1"
      Tab(8).Control(19)=   "Fontul"
      Tab(8).Control(20)=   "FontCuloare"
      Tab(8).Control(21)=   "FontMarime"
      Tab(8).Control(22)=   "FundalAjutor"
      Tab(8).Control(23)=   "CaleAjutor"
      Tab(8).Control(24)=   "DeschideAjutor"
      Tab(8).ControlCount=   25
      TabCaption(9)   =   "Drivere"
      TabPicture(9)   =   "Form1.frx":0E26
      Tab(9).ControlEnabled=   0   'False
      Tab(9).Control(0)=   "DriverInformatii1(0)"
      Tab(9).Control(1)=   "DriverInformatii2(0)"
      Tab(9).Control(2)=   "DriverInformatii3(0)"
      Tab(9).Control(3)=   "DriverInformatii1(1)"
      Tab(9).Control(4)=   "DriverInformatii2(1)"
      Tab(9).Control(5)=   "DriverInformatii3(1)"
      Tab(9).Control(6)=   "DriverInformatii1(2)"
      Tab(9).Control(7)=   "DriverInformatii2(2)"
      Tab(9).Control(8)=   "DriverInformatii3(2)"
      Tab(9).Control(9)=   "DriverInformatii1(3)"
      Tab(9).Control(10)=   "DriverInformatii2(3)"
      Tab(9).Control(11)=   "DriverInformatii3(3)"
      Tab(9).Control(12)=   "DriverInformatii1(4)"
      Tab(9).Control(13)=   "DriverInformatii2(4)"
      Tab(9).Control(14)=   "DriverInformatii3(4)"
      Tab(9).Control(15)=   "DriverInformatii1(5)"
      Tab(9).Control(16)=   "DriverInformatii2(5)"
      Tab(9).Control(17)=   "DriverInformatii3(5)"
      Tab(9).Control(18)=   "DriverInformatii1(6)"
      Tab(9).Control(19)=   "DriverInformatii2(6)"
      Tab(9).Control(20)=   "DriverInformatii3(6)"
      Tab(9).Control(21)=   "DriverInformatii1(7)"
      Tab(9).Control(22)=   "DriverInformatii2(7)"
      Tab(9).Control(23)=   "DriverInformatii3(7)"
      Tab(9).Control(24)=   "Line23(0)"
      Tab(9).Control(25)=   "Line23(1)"
      Tab(9).Control(26)=   "Line23(2)"
      Tab(9).Control(27)=   "Line23(3)"
      Tab(9).Control(28)=   "Line23(4)"
      Tab(9).Control(29)=   "Line24"
      Tab(9).Control(30)=   "etete"
      Tab(9).Control(31)=   "Shape6"
      Tab(9).Control(32)=   "Label26"
      Tab(9).Control(33)=   "Label39"
      Tab(9).Control(34)=   "Label40"
      Tab(9).Control(35)=   "Shape7"
      Tab(9).Control(36)=   "Label41"
      Tab(9).Control(37)=   "Label42"
      Tab(9).Control(38)=   "Label43"
      Tab(9).Control(39)=   "Shape8"
      Tab(9).Control(40)=   "Trebuie_completat(52)"
      Tab(9).Control(41)=   "Trebuie_completat(53)"
      Tab(9).Control(42)=   "Trebuie_completat(54)"
      Tab(9).Control(43)=   "Trebuie_completat(55)"
      Tab(9).Control(44)=   "Trebuie_completat(56)"
      Tab(9).Control(45)=   "Trebuie_completat(57)"
      Tab(9).Control(46)=   "Trebuie_completat(58)"
      Tab(9).Control(47)=   "Trebuie_completat(59)"
      Tab(9).Control(48)=   "Trebuie_completat(60)"
      Tab(9).Control(49)=   "Trebuie_completat(61)"
      Tab(9).Control(50)=   "Label45"
      Tab(9).Control(51)=   "Label46"
      Tab(9).Control(52)=   "Line25"
      Tab(9).Control(53)=   "Shape5"
      Tab(9).Control(54)=   "Inainte_de(9)"
      Tab(9).Control(55)=   "Drivere"
      Tab(9).Control(56)=   "drivere1"
      Tab(9).Control(57)=   "drivere2"
      Tab(9).Control(58)=   "DrivereTitlu(0)"
      Tab(9).Control(59)=   "DrivereExplicatii(0)"
      Tab(9).Control(60)=   "DrivereTitlu(1)"
      Tab(9).Control(61)=   "DrivereExplicatii(1)"
      Tab(9).Control(62)=   "DrivereExplicatii(2)"
      Tab(9).Control(63)=   "DrivereExplicatii(3)"
      Tab(9).Control(64)=   "DrivereExplicatii(4)"
      Tab(9).Control(65)=   "DrivereExplicatii(5)"
      Tab(9).Control(66)=   "DrivereTitlu(2)"
      Tab(9).Control(67)=   "DrivereTitlu(3)"
      Tab(9).Control(68)=   "DrivereTitlu(4)"
      Tab(9).Control(69)=   "DrivereTitlu(5)"
      Tab(9).Control(70)=   "DrivereTitlu(6)"
      Tab(9).Control(71)=   "DrivereTitlu(7)"
      Tab(9).Control(72)=   "DrivereExplicatii(6)"
      Tab(9).Control(73)=   "DrivereExplicatii(7)"
      Tab(9).Control(74)=   "DrivereCale(0)"
      Tab(9).Control(75)=   "DrivereCale(1)"
      Tab(9).Control(76)=   "DrivereCale(2)"
      Tab(9).Control(77)=   "DrivereCale(3)"
      Tab(9).Control(78)=   "DrivereCale(4)"
      Tab(9).Control(79)=   "DrivereCale(5)"
      Tab(9).Control(80)=   "DrivereCale(6)"
      Tab(9).Control(81)=   "DrivereCale(7)"
      Tab(9).Control(82)=   "StergeDriver"
      Tab(9).Control(83)=   "DeschideDriver"
      Tab(9).Control(84)=   "D_FontMarime"
      Tab(9).Control(85)=   "D_FontCuloare"
      Tab(9).Control(86)=   "D_Font"
      Tab(9).Control(87)=   "D_Cale_text"
      Tab(9).Control(88)=   "D_Alege"
      Tab(9).Control(89)=   "EX_Font"
      Tab(9).Control(90)=   "EX_FontCuloare"
      Tab(9).Control(91)=   "EX_FontMarime"
      Tab(9).Control(92)=   "Deschide_Driver_fundal"
      Tab(9).ControlCount=   93
      TabCaption(10)  =   "Alte setari"
      TabPicture(10)  =   "Form1.frx":0E42
      Tab(10).ControlEnabled=   0   'False
      Tab(10).Control(0)=   "Trebuie_completat(62)"
      Tab(10).Control(1)=   "Trebuie_completat(63)"
      Tab(10).Control(2)=   "Image2"
      Tab(10).Control(3)=   "Shape9"
      Tab(10).Control(4)=   "Shape10"
      Tab(10).Control(5)=   "xls_ul"
      Tab(10).Control(6)=   "zi_mai(1)"
      Tab(10).Control(7)=   "Ar_text"
      Tab(10).Control(8)=   "Arhiva"
      Tab(10).Control(9)=   "sunetul"
      Tab(10).Control(10)=   "cale_sunet"
      Tab(10).Control(11)=   "sunetEu"
      Tab(10).Control(12)=   "zi_mai(0)"
      Tab(10).Control(13)=   "Sunetele"
      Tab(10).ControlCount=   14
      TabCaption(11)  =   "Impachetare"
      TabPicture(11)  =   "Form1.frx":0E5E
      Tab(11).ControlEnabled=   0   'False
      Tab(11).Control(0)=   "Compilare_CD"
      Tab(11).Control(1)=   "Label27"
      Tab(11).ControlCount=   2
      Begin GenerareMatrita.Listare_Tip_GIF Pro_imagine 
         Height          =   2655
         Index           =   0
         Left            =   9120
         Top             =   5760
         Width           =   3015
         _ExtentX        =   5318
         _ExtentY        =   4683
      End
      Begin GenerareMatrita.Listare_Tip_GIF Imagine_Meniu 
         Height          =   2655
         Index           =   0
         Left            =   9120
         Top             =   600
         Width           =   3015
         _ExtentX        =   5318
         _ExtentY        =   4683
      End
      Begin SHDocVwCtl.WebBrowser Sunetele 
         Height          =   495
         Left            =   -62520
         TabIndex        =   418
         Top             =   2760
         Width           =   855
         ExtentX         =   1508
         ExtentY         =   873
         ViewMode        =   0
         Offline         =   0
         Silent          =   0
         RegisterAsBrowser=   0
         RegisterAsDropTarget=   1
         AutoArrange     =   0   'False
         NoClientEdge    =   0   'False
         AlignLeft       =   0   'False
         NoWebView       =   0   'False
         HideFileNames   =   0   'False
         SingleClick     =   0   'False
         SingleSelection =   0   'False
         NoFolders       =   0   'False
         Transparent     =   0   'False
         ViewID          =   "{0057D0E0-3573-11CF-AE69-08002B2E1262}"
         Location        =   "http:///"
      End
      Begin GenerareMatrita.Buton_3D_General zi_mai 
         Height          =   495
         Index           =   0
         Left            =   -69720
         TabIndex        =   416
         Top             =   2040
         Width           =   855
         _ExtentX        =   1508
         _ExtentY        =   873
         Caption         =   ">"
         ButtonStyle     =   3
         OriginalPicSizeW=   0
         OriginalPicSizeH=   0
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         MousePointer    =   99
      End
      Begin VB.Frame Mare_smecherie 
         BackColor       =   &H00E0E0E0&
         Caption         =   " Caseta de reclama "
         Height          =   4215
         Left            =   -74880
         TabIndex        =   396
         Top             =   3960
         Width           =   12135
         Begin VB.TextBox borduraG 
            BackColor       =   &H00000000&
            ForeColor       =   &H0000FF00&
            Height          =   285
            Left            =   10920
            TabIndex        =   403
            Text            =   "1"
            Top             =   2520
            Width           =   855
         End
         Begin VB.TextBox CaleFundalIntro 
            BackColor       =   &H00000000&
            ForeColor       =   &H0000FF00&
            Height          =   285
            Left            =   3600
            Locked          =   -1  'True
            TabIndex        =   402
            Top             =   3720
            Width           =   8175
         End
         Begin VB.CommandButton FundalIntro 
            Caption         =   "Fisier imagine pentru fundal ..."
            Height          =   255
            Left            =   240
            TabIndex        =   401
            Top             =   3720
            Width           =   3375
         End
         Begin VB.TextBox culoare 
            BackColor       =   &H00000000&
            ForeColor       =   &H0000FF00&
            Height          =   285
            Left            =   10800
            TabIndex        =   400
            Text            =   "8888ff"
            Top             =   2160
            Width           =   975
         End
         Begin VB.TextBox latime 
            BackColor       =   &H00000000&
            ForeColor       =   &H0000FF00&
            Height          =   285
            Left            =   10800
            TabIndex        =   399
            Text            =   "468"
            Top             =   1800
            Width           =   975
         End
         Begin VB.TextBox Inaltime 
            BackColor       =   &H00000000&
            ForeColor       =   &H0000FF00&
            Height          =   285
            Left            =   10800
            TabIndex        =   398
            Text            =   "60"
            Top             =   1440
            Width           =   975
         End
         Begin VB.TextBox Intro3 
            BackColor       =   &H00000000&
            ForeColor       =   &H0000FF00&
            Height          =   2415
            Left            =   120
            MultiLine       =   -1  'True
            ScrollBars      =   3  'Both
            TabIndex        =   397
            Text            =   "Form1.frx":0E7A
            Top             =   600
            Width           =   9375
         End
         Begin MSComDlg.CommonDialog FundalReclama 
            Left            =   11520
            Top             =   240
            _ExtentX        =   847
            _ExtentY        =   847
            _Version        =   393216
         End
         Begin VB.Label Label33 
            BackColor       =   &H00E0E0E0&
            Caption         =   "Grosime bordura"
            Height          =   255
            Left            =   9720
            TabIndex        =   415
            Top             =   2520
            Width           =   1215
         End
         Begin VB.Label Label32 
            BackColor       =   &H00E0E0E0&
            Caption         =   "Fisierul imagine(GIF) pentru fundalul casutei de reclama:"
            Height          =   255
            Left            =   240
            TabIndex        =   414
            Top             =   3360
            Width           =   4335
         End
         Begin VB.Shape Shape1 
            BorderColor     =   &H00808080&
            BorderWidth     =   3
            Height          =   1695
            Left            =   9600
            Top             =   1320
            Width           =   2415
         End
         Begin VB.Label Label31 
            BackColor       =   &H00E0E0E0&
            Caption         =   "Culoare"
            Height          =   255
            Left            =   9720
            TabIndex        =   413
            Top             =   2160
            Width           =   1095
         End
         Begin VB.Line Line16 
            BorderColor     =   &H00000000&
            X1              =   11280
            X2              =   11040
            Y1              =   1200
            Y2              =   1320
         End
         Begin VB.Line Line15 
            BorderColor     =   &H00000000&
            X1              =   10800
            X2              =   11040
            Y1              =   1200
            Y2              =   1320
         End
         Begin VB.Line Line14 
            BorderColor     =   &H00808080&
            BorderWidth     =   3
            X1              =   11040
            X2              =   11040
            Y1              =   1320
            Y2              =   480
         End
         Begin VB.Line Line13 
            BorderColor     =   &H00808080&
            BorderWidth     =   3
            X1              =   1800
            X2              =   11040
            Y1              =   480
            Y2              =   480
         End
         Begin VB.Label Label30 
            BackColor       =   &H00E0E0E0&
            Caption         =   "Latime"
            Height          =   255
            Left            =   9720
            TabIndex        =   412
            Top             =   1800
            Width           =   1095
         End
         Begin VB.Label Label29 
            BackColor       =   &H00E0E0E0&
            Caption         =   "Inaltime"
            Height          =   255
            Left            =   9720
            TabIndex        =   411
            Top             =   1440
            Width           =   1095
         End
         Begin VB.Label Label25 
            BackColor       =   &H00E0E0E0&
            Caption         =   "Casuta pentru reclama:"
            Height          =   255
            Left            =   120
            TabIndex        =   410
            Top             =   360
            Width           =   1815
         End
         Begin VB.Label Trebuie_completat 
            BackColor       =   &H00E0E0E0&
            Caption         =   "*"
            BeginProperty Font 
               Name            =   "Times New Roman"
               Size            =   15.75
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            ForeColor       =   &H00FF00FF&
            Height          =   255
            Index           =   46
            Left            =   9480
            TabIndex        =   409
            Top             =   600
            Width           =   135
         End
         Begin VB.Label Trebuie_completat 
            BackColor       =   &H00E0E0E0&
            Caption         =   "*"
            BeginProperty Font 
               Name            =   "Times New Roman"
               Size            =   15.75
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            ForeColor       =   &H00FF00FF&
            Height          =   255
            Index           =   45
            Left            =   11760
            TabIndex        =   408
            Top             =   1440
            Width           =   135
         End
         Begin VB.Label Trebuie_completat 
            BackColor       =   &H00E0E0E0&
            Caption         =   "*"
            BeginProperty Font 
               Name            =   "Times New Roman"
               Size            =   15.75
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            ForeColor       =   &H00FF00FF&
            Height          =   255
            Index           =   44
            Left            =   11760
            TabIndex        =   407
            Top             =   1800
            Width           =   135
         End
         Begin VB.Label Trebuie_completat 
            BackColor       =   &H00E0E0E0&
            Caption         =   "*"
            BeginProperty Font 
               Name            =   "Times New Roman"
               Size            =   15.75
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            ForeColor       =   &H00FF00FF&
            Height          =   255
            Index           =   43
            Left            =   11760
            TabIndex        =   406
            Top             =   2160
            Width           =   135
         End
         Begin VB.Label Trebuie_completat 
            BackColor       =   &H00E0E0E0&
            Caption         =   "*"
            BeginProperty Font 
               Name            =   "Times New Roman"
               Size            =   15.75
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            ForeColor       =   &H00FF00FF&
            Height          =   255
            Index           =   42
            Left            =   11760
            TabIndex        =   405
            Top             =   2520
            Width           =   135
         End
         Begin VB.Label Trebuie_completat 
            BackColor       =   &H00E0E0E0&
            Caption         =   "*"
            BeginProperty Font 
               Name            =   "Times New Roman"
               Size            =   15.75
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            ForeColor       =   &H000000FF&
            Height          =   255
            Index           =   47
            Left            =   11760
            TabIndex        =   404
            Top             =   3840
            Width           =   135
         End
      End
      Begin VB.TextBox IntroFaraReclama 
         Height          =   1215
         Index           =   2
         Left            =   -65400
         MultiLine       =   -1  'True
         ScrollBars      =   3  'Both
         TabIndex        =   395
         Text            =   "Form1.frx":0FAE
         Top             =   4080
         Visible         =   0   'False
         Width           =   2175
      End
      Begin VB.TextBox IntroFaraReclama 
         Height          =   285
         Index           =   1
         Left            =   -65400
         ScrollBars      =   3  'Both
         TabIndex        =   394
         Text            =   $"Form1.frx":177F
         Top             =   5400
         Visible         =   0   'False
         Width           =   2175
      End
      Begin VB.TextBox IntroFaraReclama 
         Height          =   1215
         Index           =   0
         Left            =   -67800
         MultiLine       =   -1  'True
         ScrollBars      =   3  'Both
         TabIndex        =   393
         Text            =   "Form1.frx":1855
         Top             =   4080
         Visible         =   0   'False
         Width           =   2175
      End
      Begin VB.CheckBox Reclama_luna 
         Caption         =   "NU am reclama pe luna asta !"
         Height          =   255
         Left            =   -70560
         TabIndex        =   392
         Top             =   3600
         Width           =   2655
      End
      Begin VB.TextBox AxaRotativa 
         BackColor       =   &H00000000&
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   18
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   555
         Left            =   -71400
         MaxLength       =   24
         TabIndex        =   390
         Text            =   "PC World-decembrie-2004-"
         Top             =   5760
         Width           =   4695
      End
      Begin MSComDlg.CommonDialog Deschide_Driver_fundal 
         Left            =   -63360
         Top             =   4560
         _ExtentX        =   847
         _ExtentY        =   847
         _Version        =   393216
      End
      Begin VB.TextBox EX_FontMarime 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Left            =   -66960
         TabIndex        =   314
         Text            =   "2"
         Top             =   6240
         Width           =   2055
      End
      Begin VB.TextBox EX_FontCuloare 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Left            =   -66960
         TabIndex        =   313
         Text            =   "ffffff"
         Top             =   5880
         Width           =   2055
      End
      Begin VB.TextBox EX_Font 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Left            =   -66960
         TabIndex        =   312
         Text            =   "Arial"
         Top             =   5520
         Width           =   2055
      End
      Begin VB.CommandButton D_Alege 
         Caption         =   "Imagine fundal pentru ""Drivere"" ..."
         Height          =   255
         Left            =   -74640
         TabIndex        =   311
         Top             =   7440
         Width           =   3255
      End
      Begin VB.TextBox D_Cale_text 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Left            =   -71400
         Locked          =   -1  'True
         TabIndex        =   310
         Top             =   7440
         Width           =   8415
      End
      Begin VB.TextBox D_Font 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Left            =   -72960
         TabIndex        =   306
         Text            =   "Arial"
         Top             =   5520
         Width           =   1815
      End
      Begin VB.TextBox D_FontCuloare 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Left            =   -72960
         TabIndex        =   305
         Text            =   "ffffff"
         Top             =   5880
         Width           =   1815
      End
      Begin VB.TextBox D_FontMarime 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Left            =   -72960
         TabIndex        =   304
         Text            =   "2"
         Top             =   6240
         Width           =   1815
      End
      Begin MSComDlg.CommonDialog DeschideDriver 
         Left            =   -63840
         Top             =   4560
         _ExtentX        =   847
         _ExtentY        =   847
         _Version        =   393216
      End
      Begin VB.CommandButton StergeDriver 
         BackColor       =   &H00C0C0C0&
         Caption         =   "Sterge tot ..."
         Height          =   255
         Left            =   -74880
         TabIndex        =   278
         Top             =   4320
         Width           =   12015
      End
      Begin VB.TextBox DrivereCale 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   7
         Left            =   -66720
         Locked          =   -1  'True
         TabIndex        =   277
         Text            =   "Text1"
         Top             =   3840
         Width           =   3975
      End
      Begin VB.TextBox DrivereCale 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   6
         Left            =   -66720
         Locked          =   -1  'True
         TabIndex        =   276
         Text            =   "Text1"
         Top             =   2880
         Width           =   3975
      End
      Begin VB.TextBox DrivereCale 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   5
         Left            =   -66720
         Locked          =   -1  'True
         TabIndex        =   275
         Text            =   "Text1"
         Top             =   1920
         Width           =   3975
      End
      Begin VB.TextBox DrivereCale 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   4
         Left            =   -66720
         Locked          =   -1  'True
         TabIndex        =   274
         Text            =   "Text1"
         Top             =   960
         Width           =   3975
      End
      Begin VB.TextBox DrivereCale 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   3
         Left            =   -72480
         Locked          =   -1  'True
         TabIndex        =   273
         Text            =   "Text1"
         Top             =   3840
         Width           =   3135
      End
      Begin VB.TextBox DrivereCale 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   2
         Left            =   -72480
         Locked          =   -1  'True
         TabIndex        =   272
         Text            =   "Text1"
         Top             =   2880
         Width           =   3135
      End
      Begin VB.TextBox DrivereCale 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   1
         Left            =   -72480
         Locked          =   -1  'True
         TabIndex        =   271
         Text            =   "Text1"
         Top             =   1920
         Width           =   3135
      End
      Begin VB.TextBox DrivereCale 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   0
         Left            =   -72480
         Locked          =   -1  'True
         TabIndex        =   270
         Text            =   "Text1"
         Top             =   960
         Width           =   3015
      End
      Begin VB.TextBox DrivereExplicatii 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   7
         Left            =   -66720
         TabIndex        =   269
         Text            =   "xxxxxxxxxxxxxxxx"
         Top             =   3600
         Width           =   3975
      End
      Begin VB.TextBox DrivereExplicatii 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   6
         Left            =   -66720
         TabIndex        =   268
         Text            =   "xxxxxxxxxxxxxxxxxx"
         Top             =   2640
         Width           =   3975
      End
      Begin VB.TextBox DrivereTitlu 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   7
         Left            =   -66720
         TabIndex        =   267
         Text            =   "xxxxxxxxxxxxxxxxxxxxx"
         Top             =   3360
         Width           =   3975
      End
      Begin VB.TextBox DrivereTitlu 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   6
         Left            =   -66720
         TabIndex        =   266
         Text            =   "xxxxxxxxxxxxxxxxxxxxxx"
         Top             =   2400
         Width           =   3975
      End
      Begin VB.TextBox DrivereTitlu 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   5
         Left            =   -66720
         TabIndex        =   265
         Text            =   "xxxxxxxxxxxxxxxxx"
         Top             =   1440
         Width           =   3975
      End
      Begin VB.TextBox DrivereTitlu 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   4
         Left            =   -66720
         TabIndex        =   264
         Text            =   "xxxxxxxxxxxxx"
         Top             =   480
         Width           =   3975
      End
      Begin VB.TextBox DrivereTitlu 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   3
         Left            =   -72480
         TabIndex        =   263
         Text            =   "xxxxxxxxxxxxxxxxxxxx"
         Top             =   3360
         Width           =   3135
      End
      Begin VB.TextBox DrivereTitlu 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   2
         Left            =   -72480
         TabIndex        =   262
         Text            =   "xxxxxxxxxxxxxxxxxxxxxx"
         Top             =   2400
         Width           =   3135
      End
      Begin VB.TextBox DrivereExplicatii 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   5
         Left            =   -66720
         TabIndex        =   261
         Text            =   "xxxxxxxxxxxxxxxxxxxx"
         Top             =   1680
         Width           =   3975
      End
      Begin VB.TextBox DrivereExplicatii 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   4
         Left            =   -66720
         TabIndex        =   260
         Text            =   "xxxxxxxxxxxxxxx"
         Top             =   720
         Width           =   3975
      End
      Begin VB.TextBox DrivereExplicatii 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   3
         Left            =   -72480
         TabIndex        =   259
         Text            =   "xxxxxxxxxxxxxxxxxx"
         Top             =   3600
         Width           =   3135
      End
      Begin VB.TextBox DrivereExplicatii 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   2
         Left            =   -72480
         TabIndex        =   258
         Text            =   "xxxxxxxxxxxxxx"
         Top             =   2640
         Width           =   3135
      End
      Begin VB.TextBox DrivereExplicatii 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   1
         Left            =   -72480
         TabIndex        =   257
         Text            =   "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
         Top             =   1680
         Width           =   3135
      End
      Begin VB.TextBox DrivereTitlu 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   1
         Left            =   -72480
         TabIndex        =   256
         Text            =   "xxxxxxxxxxxxxx"
         Top             =   1440
         Width           =   3135
      End
      Begin VB.TextBox DrivereExplicatii 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   0
         Left            =   -72480
         TabIndex        =   255
         Text            =   "xxxxxxxxxxxxxxxxxx"
         Top             =   720
         Width           =   3015
      End
      Begin VB.TextBox DrivereTitlu 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   0
         Left            =   -72480
         TabIndex        =   254
         Text            =   "xxxxxxxxx"
         Top             =   480
         Width           =   3015
      End
      Begin VB.CommandButton Sterge 
         Caption         =   "Sterge toata sectiunea !"
         Height          =   255
         Index           =   5
         Left            =   -65880
         TabIndex        =   253
         Top             =   4560
         Width           =   3015
      End
      Begin VB.CommandButton Sterge 
         Caption         =   "Sterge toata sectiunea !"
         Height          =   255
         Index           =   4
         Left            =   -65880
         TabIndex        =   252
         Top             =   4560
         Width           =   3015
      End
      Begin VB.CommandButton Sterge 
         Caption         =   "Sterge toata sectiunea !"
         Height          =   255
         Index           =   3
         Left            =   -65880
         TabIndex        =   251
         Top             =   4560
         Width           =   3015
      End
      Begin VB.CommandButton Sterge 
         Caption         =   "Sterge toata sectiunea !"
         Height          =   255
         Index           =   2
         Left            =   -65880
         TabIndex        =   250
         Top             =   4560
         Width           =   3015
      End
      Begin VB.CommandButton Sterge 
         Caption         =   "Sterge toata sectiunea !"
         Height          =   255
         Index           =   0
         Left            =   9120
         TabIndex        =   249
         Top             =   4560
         Width           =   3015
      End
      Begin VB.CommandButton Sterge 
         Caption         =   "Sterge toata sectiunea !"
         Height          =   255
         Index           =   1
         Left            =   -65880
         TabIndex        =   248
         Top             =   4560
         Width           =   3015
      End
      Begin MSComDlg.CommonDialog DeschideAjutor 
         Left            =   -74760
         Top             =   8040
         _ExtentX        =   847
         _ExtentY        =   847
         _Version        =   393216
      End
      Begin VB.TextBox CaleAjutor 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Left            =   -71400
         Locked          =   -1  'True
         TabIndex        =   247
         Top             =   7680
         Width           =   8415
      End
      Begin VB.CommandButton FundalAjutor 
         Caption         =   "Imagine fundal pentru ""Ajutor"" ..."
         Height          =   255
         Left            =   -74640
         TabIndex        =   246
         Top             =   7680
         Width           =   3255
      End
      Begin VB.TextBox FontMarime 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Left            =   -72960
         TabIndex        =   241
         Text            =   "2"
         Top             =   6840
         Width           =   1815
      End
      Begin VB.TextBox FontCuloare 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Left            =   -72960
         TabIndex        =   240
         Text            =   "ffffff"
         Top             =   6480
         Width           =   1815
      End
      Begin VB.TextBox Fontul 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Left            =   -72960
         TabIndex        =   239
         Text            =   "Arial"
         Top             =   6120
         Width           =   1815
      End
      Begin MSComDlg.CommonDialog sunetEu 
         Left            =   -74760
         Top             =   2040
         _ExtentX        =   847
         _ExtentY        =   847
         _Version        =   393216
      End
      Begin VB.TextBox cale_sunet 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Left            =   -72360
         Locked          =   -1  'True
         TabIndex        =   238
         Top             =   1680
         Width           =   9375
      End
      Begin VB.CommandButton sunetul 
         Caption         =   "Fisierul wav(sunet fundal) ..."
         Height          =   255
         Left            =   -74760
         TabIndex        =   237
         Top             =   1680
         Width           =   2415
      End
      Begin MSComDlg.CommonDialog I_Mare_deschide 
         Left            =   -69120
         Top             =   5640
         _ExtentX        =   847
         _ExtentY        =   847
         _Version        =   393216
      End
      Begin MSComDlg.CommonDialog I_mica_deschide 
         Left            =   -69720
         Top             =   5640
         _ExtentX        =   847
         _ExtentY        =   847
         _Version        =   393216
      End
      Begin VB.TextBox IMare 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   5
         Left            =   -72000
         Locked          =   -1  'True
         TabIndex        =   236
         Top             =   6600
         Width           =   5775
      End
      Begin VB.TextBox IMare 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   4
         Left            =   -72000
         Locked          =   -1  'True
         TabIndex        =   235
         Top             =   6600
         Width           =   5775
      End
      Begin VB.TextBox IMare 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   3
         Left            =   -72000
         Locked          =   -1  'True
         TabIndex        =   234
         Top             =   6600
         Width           =   5775
      End
      Begin VB.TextBox IMare 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   2
         Left            =   -72000
         Locked          =   -1  'True
         TabIndex        =   233
         Top             =   6600
         Width           =   5775
      End
      Begin VB.TextBox IMare 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   1
         Left            =   -72000
         Locked          =   -1  'True
         TabIndex        =   232
         Top             =   6600
         Width           =   5775
      End
      Begin VB.TextBox IMare 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   0
         Left            =   3000
         Locked          =   -1  'True
         TabIndex        =   231
         Top             =   6600
         Width           =   5775
      End
      Begin VB.CommandButton Imagine_Mare 
         Caption         =   "Imagine_Mare"
         Height          =   255
         Index           =   5
         Left            =   -74640
         TabIndex        =   230
         Top             =   6600
         Width           =   2655
      End
      Begin VB.CommandButton Imagine_Mare 
         Caption         =   "Imagine_Mare"
         Height          =   255
         Index           =   4
         Left            =   -74640
         TabIndex        =   229
         Top             =   6600
         Width           =   2655
      End
      Begin VB.CommandButton Imagine_Mare 
         Caption         =   "Imagine_Mare"
         Height          =   255
         Index           =   3
         Left            =   -74640
         TabIndex        =   228
         Top             =   6600
         Width           =   2655
      End
      Begin VB.CommandButton Imagine_Mare 
         Caption         =   "Imagine_Mare"
         Height          =   255
         Index           =   2
         Left            =   -74640
         TabIndex        =   227
         Top             =   6600
         Width           =   2655
      End
      Begin VB.CommandButton Imagine_Mare 
         Caption         =   "Imagine_Mare"
         Height          =   255
         Index           =   1
         Left            =   -74640
         TabIndex        =   226
         Top             =   6600
         Width           =   2655
      End
      Begin VB.CommandButton Imagine_Mare 
         Caption         =   "Imagine_Mare"
         Height          =   255
         Index           =   0
         Left            =   360
         TabIndex        =   225
         Top             =   6600
         Width           =   2655
      End
      Begin VB.TextBox IMica 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   5
         Left            =   -72000
         Locked          =   -1  'True
         TabIndex        =   224
         Top             =   6240
         Width           =   5775
      End
      Begin VB.TextBox IMica 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   4
         Left            =   -72000
         Locked          =   -1  'True
         TabIndex        =   223
         Top             =   6240
         Width           =   5775
      End
      Begin VB.TextBox IMica 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   3
         Left            =   -72000
         Locked          =   -1  'True
         TabIndex        =   222
         Top             =   6240
         Width           =   5775
      End
      Begin VB.TextBox IMica 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   2
         Left            =   -72000
         Locked          =   -1  'True
         TabIndex        =   221
         Top             =   6240
         Width           =   5775
      End
      Begin VB.TextBox IMica 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   1
         Left            =   -72000
         Locked          =   -1  'True
         TabIndex        =   220
         Top             =   6240
         Width           =   5775
      End
      Begin VB.TextBox IMica 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   0
         Left            =   3000
         Locked          =   -1  'True
         TabIndex        =   219
         Top             =   6240
         Width           =   5775
      End
      Begin VB.CommandButton ImagineM 
         Caption         =   "Imagine_Mica"
         Height          =   255
         Index           =   5
         Left            =   -74640
         TabIndex        =   218
         Top             =   6240
         Width           =   2655
      End
      Begin VB.CommandButton ImagineM 
         Caption         =   "Imagine_Mica"
         Height          =   255
         Index           =   4
         Left            =   -74640
         TabIndex        =   217
         Top             =   6240
         Width           =   2655
      End
      Begin VB.CommandButton ImagineM 
         Caption         =   "Imagine_Mica"
         Height          =   255
         Index           =   3
         Left            =   -74640
         TabIndex        =   216
         Top             =   6240
         Width           =   2655
      End
      Begin VB.CommandButton ImagineM 
         Caption         =   "Imagine_Mica"
         Height          =   255
         Index           =   2
         Left            =   -74640
         TabIndex        =   215
         Top             =   6240
         Width           =   2655
      End
      Begin VB.CommandButton ImagineM 
         Caption         =   "Imagine_Mica"
         Height          =   255
         Index           =   1
         Left            =   -74640
         TabIndex        =   214
         Top             =   6240
         Width           =   2655
      End
      Begin VB.CommandButton ImagineM 
         Caption         =   "Imagine_Mica"
         Height          =   255
         Index           =   0
         Left            =   360
         TabIndex        =   213
         Top             =   6240
         Width           =   2655
      End
      Begin VB.CommandButton Arhiva 
         Caption         =   "Calea fisierului arhiva ..."
         Height          =   255
         Left            =   -74760
         TabIndex        =   212
         Top             =   720
         Width           =   2415
      End
      Begin VB.TextBox Ar_text 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Left            =   -72360
         Locked          =   -1  'True
         TabIndex        =   211
         Top             =   720
         Width           =   9375
      End
      Begin VB.TextBox Compilare_CD 
         BackColor       =   &H00000000&
         BeginProperty Font 
            Name            =   "System"
            Size            =   9.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H0000FF00&
         Height          =   7935
         Left            =   -74880
         Locked          =   -1  'True
         MultiLine       =   -1  'True
         ScrollBars      =   3  'Both
         TabIndex        =   209
         Top             =   600
         Width           =   12135
      End
      Begin VB.TextBox drivere2 
         Height          =   615
         Left            =   -63720
         MultiLine       =   -1  'True
         ScrollBars      =   3  'Both
         TabIndex        =   208
         Text            =   "Form1.frx":22B5
         Top             =   8040
         Visible         =   0   'False
         Width           =   1095
      End
      Begin VB.TextBox drivere1 
         Height          =   615
         Left            =   -64920
         MultiLine       =   -1  'True
         ScrollBars      =   3  'Both
         TabIndex        =   207
         Text            =   "Form1.frx":2316
         Top             =   8040
         Visible         =   0   'False
         Width           =   1215
      End
      Begin VB.TextBox Drivere 
         Height          =   615
         Left            =   -75000
         MultiLine       =   -1  'True
         ScrollBars      =   3  'Both
         TabIndex        =   206
         Text            =   "Form1.frx":2C38
         Top             =   8040
         Visible         =   0   'False
         Width           =   2295
      End
      Begin VB.TextBox Ajutor1 
         Height          =   975
         Left            =   -65160
         MultiLine       =   -1  'True
         ScrollBars      =   3  'Both
         TabIndex        =   205
         Text            =   "Form1.frx":2CD7
         Top             =   600
         Visible         =   0   'False
         Width           =   1935
      End
      Begin VB.TextBox Intro2 
         Height          =   1215
         Left            =   -72480
         MultiLine       =   -1  'True
         ScrollBars      =   3  'Both
         TabIndex        =   204
         Text            =   "Form1.frx":3539
         Top             =   4080
         Visible         =   0   'False
         Width           =   1935
      End
      Begin VB.TextBox Intro1 
         Height          =   1215
         Left            =   -74760
         MultiLine       =   -1  'True
         ScrollBars      =   3  'Both
         TabIndex        =   203
         Text            =   "Form1.frx":3AF3
         Top             =   4080
         Visible         =   0   'False
         Width           =   2175
      End
      Begin VB.TextBox revista2 
         Height          =   1455
         Left            =   -71760
         MultiLine       =   -1  'True
         ScrollBars      =   3  'Both
         TabIndex        =   202
         Text            =   "Form1.frx":44E3
         Top             =   6480
         Visible         =   0   'False
         Width           =   2895
      End
      Begin VB.TextBox revista1 
         Height          =   1455
         Left            =   -74760
         MultiLine       =   -1  'True
         ScrollBars      =   3  'Both
         TabIndex        =   201
         Text            =   "Form1.frx":450A
         Top             =   6480
         Visible         =   0   'False
         Width           =   2895
      End
      Begin VB.CommandButton Inainte_de 
         Caption         =   "Vezi cum arata inainte de compilare !"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Index           =   9
         Left            =   -71640
         TabIndex        =   199
         Top             =   8280
         Width           =   5775
      End
      Begin VB.CommandButton Inainte_de 
         Caption         =   "Vezi cum arata inainte de compilare !"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Index           =   8
         Left            =   -71640
         TabIndex        =   198
         Top             =   8280
         Width           =   5775
      End
      Begin VB.CommandButton Inainte_de 
         Caption         =   "Vezi cum arata inainte de compilare !      (pentru a vedea casuta de reclama trebuie sa astepti 7 secunde)"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Index           =   7
         Left            =   -74040
         TabIndex        =   197
         Top             =   8280
         Width           =   10935
      End
      Begin VB.CommandButton Inainte_de 
         Caption         =   "Vezi cum arata inainte de compilare !"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Index           =   6
         Left            =   -71640
         TabIndex        =   196
         Top             =   8280
         Width           =   5775
      End
      Begin VB.CommandButton Inainte_de 
         Caption         =   "Vezi cum arata inainte de compilare !"
         Height          =   255
         Index           =   5
         Left            =   -74640
         TabIndex        =   57
         Top             =   8280
         Width           =   8535
      End
      Begin VB.CommandButton Inainte_de 
         Caption         =   "Vezi cum arata inainte de compilare !"
         Height          =   255
         Index           =   4
         Left            =   -74640
         TabIndex        =   56
         Top             =   8280
         Width           =   8535
      End
      Begin VB.CommandButton Inainte_de 
         Caption         =   "Vezi cum arata inainte de compilare !"
         Height          =   255
         Index           =   3
         Left            =   -74640
         TabIndex        =   55
         Top             =   8280
         Width           =   8535
      End
      Begin VB.CommandButton Inainte_de 
         Caption         =   "Vezi cum arata inainte de compilare !"
         Height          =   255
         Index           =   2
         Left            =   -74640
         TabIndex        =   54
         Top             =   8280
         Width           =   8535
      End
      Begin VB.CommandButton Inainte_de 
         Caption         =   "Vezi cum arata inainte de compilare !"
         Height          =   255
         Index           =   1
         Left            =   -74640
         TabIndex        =   53
         Top             =   8280
         Width           =   8535
      End
      Begin VB.CommandButton Inainte_de 
         Caption         =   "Vezi cum arata inainte de compilare !"
         Height          =   255
         Index           =   0
         Left            =   360
         TabIndex        =   52
         Top             =   8280
         Width           =   8535
      End
      Begin VB.TextBox Citeste_Text 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   1815
         Index           =   5
         Left            =   -74640
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertical
         TabIndex        =   51
         Text            =   "Form1.frx":4E0C
         Top             =   3720
         Width           =   4575
      End
      Begin VB.TextBox Explicatie 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   1845
         Index           =   5
         Left            =   -74640
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertical
         TabIndex        =   50
         Text            =   "Form1.frx":4E56
         ToolTipText     =   "Date privind programul prezentat !"
         Top             =   1440
         Width           =   4575
      End
      Begin VB.TextBox Titlu 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   5
         Left            =   -72600
         MaxLength       =   36
         TabIndex        =   49
         Text            =   "Nume program"
         ToolTipText     =   "Nume program"
         Top             =   720
         Width           =   2535
      End
      Begin VB.CommandButton IN_Lista 
         Caption         =   "Introdu in lista de setari"
         Height          =   495
         Index           =   5
         Left            =   -74640
         TabIndex        =   48
         Top             =   7680
         Width           =   8535
      End
      Begin VB.CommandButton kit 
         Caption         =   "Kit-ul pt. butonul ""Instalare"""
         Height          =   255
         Index           =   5
         Left            =   -74640
         TabIndex        =   47
         Top             =   7320
         Width           =   2655
      End
      Begin VB.CommandButton kitZip 
         Caption         =   "Kit-ul pt. butonul ""Copiere"""
         Height          =   255
         Index           =   5
         Left            =   -74640
         TabIndex        =   46
         Top             =   6960
         Width           =   2655
      End
      Begin VB.TextBox cale2 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   5
         Left            =   -72000
         Locked          =   -1  'True
         TabIndex        =   45
         Top             =   7320
         Width           =   5775
      End
      Begin VB.TextBox calea 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   5
         Left            =   -72000
         Locked          =   -1  'True
         TabIndex        =   44
         Top             =   6960
         Width           =   5775
      End
      Begin VB.TextBox Citeste_Text 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   1815
         Index           =   4
         Left            =   -74640
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertical
         TabIndex        =   43
         Text            =   "Form1.frx":4E7B
         Top             =   3720
         Width           =   4575
      End
      Begin VB.TextBox Explicatie 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   1845
         Index           =   4
         Left            =   -74640
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertical
         TabIndex        =   42
         Text            =   "Form1.frx":4EC5
         ToolTipText     =   "Date privind programul prezentat !"
         Top             =   1440
         Width           =   4575
      End
      Begin VB.TextBox Titlu 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   4
         Left            =   -72600
         MaxLength       =   36
         TabIndex        =   41
         Text            =   "Nume program"
         ToolTipText     =   "Nume program"
         Top             =   720
         Width           =   2535
      End
      Begin VB.CommandButton IN_Lista 
         Caption         =   "Introdu in lista de setari"
         Height          =   495
         Index           =   4
         Left            =   -74640
         TabIndex        =   40
         Top             =   7680
         Width           =   8535
      End
      Begin VB.CommandButton kit 
         Caption         =   "Kit-ul pt. butonul ""Instalare"""
         Height          =   255
         Index           =   4
         Left            =   -74640
         TabIndex        =   39
         Top             =   7320
         Width           =   2655
      End
      Begin VB.CommandButton kitZip 
         Caption         =   "Kit-ul pt. butonul ""Copiere"""
         Height          =   255
         Index           =   4
         Left            =   -74640
         TabIndex        =   38
         Top             =   6960
         Width           =   2655
      End
      Begin VB.TextBox cale2 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   4
         Left            =   -72000
         Locked          =   -1  'True
         TabIndex        =   37
         Top             =   7320
         Width           =   5775
      End
      Begin VB.TextBox calea 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   4
         Left            =   -72000
         Locked          =   -1  'True
         TabIndex        =   36
         Top             =   6960
         Width           =   5775
      End
      Begin VB.TextBox Citeste_Text 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   1815
         Index           =   3
         Left            =   -74640
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertical
         TabIndex        =   35
         Text            =   "Form1.frx":4EEA
         Top             =   3720
         Width           =   4575
      End
      Begin VB.TextBox Explicatie 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   1845
         Index           =   3
         Left            =   -74640
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertical
         TabIndex        =   34
         Text            =   "Form1.frx":4F34
         ToolTipText     =   "Date privind programul prezentat !"
         Top             =   1440
         Width           =   4575
      End
      Begin VB.TextBox Titlu 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   3
         Left            =   -72600
         MaxLength       =   36
         TabIndex        =   33
         Text            =   "Nume program"
         ToolTipText     =   "Nume program"
         Top             =   720
         Width           =   2535
      End
      Begin VB.CommandButton IN_Lista 
         Caption         =   "Introdu in lista de setari"
         Height          =   495
         Index           =   3
         Left            =   -74640
         TabIndex        =   32
         Top             =   7680
         Width           =   8535
      End
      Begin VB.CommandButton kit 
         Caption         =   "Kit-ul pt. butonul ""Instalare"""
         Height          =   255
         Index           =   3
         Left            =   -74640
         TabIndex        =   31
         Top             =   7320
         Width           =   2655
      End
      Begin VB.CommandButton kitZip 
         Caption         =   "Kit-ul pt. butonul ""Copiere"""
         Height          =   255
         Index           =   3
         Left            =   -74640
         TabIndex        =   30
         Top             =   6960
         Width           =   2655
      End
      Begin VB.TextBox cale2 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   3
         Left            =   -72000
         Locked          =   -1  'True
         TabIndex        =   29
         Top             =   7320
         Width           =   5775
      End
      Begin VB.TextBox calea 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   3
         Left            =   -72000
         Locked          =   -1  'True
         TabIndex        =   28
         Top             =   6960
         Width           =   5775
      End
      Begin VB.TextBox Citeste_Text 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   1815
         Index           =   2
         Left            =   -74640
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertical
         TabIndex        =   27
         Text            =   "Form1.frx":4F59
         Top             =   3720
         Width           =   4575
      End
      Begin VB.TextBox Explicatie 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   1845
         Index           =   2
         Left            =   -74640
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertical
         TabIndex        =   26
         Text            =   "Form1.frx":4FA3
         ToolTipText     =   "Date privind programul prezentat !"
         Top             =   1440
         Width           =   4575
      End
      Begin VB.TextBox Titlu 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   2
         Left            =   -72600
         MaxLength       =   36
         TabIndex        =   25
         Text            =   "Nume program"
         ToolTipText     =   "Nume program"
         Top             =   720
         Width           =   2535
      End
      Begin VB.CommandButton IN_Lista 
         Caption         =   "Introdu in lista de setari"
         Height          =   495
         Index           =   2
         Left            =   -74640
         TabIndex        =   24
         Top             =   7680
         Width           =   8535
      End
      Begin VB.CommandButton kit 
         Caption         =   "Kit-ul pt. butonul ""Instalare"""
         Height          =   255
         Index           =   2
         Left            =   -74640
         TabIndex        =   23
         Top             =   7320
         Width           =   2655
      End
      Begin VB.CommandButton kitZip 
         Caption         =   "Kit-ul pt. butonul ""Copiere"""
         Height          =   255
         Index           =   2
         Left            =   -74640
         TabIndex        =   22
         Top             =   6960
         Width           =   2655
      End
      Begin VB.TextBox cale2 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   2
         Left            =   -72000
         Locked          =   -1  'True
         TabIndex        =   21
         Top             =   7320
         Width           =   5775
      End
      Begin VB.TextBox calea 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   2
         Left            =   -72000
         Locked          =   -1  'True
         TabIndex        =   20
         Top             =   6960
         Width           =   5775
      End
      Begin VB.TextBox calea 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   1
         Left            =   -72000
         Locked          =   -1  'True
         TabIndex        =   19
         Top             =   6960
         Width           =   5775
      End
      Begin VB.TextBox cale2 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   1
         Left            =   -72000
         Locked          =   -1  'True
         TabIndex        =   18
         Top             =   7320
         Width           =   5775
      End
      Begin VB.CommandButton kitZip 
         Caption         =   "Kit-ul pt. butonul ""Copiere"""
         Height          =   255
         Index           =   1
         Left            =   -74640
         TabIndex        =   17
         Top             =   6960
         Width           =   2655
      End
      Begin VB.CommandButton kit 
         Caption         =   "Kit-ul pt. butonul ""Instalare"""
         Height          =   255
         Index           =   1
         Left            =   -74640
         TabIndex        =   16
         Top             =   7320
         Width           =   2655
      End
      Begin VB.CommandButton IN_Lista 
         Caption         =   "Introdu in lista de setari"
         Height          =   495
         Index           =   1
         Left            =   -74640
         TabIndex        =   15
         Top             =   7680
         Width           =   8535
      End
      Begin VB.TextBox Titlu 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   1
         Left            =   -72600
         MaxLength       =   36
         TabIndex        =   14
         Text            =   "Nume program"
         ToolTipText     =   "Nume program"
         Top             =   720
         Width           =   2535
      End
      Begin VB.TextBox Explicatie 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   1845
         Index           =   1
         Left            =   -74640
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertical
         TabIndex        =   13
         Text            =   "Form1.frx":4FC8
         ToolTipText     =   "Date privind programul prezentat !"
         Top             =   1440
         Width           =   4575
      End
      Begin VB.TextBox Citeste_Text 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   1815
         Index           =   1
         Left            =   -74640
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertical
         TabIndex        =   12
         Text            =   "Form1.frx":4FED
         Top             =   3720
         Width           =   4575
      End
      Begin VB.TextBox Citeste_Text 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   1815
         Index           =   0
         Left            =   360
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertical
         TabIndex        =   11
         Text            =   "Form1.frx":5037
         Top             =   3720
         Width           =   4575
      End
      Begin VB.CommandButton IN_Lista 
         Caption         =   "Introdu datele in lista de setari"
         Height          =   495
         Index           =   0
         Left            =   360
         TabIndex        =   10
         Top             =   7680
         Width           =   8535
      End
      Begin VB.CommandButton kit 
         Caption         =   "Kit-ul pt. butonul ""Instalare"""
         Height          =   255
         Index           =   0
         Left            =   360
         TabIndex        =   9
         Top             =   7320
         Width           =   2655
      End
      Begin VB.CommandButton kitZip 
         Caption         =   "Kit-ul pt. butonul ""Copiere"""
         Height          =   255
         Index           =   0
         Left            =   360
         TabIndex        =   8
         Top             =   6960
         Width           =   2655
      End
      Begin VB.TextBox Revista 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FFFF&
         Height          =   7335
         Left            =   -74880
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertical
         TabIndex        =   7
         Text            =   "Form1.frx":5074
         Top             =   720
         Width           =   12135
      End
      Begin VB.TextBox Intro 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   3015
         Left            =   -74880
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertical
         TabIndex        =   6
         Text            =   "Form1.frx":60DA
         Top             =   480
         Width           =   12015
      End
      Begin VB.TextBox Ajutor 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   5415
         Left            =   -74760
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertical
         TabIndex        =   5
         Text            =   "Form1.frx":6279
         Top             =   480
         Width           =   11895
      End
      Begin VB.TextBox cale2 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   0
         Left            =   3000
         Locked          =   -1  'True
         TabIndex        =   4
         Top             =   7320
         Width           =   5775
      End
      Begin VB.TextBox calea 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   0
         Left            =   3000
         Locked          =   -1  'True
         TabIndex        =   3
         Top             =   6960
         Width           =   5775
      End
      Begin VB.TextBox Explicatie 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   1845
         Index           =   0
         Left            =   360
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertical
         TabIndex        =   2
         Text            =   "Form1.frx":6C2A
         ToolTipText     =   "Date despre utilitarul prezentat !"
         Top             =   1440
         Width           =   4575
      End
      Begin VB.TextBox Titlu 
         BackColor       =   &H00000000&
         ForeColor       =   &H0000FF00&
         Height          =   285
         Index           =   0
         Left            =   2400
         MaxLength       =   36
         TabIndex        =   1
         Text            =   "Nume utilitar"
         ToolTipText     =   "Nume utilitar"
         Top             =   720
         Width           =   2535
      End
      Begin GenerareMatrita.Buton_3D_General zi_mai 
         Height          =   495
         Index           =   1
         Left            =   -68760
         TabIndex        =   417
         Top             =   2040
         Width           =   855
         _ExtentX        =   1508
         _ExtentY        =   873
         Caption         =   "STOP"
         ButtonStyle     =   3
         OriginalPicSizeW=   0
         OriginalPicSizeH=   0
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         MousePointer    =   99
      End
      Begin GenerareMatrita.Listare_Tip_GIF Imagine_Meniu 
         Height          =   2655
         Index           =   1
         Left            =   -65880
         Top             =   600
         Width           =   3015
         _ExtentX        =   5318
         _ExtentY        =   4683
      End
      Begin GenerareMatrita.Listare_Tip_GIF Imagine_Meniu 
         Height          =   2655
         Index           =   2
         Left            =   -65880
         Top             =   600
         Width           =   3015
         _ExtentX        =   5318
         _ExtentY        =   4683
      End
      Begin GenerareMatrita.Listare_Tip_GIF Imagine_Meniu 
         Height          =   2655
         Index           =   3
         Left            =   -65880
         Top             =   600
         Width           =   3015
         _ExtentX        =   5318
         _ExtentY        =   4683
      End
      Begin GenerareMatrita.Listare_Tip_GIF Imagine_Meniu 
         Height          =   2655
         Index           =   4
         Left            =   -65880
         Top             =   600
         Width           =   3015
         _ExtentX        =   5318
         _ExtentY        =   4683
      End
      Begin GenerareMatrita.Listare_Tip_GIF Imagine_Meniu 
         Height          =   2655
         Index           =   5
         Left            =   -65880
         Top             =   600
         Width           =   3015
         _ExtentX        =   5318
         _ExtentY        =   4683
      End
      Begin GenerareMatrita.Listare_Tip_GIF Pro_imagine 
         Height          =   2655
         Index           =   1
         Left            =   -65880
         Top             =   5760
         Width           =   3015
         _ExtentX        =   5318
         _ExtentY        =   4683
      End
      Begin GenerareMatrita.Listare_Tip_GIF Pro_imagine 
         Height          =   2655
         Index           =   2
         Left            =   -65880
         Top             =   5760
         Width           =   3015
         _ExtentX        =   5318
         _ExtentY        =   4683
      End
      Begin GenerareMatrita.Listare_Tip_GIF Pro_imagine 
         Height          =   2655
         Index           =   3
         Left            =   -65880
         Top             =   5760
         Width           =   3015
         _ExtentX        =   5318
         _ExtentY        =   4683
      End
      Begin GenerareMatrita.Listare_Tip_GIF Pro_imagine 
         Height          =   2655
         Index           =   4
         Left            =   -65880
         Top             =   5760
         Width           =   3015
         _ExtentX        =   5318
         _ExtentY        =   4683
      End
      Begin GenerareMatrita.Listare_Tip_GIF Pro_imagine 
         Height          =   2655
         Index           =   5
         Left            =   -65880
         Top             =   5760
         Width           =   3015
         _ExtentX        =   5318
         _ExtentY        =   4683
      End
      Begin GenerareMatrita.Buton_3D_General xls_ul 
         Height          =   255
         Left            =   -69720
         TabIndex        =   419
         Top             =   1080
         Width           =   1815
         _ExtentX        =   1508
         _ExtentY        =   873
         Caption         =   "Deschide XLS"
         ButtonStyle     =   3
         OriginalPicSizeW=   0
         OriginalPicSizeH=   0
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         MousePointer    =   99
      End
      Begin VB.Shape Shape10 
         BorderColor     =   &H00000000&
         Height          =   975
         Left            =   -74880
         Top             =   480
         Width           =   12135
      End
      Begin VB.Shape Shape9 
         BorderColor     =   &H00000000&
         Height          =   1095
         Left            =   -74880
         Top             =   1560
         Width           =   12135
      End
      Begin VB.Shape Shape5 
         BorderColor     =   &H00000000&
         Height          =   375
         Left            =   -74880
         Top             =   4680
         Width           =   12015
      End
      Begin VB.Line Line25 
         BorderColor     =   &H00000000&
         X1              =   -69840
         X2              =   -69840
         Y1              =   5040
         Y2              =   7320
      End
      Begin VB.Label lalalalalala 
         Caption         =   "Textul din cercul rotativ :"
         Height          =   255
         Left            =   -71400
         TabIndex        =   391
         Top             =   5520
         Width           =   2895
      End
      Begin VB.Image Image2 
         Height          =   3600
         Left            =   -70200
         Picture         =   "Form1.frx":6C4F
         Top             =   3000
         Visible         =   0   'False
         Width           =   3090
      End
      Begin VB.Label Label46 
         BackStyle       =   0  'Transparent
         Caption         =   "Textul cu care se scriu explicatiile privitoare la drivere :"
         Height          =   255
         Left            =   -68760
         TabIndex        =   381
         Top             =   5160
         Width           =   3975
      End
      Begin VB.Label Label45 
         BackStyle       =   0  'Transparent
         Caption         =   "Textul cu care se scriu numele driverilor :"
         Height          =   255
         Left            =   -74760
         TabIndex        =   380
         Top             =   5160
         Width           =   3495
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF00FF&
         Height          =   255
         Index           =   66
         Left            =   -63000
         TabIndex        =   379
         Top             =   7680
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   65
         Left            =   -70800
         TabIndex        =   378
         Top             =   480
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF0000&
         Height          =   255
         Index           =   64
         Left            =   8760
         TabIndex        =   377
         Top             =   6960
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   63
         Left            =   -63000
         TabIndex        =   376
         Top             =   720
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   62
         Left            =   -63000
         TabIndex        =   375
         Top             =   1680
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF00FF&
         Height          =   255
         Index           =   61
         Left            =   -63000
         TabIndex        =   374
         Top             =   7440
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   60
         Left            =   -69480
         TabIndex        =   373
         Top             =   480
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   59
         Left            =   -69480
         TabIndex        =   372
         Top             =   720
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   58
         Left            =   -69480
         TabIndex        =   371
         Top             =   960
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF00FF&
         Height          =   255
         Index           =   57
         Left            =   -71160
         TabIndex        =   370
         Top             =   5520
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF00FF&
         Height          =   255
         Index           =   56
         Left            =   -71160
         TabIndex        =   369
         Top             =   5880
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF00FF&
         Height          =   255
         Index           =   55
         Left            =   -71160
         TabIndex        =   368
         Top             =   6240
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF00FF&
         Height          =   255
         Index           =   54
         Left            =   -64920
         TabIndex        =   367
         Top             =   5520
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF00FF&
         Height          =   255
         Index           =   53
         Left            =   -64920
         TabIndex        =   366
         Top             =   5880
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF00FF&
         Height          =   255
         Index           =   52
         Left            =   -64920
         TabIndex        =   365
         Top             =   6240
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF00FF&
         Height          =   255
         Index           =   51
         Left            =   -62880
         TabIndex        =   364
         Top             =   480
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF00FF&
         Height          =   255
         Index           =   50
         Left            =   -71160
         TabIndex        =   363
         Top             =   6840
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF00FF&
         Height          =   255
         Index           =   49
         Left            =   -71160
         TabIndex        =   362
         Top             =   6480
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF00FF&
         Height          =   255
         Index           =   48
         Left            =   -71160
         TabIndex        =   361
         Top             =   6120
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF00FF&
         Height          =   255
         Index           =   41
         Left            =   -62880
         TabIndex        =   360
         Top             =   480
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF0000&
         Height          =   255
         Index           =   40
         Left            =   -66240
         TabIndex        =   359
         Top             =   7320
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF0000&
         Height          =   255
         Index           =   39
         Left            =   -66240
         TabIndex        =   358
         Top             =   6960
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   38
         Left            =   -66240
         TabIndex        =   357
         Top             =   6600
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   37
         Left            =   -66240
         TabIndex        =   356
         Top             =   6240
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   36
         Left            =   -70080
         TabIndex        =   355
         Top             =   3720
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   35
         Left            =   -70080
         TabIndex        =   354
         Top             =   1440
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   34
         Left            =   -70080
         TabIndex        =   353
         Top             =   720
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF0000&
         Height          =   255
         Index           =   33
         Left            =   -66240
         TabIndex        =   352
         Top             =   7320
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF0000&
         Height          =   255
         Index           =   32
         Left            =   -66240
         TabIndex        =   351
         Top             =   6960
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   31
         Left            =   -66240
         TabIndex        =   350
         Top             =   6600
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   30
         Left            =   -66240
         TabIndex        =   349
         Top             =   6240
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   29
         Left            =   -70080
         TabIndex        =   348
         Top             =   3720
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   28
         Left            =   -70080
         TabIndex        =   347
         Top             =   1440
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   27
         Left            =   -70080
         TabIndex        =   346
         Top             =   720
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF0000&
         Height          =   255
         Index           =   26
         Left            =   -66240
         TabIndex        =   345
         Top             =   7320
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF0000&
         Height          =   255
         Index           =   25
         Left            =   -66240
         TabIndex        =   344
         Top             =   6960
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   24
         Left            =   -66240
         TabIndex        =   343
         Top             =   6600
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   23
         Left            =   -66240
         TabIndex        =   342
         Top             =   6240
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   22
         Left            =   -70080
         TabIndex        =   341
         Top             =   3720
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   21
         Left            =   -70080
         TabIndex        =   340
         Top             =   1440
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   20
         Left            =   -70080
         TabIndex        =   339
         Top             =   720
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF0000&
         Height          =   255
         Index           =   19
         Left            =   -66240
         TabIndex        =   338
         Top             =   7320
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF0000&
         Height          =   255
         Index           =   18
         Left            =   -66240
         TabIndex        =   337
         Top             =   6960
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   17
         Left            =   -66240
         TabIndex        =   336
         Top             =   6600
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   16
         Left            =   -66240
         TabIndex        =   335
         Top             =   6240
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   15
         Left            =   -70080
         TabIndex        =   334
         Top             =   3720
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   14
         Left            =   -70080
         TabIndex        =   333
         Top             =   1440
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   13
         Left            =   -70080
         TabIndex        =   332
         Top             =   720
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF0000&
         Height          =   255
         Index           =   12
         Left            =   -66240
         TabIndex        =   331
         Top             =   7320
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF0000&
         Height          =   255
         Index           =   11
         Left            =   -66240
         TabIndex        =   330
         Top             =   6960
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   10
         Left            =   -66240
         TabIndex        =   329
         Top             =   6600
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   9
         Left            =   -66240
         TabIndex        =   328
         Top             =   6240
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   8
         Left            =   -70080
         TabIndex        =   327
         Top             =   3720
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   7
         Left            =   -70080
         TabIndex        =   326
         Top             =   1440
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   5
         Left            =   -70080
         TabIndex        =   325
         Top             =   720
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF0000&
         Height          =   255
         Index           =   6
         Left            =   8760
         TabIndex        =   324
         Top             =   7320
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   4
         Left            =   8760
         TabIndex        =   323
         Top             =   6600
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   3
         Left            =   8760
         TabIndex        =   322
         Top             =   6240
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   2
         Left            =   4920
         TabIndex        =   321
         Top             =   3720
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   1
         Left            =   4920
         TabIndex        =   320
         Top             =   1440
         Width           =   135
      End
      Begin VB.Label Trebuie_completat 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   255
         Index           =   0
         Left            =   4920
         TabIndex        =   319
         Top             =   720
         Width           =   135
      End
      Begin VB.Label Label44 
         Caption         =   "Am vorbit la telefon de partea asta ... este doar HTML  ... "
         Height          =   255
         Left            =   -74880
         TabIndex        =   318
         Top             =   480
         Width           =   4455
      End
      Begin VB.Shape Shape8 
         BorderColor     =   &H00808080&
         Height          =   1335
         Left            =   -68760
         Top             =   5400
         Width           =   4095
      End
      Begin VB.Label Label43 
         Caption         =   "Marime font:"
         Height          =   255
         Left            =   -68640
         TabIndex        =   317
         Top             =   6240
         Width           =   1095
      End
      Begin VB.Label Label42 
         Caption         =   "Culoare font:"
         Height          =   255
         Left            =   -68640
         TabIndex        =   316
         Top             =   5880
         Width           =   1095
      End
      Begin VB.Label Label41 
         Caption         =   "Culoare font:"
         Height          =   255
         Left            =   -68640
         TabIndex        =   315
         Top             =   5520
         Width           =   1095
      End
      Begin VB.Shape Shape7 
         BorderColor     =   &H00808080&
         Height          =   495
         Left            =   -74760
         Top             =   7320
         Width           =   12015
      End
      Begin VB.Label Label40 
         Caption         =   "Culoare font:"
         Height          =   255
         Left            =   -74640
         TabIndex        =   309
         Top             =   5520
         Width           =   1095
      End
      Begin VB.Label Label39 
         Caption         =   "Culoare font:"
         Height          =   255
         Left            =   -74640
         TabIndex        =   308
         Top             =   5880
         Width           =   1095
      End
      Begin VB.Label Label26 
         Caption         =   "Marime font:"
         Height          =   255
         Left            =   -74640
         TabIndex        =   307
         Top             =   6240
         Width           =   1095
      End
      Begin VB.Shape Shape6 
         BorderColor     =   &H00808080&
         Height          =   1335
         Left            =   -74760
         Top             =   5400
         Width           =   3855
      End
      Begin VB.Label etete 
         Caption         =   "Nu este necesara completarea tuturor casutelor dar trebuie completata cel putin una !"
         Height          =   255
         Left            =   -72480
         TabIndex        =   303
         Top             =   4800
         Width           =   6135
      End
      Begin VB.Line Line24 
         BorderColor     =   &H00000000&
         X1              =   -69240
         X2              =   -69240
         Y1              =   360
         Y2              =   4200
      End
      Begin VB.Line Line23 
         BorderColor     =   &H00000000&
         Index           =   4
         X1              =   -74880
         X2              =   -62880
         Y1              =   360
         Y2              =   360
      End
      Begin VB.Line Line23 
         BorderColor     =   &H00000000&
         Index           =   3
         X1              =   -74880
         X2              =   -62760
         Y1              =   4200
         Y2              =   4200
      End
      Begin VB.Line Line23 
         BorderColor     =   &H00000000&
         Index           =   2
         X1              =   -74880
         X2              =   -62760
         Y1              =   3240
         Y2              =   3240
      End
      Begin VB.Line Line23 
         BorderColor     =   &H00000000&
         Index           =   1
         X1              =   -74880
         X2              =   -62760
         Y1              =   2280
         Y2              =   2280
      End
      Begin VB.Line Line23 
         BorderColor     =   &H00000000&
         Index           =   0
         X1              =   -74880
         X2              =   -62760
         Y1              =   1320
         Y2              =   1320
      End
      Begin VB.Label DriverInformatii3 
         Caption         =   "Calea spre aplicatia de instalare:"
         Height          =   255
         Index           =   7
         Left            =   -69120
         TabIndex        =   302
         Top             =   3840
         Width           =   2415
      End
      Begin VB.Label DriverInformatii2 
         Caption         =   "Explicatii scurte privind driver-ul:"
         Height          =   255
         Index           =   7
         Left            =   -69120
         TabIndex        =   301
         Top             =   3600
         Width           =   2415
      End
      Begin VB.Label DriverInformatii1 
         Caption         =   "Nume driver:"
         Height          =   255
         Index           =   7
         Left            =   -69120
         TabIndex        =   300
         Top             =   3360
         Width           =   1695
      End
      Begin VB.Label DriverInformatii3 
         Caption         =   "Calea spre aplicatia de instalare:"
         Height          =   255
         Index           =   6
         Left            =   -69120
         TabIndex        =   299
         Top             =   2880
         Width           =   2415
      End
      Begin VB.Label DriverInformatii2 
         Caption         =   "Explicatii scurte privind driver-ul:"
         Height          =   255
         Index           =   6
         Left            =   -69120
         TabIndex        =   298
         Top             =   2640
         Width           =   2415
      End
      Begin VB.Label DriverInformatii1 
         Caption         =   "Nume driver:"
         Height          =   255
         Index           =   6
         Left            =   -69120
         TabIndex        =   297
         Top             =   2400
         Width           =   1695
      End
      Begin VB.Label DriverInformatii3 
         Caption         =   "Calea spre aplicatia de instalare:"
         Height          =   255
         Index           =   5
         Left            =   -69120
         TabIndex        =   296
         Top             =   1920
         Width           =   2415
      End
      Begin VB.Label DriverInformatii2 
         Caption         =   "Explicatii scurte privind driver-ul:"
         Height          =   255
         Index           =   5
         Left            =   -69120
         TabIndex        =   295
         Top             =   1680
         Width           =   2415
      End
      Begin VB.Label DriverInformatii1 
         Caption         =   "Nume driver:"
         Height          =   255
         Index           =   5
         Left            =   -69120
         TabIndex        =   294
         Top             =   1440
         Width           =   1695
      End
      Begin VB.Label DriverInformatii3 
         Caption         =   "Calea spre aplicatia de instalare:"
         Height          =   255
         Index           =   4
         Left            =   -69120
         TabIndex        =   293
         Top             =   960
         Width           =   2415
      End
      Begin VB.Label DriverInformatii2 
         Caption         =   "Explicatii scurte privind driver-ul:"
         Height          =   255
         Index           =   4
         Left            =   -69120
         TabIndex        =   292
         Top             =   720
         Width           =   2415
      End
      Begin VB.Label DriverInformatii1 
         Caption         =   "Nume driver:"
         Height          =   255
         Index           =   4
         Left            =   -69120
         TabIndex        =   291
         Top             =   480
         Width           =   1695
      End
      Begin VB.Label DriverInformatii3 
         Caption         =   "Calea spre aplicatia de instalare:"
         Height          =   255
         Index           =   3
         Left            =   -74880
         TabIndex        =   290
         Top             =   3840
         Width           =   2415
      End
      Begin VB.Label DriverInformatii2 
         Caption         =   "Explicatii scurte privind driver-ul:"
         Height          =   255
         Index           =   3
         Left            =   -74880
         TabIndex        =   289
         Top             =   3600
         Width           =   2415
      End
      Begin VB.Label DriverInformatii1 
         Caption         =   "Nume driver:"
         Height          =   255
         Index           =   3
         Left            =   -74880
         TabIndex        =   288
         Top             =   3360
         Width           =   1695
      End
      Begin VB.Label DriverInformatii3 
         Caption         =   "Calea spre aplicatia de instalare:"
         Height          =   255
         Index           =   2
         Left            =   -74880
         TabIndex        =   287
         Top             =   2880
         Width           =   2415
      End
      Begin VB.Label DriverInformatii2 
         Caption         =   "Explicatii scurte privind driver-ul:"
         Height          =   255
         Index           =   2
         Left            =   -74880
         TabIndex        =   286
         Top             =   2640
         Width           =   2415
      End
      Begin VB.Label DriverInformatii1 
         Caption         =   "Nume driver:"
         Height          =   255
         Index           =   2
         Left            =   -74880
         TabIndex        =   285
         Top             =   2400
         Width           =   1695
      End
      Begin VB.Label DriverInformatii3 
         Caption         =   "Calea spre aplicatia de instalare:"
         Height          =   255
         Index           =   1
         Left            =   -74880
         TabIndex        =   284
         Top             =   1920
         Width           =   2415
      End
      Begin VB.Label DriverInformatii2 
         Caption         =   "Explicatii scurte privind driver-ul:"
         Height          =   255
         Index           =   1
         Left            =   -74880
         TabIndex        =   283
         Top             =   1680
         Width           =   2415
      End
      Begin VB.Label DriverInformatii1 
         Caption         =   "Nume driver:"
         Height          =   255
         Index           =   1
         Left            =   -74880
         TabIndex        =   282
         Top             =   1440
         Width           =   1695
      End
      Begin VB.Label DriverInformatii3 
         Caption         =   "Calea spre aplicatia de instalare:"
         Height          =   255
         Index           =   0
         Left            =   -74880
         TabIndex        =   281
         Top             =   960
         Width           =   2415
      End
      Begin VB.Label DriverInformatii2 
         Caption         =   "Explicatii scurte privind driver-ul:"
         Height          =   255
         Index           =   0
         Left            =   -74880
         TabIndex        =   280
         Top             =   720
         Width           =   2415
      End
      Begin VB.Label DriverInformatii1 
         Caption         =   "Nume driver:"
         Height          =   255
         Index           =   0
         Left            =   -74880
         TabIndex        =   279
         Top             =   480
         Width           =   1695
      End
      Begin VB.Line Line18 
         BorderColor     =   &H00000000&
         Index           =   5
         X1              =   -68160
         X2              =   -68160
         Y1              =   6000
         Y2              =   6240
      End
      Begin VB.Line Line18 
         BorderColor     =   &H00000000&
         Index           =   4
         X1              =   -69000
         X2              =   -69000
         Y1              =   6000
         Y2              =   6240
      End
      Begin VB.Line Line18 
         BorderColor     =   &H00000000&
         Index           =   3
         X1              =   -69480
         X2              =   -69480
         Y1              =   6000
         Y2              =   6240
      End
      Begin VB.Line Line18 
         BorderColor     =   &H00000000&
         Index           =   2
         X1              =   -70200
         X2              =   -70200
         Y1              =   6000
         Y2              =   6240
      End
      Begin VB.Line Line18 
         BorderColor     =   &H00000000&
         Index           =   1
         X1              =   -71160
         X2              =   -71160
         Y1              =   6000
         Y2              =   6240
      End
      Begin VB.Line Line18 
         BorderColor     =   &H00000000&
         Index           =   0
         X1              =   3480
         X2              =   3480
         Y1              =   6000
         Y2              =   6240
      End
      Begin VB.Shape Shape4 
         BorderColor     =   &H00808080&
         Height          =   495
         Left            =   -74760
         Top             =   7560
         Width           =   12015
      End
      Begin VB.Shape Shape3 
         BackColor       =   &H00C0C0C0&
         BorderColor     =   &H00808080&
         Height          =   1335
         Left            =   -68640
         Top             =   6000
         Width           =   5175
      End
      Begin VB.Label Label38 
         Caption         =   $"Form1.frx":801E
         Height          =   1095
         Left            =   -68520
         TabIndex        =   245
         Top             =   6120
         Width           =   5055
      End
      Begin VB.Line Line22 
         BorderColor     =   &H00000000&
         X1              =   -70680
         X2              =   -70920
         Y1              =   6840
         Y2              =   6720
      End
      Begin VB.Line Line21 
         BorderColor     =   &H00000000&
         X1              =   -70680
         X2              =   -70920
         Y1              =   6600
         Y2              =   6720
      End
      Begin VB.Line Line20 
         BorderColor     =   &H00000000&
         X1              =   -70920
         X2              =   -69600
         Y1              =   6720
         Y2              =   6720
      End
      Begin VB.Line Line19 
         BorderColor     =   &H00000000&
         X1              =   -69600
         X2              =   -69600
         Y1              =   5880
         Y2              =   6720
      End
      Begin VB.Shape Shape2 
         BorderColor     =   &H00808080&
         Height          =   1335
         Left            =   -74760
         Top             =   6000
         Width           =   3855
      End
      Begin VB.Label Label37 
         Caption         =   "Marime font:"
         Height          =   255
         Left            =   -74640
         TabIndex        =   244
         Top             =   6840
         Width           =   1095
      End
      Begin VB.Label Label36 
         Caption         =   "Culoare font:"
         Height          =   255
         Left            =   -74640
         TabIndex        =   243
         Top             =   6480
         Width           =   1095
      End
      Begin VB.Label Label35 
         Caption         =   "Culoare font:"
         Height          =   255
         Left            =   -74640
         TabIndex        =   242
         Top             =   6120
         Width           =   1095
      End
      Begin VB.Label Label27 
         Alignment       =   2  'Center
         BackStyle       =   0  'Transparent
         Caption         =   "Compilare..."
         BeginProperty Font 
            Name            =   "System"
            Size            =   9.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Left            =   -69720
         TabIndex        =   210
         Top             =   360
         Width           =   1935
      End
      Begin VB.Line Line11 
         BorderColor     =   &H00000000&
         X1              =   -69720
         X2              =   -62760
         Y1              =   5400
         Y2              =   5400
      End
      Begin VB.Shape BorduraTemp 
         BackColor       =   &H000000FF&
         BorderColor     =   &H00000000&
         Height          =   2895
         Index           =   5
         Left            =   -66000
         Top             =   5640
         Width           =   3255
      End
      Begin VB.Shape BorduraTemp 
         BackColor       =   &H000000FF&
         BorderColor     =   &H00000000&
         Height          =   2895
         Index           =   4
         Left            =   -66000
         Top             =   5640
         Width           =   3255
      End
      Begin VB.Shape BorduraTemp 
         BackColor       =   &H000000FF&
         BorderColor     =   &H00000000&
         Height          =   2895
         Index           =   3
         Left            =   -66000
         Top             =   5640
         Width           =   3255
      End
      Begin VB.Line Line1 
         BorderColor     =   &H00000000&
         Index           =   4
         X1              =   -69720
         X2              =   -62760
         Y1              =   5400
         Y2              =   5400
      End
      Begin VB.Shape BorduraTemp 
         BackColor       =   &H000000FF&
         BorderColor     =   &H00000000&
         Height          =   2895
         Index           =   2
         Left            =   -66000
         Top             =   5640
         Width           =   3255
      End
      Begin VB.Line Line1 
         BorderColor     =   &H00000000&
         Index           =   3
         X1              =   -69720
         X2              =   -62760
         Y1              =   5400
         Y2              =   5400
      End
      Begin VB.Label Label28 
         Alignment       =   2  'Center
         Caption         =   "Permanente"
         BeginProperty Font 
            Name            =   "MS Serif"
            Size            =   24
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   615
         Index           =   5
         Left            =   -65880
         TabIndex        =   195
         Top             =   3960
         Width           =   3015
      End
      Begin VB.Label Label28 
         Alignment       =   2  'Center
         Caption         =   "Antivirus"
         BeginProperty Font 
            Name            =   "MS Serif"
            Size            =   24
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   615
         Index           =   4
         Left            =   -65880
         TabIndex        =   194
         Top             =   3960
         Width           =   3015
      End
      Begin VB.Label Label28 
         Alignment       =   2  'Center
         Caption         =   "Internet"
         BeginProperty Font 
            Name            =   "MS Serif"
            Size            =   24
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   615
         Index           =   3
         Left            =   -65880
         TabIndex        =   193
         Top             =   3960
         Width           =   3015
      End
      Begin VB.Label Label28 
         Alignment       =   2  'Center
         Caption         =   "Jocuri"
         BeginProperty Font 
            Name            =   "MS Serif"
            Size            =   24
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   615
         Index           =   2
         Left            =   -65880
         TabIndex        =   192
         Top             =   3960
         Width           =   3015
      End
      Begin VB.Label Label28 
         Alignment       =   2  'Center
         Caption         =   "Multimedia"
         BeginProperty Font 
            Name            =   "MS Serif"
            Size            =   24
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   615
         Index           =   1
         Left            =   -65880
         TabIndex        =   191
         Top             =   3960
         Width           =   3015
      End
      Begin VB.Shape BorduraGata 
         BorderColor     =   &H00000000&
         Height          =   2895
         Index           =   5
         Left            =   -66000
         Top             =   480
         Width           =   3255
      End
      Begin VB.Shape BorduraGata 
         BorderColor     =   &H00000000&
         Height          =   2895
         Index           =   4
         Left            =   -66000
         Top             =   480
         Width           =   3255
      End
      Begin VB.Shape BorduraGata 
         BorderColor     =   &H00000000&
         Height          =   2895
         Index           =   3
         Left            =   -66000
         Top             =   480
         Width           =   3255
      End
      Begin VB.Shape BorduraGata 
         BorderColor     =   &H00000000&
         Height          =   2895
         Index           =   2
         Left            =   -66000
         Top             =   480
         Width           =   3255
      End
      Begin VB.Shape BorduraGata 
         BorderColor     =   &H00000000&
         Height          =   2895
         Index           =   1
         Left            =   -66000
         Top             =   480
         Width           =   3255
      End
      Begin VB.Shape BorduraGata 
         BorderColor     =   &H00000000&
         Height          =   2895
         Index           =   0
         Left            =   9000
         Top             =   480
         Width           =   3255
      End
      Begin VB.Line Line1 
         BorderColor     =   &H00000000&
         Index           =   1
         X1              =   5280
         X2              =   12240
         Y1              =   5400
         Y2              =   5400
      End
      Begin VB.Line Line7 
         BorderColor     =   &H00000000&
         X1              =   -69720
         X2              =   -62760
         Y1              =   5400
         Y2              =   5400
      End
      Begin VB.Label Label24 
         Caption         =   "Informatii ce se vor citi la apasarea butonului ""Citeste-ma"""
         Height          =   255
         Left            =   -74640
         TabIndex        =   190
         Top             =   3480
         Width           =   4215
      End
      Begin VB.Label Label23 
         Caption         =   "Expicatii despre programul prezentat"
         Height          =   255
         Left            =   -74640
         TabIndex        =   189
         Top             =   1200
         Width           =   2775
      End
      Begin VB.Label Label22 
         Caption         =   "Titlul programului prezentat:"
         Height          =   255
         Left            =   -74640
         TabIndex        =   188
         Top             =   720
         Width           =   2055
      End
      Begin VB.Label Label21 
         Alignment       =   2  'Center
         Caption         =   "Programele introduse deja."
         Height          =   255
         Left            =   -69360
         TabIndex        =   187
         Top             =   480
         Width           =   3015
      End
      Begin VB.Line Line6 
         BorderColor     =   &H00000000&
         X1              =   -69840
         X2              =   -69840
         Y1              =   600
         Y2              =   5280
      End
      Begin VB.Label ListaMarePR 
         Caption         =   "18 nimic"
         Height          =   255
         Index           =   17
         Left            =   -69600
         TabIndex        =   186
         Top             =   4920
         Width           =   3375
      End
      Begin VB.Label ListaMarePR 
         Caption         =   "17 nimic"
         Height          =   255
         Index           =   16
         Left            =   -69600
         TabIndex        =   185
         Top             =   4680
         Width           =   3375
      End
      Begin VB.Label ListaMarePR 
         Caption         =   "16 nimic"
         Height          =   255
         Index           =   15
         Left            =   -69600
         TabIndex        =   184
         Top             =   4440
         Width           =   3375
      End
      Begin VB.Label ListaMarePR 
         Caption         =   "15 nimic"
         Height          =   255
         Index           =   14
         Left            =   -69600
         TabIndex        =   183
         Top             =   4200
         Width           =   3375
      End
      Begin VB.Label ListaMarePR 
         Caption         =   "14 nimic"
         Height          =   255
         Index           =   13
         Left            =   -69600
         TabIndex        =   182
         Top             =   3960
         Width           =   3375
      End
      Begin VB.Label ListaMarePR 
         Caption         =   "13 nimic"
         Height          =   255
         Index           =   12
         Left            =   -69600
         TabIndex        =   181
         Top             =   3720
         Width           =   3375
      End
      Begin VB.Label ListaMarePR 
         Caption         =   "12 nimic"
         Height          =   255
         Index           =   11
         Left            =   -69600
         TabIndex        =   180
         Top             =   3480
         Width           =   3375
      End
      Begin VB.Label ListaMarePR 
         Caption         =   "11 nimic"
         Height          =   255
         Index           =   10
         Left            =   -69600
         TabIndex        =   179
         Top             =   3240
         Width           =   3375
      End
      Begin VB.Label ListaMarePR 
         Caption         =   "10 nimic"
         Height          =   255
         Index           =   9
         Left            =   -69600
         TabIndex        =   178
         Top             =   3000
         Width           =   3375
      End
      Begin VB.Label ListaMarePR 
         Caption         =   "9 nimic"
         Height          =   255
         Index           =   8
         Left            =   -69600
         TabIndex        =   177
         Top             =   2760
         Width           =   3375
      End
      Begin VB.Label ListaMarePR 
         Caption         =   "8 nimic"
         Height          =   255
         Index           =   7
         Left            =   -69600
         TabIndex        =   176
         Top             =   2520
         Width           =   3375
      End
      Begin VB.Label ListaMarePR 
         Caption         =   "7 nimic"
         Height          =   255
         Index           =   6
         Left            =   -69600
         TabIndex        =   175
         Top             =   2280
         Width           =   3375
      End
      Begin VB.Label ListaMarePR 
         Caption         =   "6 nimic"
         Height          =   255
         Index           =   5
         Left            =   -69600
         TabIndex        =   174
         Top             =   2040
         Width           =   3375
      End
      Begin VB.Label ListaMarePR 
         Caption         =   "5 nimic"
         Height          =   255
         Index           =   4
         Left            =   -69600
         TabIndex        =   173
         Top             =   1800
         Width           =   3375
      End
      Begin VB.Label ListaMarePR 
         Caption         =   "4 nimic"
         Height          =   255
         Index           =   3
         Left            =   -69600
         TabIndex        =   172
         Top             =   1560
         Width           =   3375
      End
      Begin VB.Label ListaMarePR 
         Caption         =   "3 nimic"
         Height          =   255
         Index           =   2
         Left            =   -69600
         TabIndex        =   171
         Top             =   1320
         Width           =   3375
      End
      Begin VB.Label ListaMarePR 
         Caption         =   "2 nimic"
         Height          =   255
         Index           =   1
         Left            =   -69600
         TabIndex        =   170
         Top             =   1080
         Width           =   3375
      End
      Begin VB.Label ListaMarePR 
         Caption         =   "1 nimic"
         Height          =   255
         Index           =   0
         Left            =   -69600
         TabIndex        =   169
         Top             =   840
         Width           =   3375
      End
      Begin VB.Label Label20 
         Caption         =   "Informatii ce se vor citi la apasarea butonului ""Citeste-ma"""
         Height          =   255
         Left            =   -74640
         TabIndex        =   168
         Top             =   3480
         Width           =   4215
      End
      Begin VB.Label Label19 
         Caption         =   "Expicatii despre programul prezentat"
         Height          =   255
         Left            =   -74640
         TabIndex        =   167
         Top             =   1200
         Width           =   2775
      End
      Begin VB.Label Label18 
         Caption         =   "Titlul programului prezentat:"
         Height          =   255
         Left            =   -74640
         TabIndex        =   166
         Top             =   720
         Width           =   2055
      End
      Begin VB.Label Label17 
         Alignment       =   2  'Center
         Caption         =   "Programele introduse deja."
         Height          =   255
         Left            =   -69360
         TabIndex        =   165
         Top             =   480
         Width           =   3015
      End
      Begin VB.Line Line5 
         BorderColor     =   &H00000000&
         X1              =   -69840
         X2              =   -69840
         Y1              =   600
         Y2              =   5280
      End
      Begin VB.Label ListaMareAV 
         Caption         =   "18 nimic"
         Height          =   255
         Index           =   17
         Left            =   -69600
         TabIndex        =   164
         Top             =   4920
         Width           =   3375
      End
      Begin VB.Label ListaMareAV 
         Caption         =   "17 nimic"
         Height          =   255
         Index           =   16
         Left            =   -69600
         TabIndex        =   163
         Top             =   4680
         Width           =   3375
      End
      Begin VB.Label ListaMareAV 
         Caption         =   "16 nimic"
         Height          =   255
         Index           =   15
         Left            =   -69600
         TabIndex        =   162
         Top             =   4440
         Width           =   3375
      End
      Begin VB.Label ListaMareAV 
         Caption         =   "15 nimic"
         Height          =   255
         Index           =   14
         Left            =   -69600
         TabIndex        =   161
         Top             =   4200
         Width           =   3375
      End
      Begin VB.Label ListaMareAV 
         Caption         =   "14 nimic"
         Height          =   255
         Index           =   13
         Left            =   -69600
         TabIndex        =   160
         Top             =   3960
         Width           =   3375
      End
      Begin VB.Label ListaMareAV 
         Caption         =   "13 nimic"
         Height          =   255
         Index           =   12
         Left            =   -69600
         TabIndex        =   159
         Top             =   3720
         Width           =   3375
      End
      Begin VB.Label ListaMareAV 
         Caption         =   "12 nimic"
         Height          =   255
         Index           =   11
         Left            =   -69600
         TabIndex        =   158
         Top             =   3480
         Width           =   3375
      End
      Begin VB.Label ListaMareAV 
         Caption         =   "11 nimic"
         Height          =   255
         Index           =   10
         Left            =   -69600
         TabIndex        =   157
         Top             =   3240
         Width           =   3375
      End
      Begin VB.Label ListaMareAV 
         Caption         =   "10 nimic"
         Height          =   255
         Index           =   9
         Left            =   -69600
         TabIndex        =   156
         Top             =   3000
         Width           =   3375
      End
      Begin VB.Label ListaMareAV 
         Caption         =   "9 nimic"
         Height          =   255
         Index           =   8
         Left            =   -69600
         TabIndex        =   155
         Top             =   2760
         Width           =   3375
      End
      Begin VB.Label ListaMareAV 
         Caption         =   "8 nimic"
         Height          =   255
         Index           =   7
         Left            =   -69600
         TabIndex        =   154
         Top             =   2520
         Width           =   3375
      End
      Begin VB.Label ListaMareAV 
         Caption         =   "7 nimic"
         Height          =   255
         Index           =   6
         Left            =   -69600
         TabIndex        =   153
         Top             =   2280
         Width           =   3375
      End
      Begin VB.Label ListaMareAV 
         Caption         =   "6 nimic"
         Height          =   255
         Index           =   5
         Left            =   -69600
         TabIndex        =   152
         Top             =   2040
         Width           =   3375
      End
      Begin VB.Label ListaMareAV 
         Caption         =   "5 nimic"
         Height          =   255
         Index           =   4
         Left            =   -69600
         TabIndex        =   151
         Top             =   1800
         Width           =   3375
      End
      Begin VB.Label ListaMareAV 
         Caption         =   "4 nimic"
         Height          =   255
         Index           =   3
         Left            =   -69600
         TabIndex        =   150
         Top             =   1560
         Width           =   3375
      End
      Begin VB.Label ListaMareAV 
         Caption         =   "3 nimic"
         Height          =   255
         Index           =   2
         Left            =   -69600
         TabIndex        =   149
         Top             =   1320
         Width           =   3375
      End
      Begin VB.Label ListaMareAV 
         Caption         =   "2 nimic"
         Height          =   255
         Index           =   1
         Left            =   -69600
         TabIndex        =   148
         Top             =   1080
         Width           =   3375
      End
      Begin VB.Label ListaMareAV 
         Caption         =   "1 nimic"
         Height          =   255
         Index           =   0
         Left            =   -69600
         TabIndex        =   147
         Top             =   840
         Width           =   3375
      End
      Begin VB.Label Label16 
         Caption         =   "Informatii ce se vor citi la apasarea butonului ""Citeste-ma"""
         Height          =   255
         Left            =   -74640
         TabIndex        =   146
         Top             =   3480
         Width           =   4215
      End
      Begin VB.Label Label15 
         Caption         =   "Expicatii despre programul prezentat"
         Height          =   255
         Left            =   -74640
         TabIndex        =   145
         Top             =   1200
         Width           =   2775
      End
      Begin VB.Label Label14 
         Caption         =   "Titlul programului prezentat:"
         Height          =   255
         Left            =   -74640
         TabIndex        =   144
         Top             =   720
         Width           =   2055
      End
      Begin VB.Label Label13 
         Alignment       =   2  'Center
         Caption         =   "Programele introduse deja."
         Height          =   255
         Left            =   -69360
         TabIndex        =   143
         Top             =   480
         Width           =   3015
      End
      Begin VB.Line Line4 
         BorderColor     =   &H00000000&
         X1              =   -69840
         X2              =   -69840
         Y1              =   600
         Y2              =   5280
      End
      Begin VB.Label ListaMareIN 
         Caption         =   "18 nimic"
         Height          =   255
         Index           =   17
         Left            =   -69600
         TabIndex        =   142
         Top             =   4920
         Width           =   3375
      End
      Begin VB.Label ListaMareIN 
         Caption         =   "17 nimic"
         Height          =   255
         Index           =   16
         Left            =   -69600
         TabIndex        =   141
         Top             =   4680
         Width           =   3375
      End
      Begin VB.Label ListaMareIN 
         Caption         =   "16 nimic"
         Height          =   255
         Index           =   15
         Left            =   -69600
         TabIndex        =   140
         Top             =   4440
         Width           =   3375
      End
      Begin VB.Label ListaMareIN 
         Caption         =   "15 nimic"
         Height          =   255
         Index           =   14
         Left            =   -69600
         TabIndex        =   139
         Top             =   4200
         Width           =   3375
      End
      Begin VB.Label ListaMareIN 
         Caption         =   "14 nimic"
         Height          =   255
         Index           =   13
         Left            =   -69600
         TabIndex        =   138
         Top             =   3960
         Width           =   3375
      End
      Begin VB.Label ListaMareIN 
         Caption         =   "13 nimic"
         Height          =   255
         Index           =   12
         Left            =   -69600
         TabIndex        =   137
         Top             =   3720
         Width           =   3375
      End
      Begin VB.Label ListaMareIN 
         Caption         =   "12 nimic"
         Height          =   255
         Index           =   11
         Left            =   -69600
         TabIndex        =   136
         Top             =   3480
         Width           =   3375
      End
      Begin VB.Label ListaMareIN 
         Caption         =   "11 nimic"
         Height          =   255
         Index           =   10
         Left            =   -69600
         TabIndex        =   135
         Top             =   3240
         Width           =   3375
      End
      Begin VB.Label ListaMareIN 
         Caption         =   "10 nimic"
         Height          =   255
         Index           =   9
         Left            =   -69600
         TabIndex        =   134
         Top             =   3000
         Width           =   3375
      End
      Begin VB.Label ListaMareIN 
         Caption         =   "9 nimic"
         Height          =   255
         Index           =   8
         Left            =   -69600
         TabIndex        =   133
         Top             =   2760
         Width           =   3375
      End
      Begin VB.Label ListaMareIN 
         Caption         =   "8 nimic"
         Height          =   255
         Index           =   7
         Left            =   -69600
         TabIndex        =   132
         Top             =   2520
         Width           =   3375
      End
      Begin VB.Label ListaMareIN 
         Caption         =   "7 nimic"
         Height          =   255
         Index           =   6
         Left            =   -69600
         TabIndex        =   131
         Top             =   2280
         Width           =   3375
      End
      Begin VB.Label ListaMareIN 
         Caption         =   "6 nimic"
         Height          =   255
         Index           =   5
         Left            =   -69600
         TabIndex        =   130
         Top             =   2040
         Width           =   3375
      End
      Begin VB.Label ListaMareIN 
         Caption         =   "5 nimic"
         Height          =   255
         Index           =   4
         Left            =   -69600
         TabIndex        =   129
         Top             =   1800
         Width           =   3375
      End
      Begin VB.Label ListaMareIN 
         Caption         =   "4 nimic"
         Height          =   255
         Index           =   3
         Left            =   -69600
         TabIndex        =   128
         Top             =   1560
         Width           =   3375
      End
      Begin VB.Label ListaMareIN 
         Caption         =   "3 nimic"
         Height          =   255
         Index           =   2
         Left            =   -69600
         TabIndex        =   127
         Top             =   1320
         Width           =   3375
      End
      Begin VB.Label ListaMareIN 
         Caption         =   "2 nimic"
         Height          =   255
         Index           =   1
         Left            =   -69600
         TabIndex        =   126
         Top             =   1080
         Width           =   3375
      End
      Begin VB.Label ListaMareIN 
         Caption         =   "1 nimic"
         Height          =   255
         Index           =   0
         Left            =   -69600
         TabIndex        =   125
         Top             =   840
         Width           =   3375
      End
      Begin VB.Label Label12 
         Caption         =   "Informatii ce se vor citi la apasarea butonului ""Citeste-ma"""
         Height          =   255
         Left            =   -74640
         TabIndex        =   124
         Top             =   3480
         Width           =   4215
      End
      Begin VB.Label Label11 
         Caption         =   "Expicatii despre programul prezentat"
         Height          =   255
         Left            =   -74640
         TabIndex        =   123
         Top             =   1200
         Width           =   2775
      End
      Begin VB.Label Label10 
         Caption         =   "Titlul programului prezentat:"
         Height          =   255
         Left            =   -74640
         TabIndex        =   122
         Top             =   720
         Width           =   2055
      End
      Begin VB.Label Label9 
         Alignment       =   2  'Center
         Caption         =   "Programele introduse deja."
         Height          =   255
         Left            =   -69360
         TabIndex        =   121
         Top             =   480
         Width           =   3015
      End
      Begin VB.Line Line3 
         BorderColor     =   &H00000000&
         X1              =   -69840
         X2              =   -69840
         Y1              =   600
         Y2              =   5280
      End
      Begin VB.Label ListaMareJC 
         Caption         =   "18 nimic"
         Height          =   255
         Index           =   17
         Left            =   -69600
         TabIndex        =   120
         Top             =   4920
         Width           =   3375
      End
      Begin VB.Label ListaMareJC 
         Caption         =   "17 nimic"
         Height          =   255
         Index           =   16
         Left            =   -69600
         TabIndex        =   119
         Top             =   4680
         Width           =   3375
      End
      Begin VB.Label ListaMareJC 
         Caption         =   "16 nimic"
         Height          =   255
         Index           =   15
         Left            =   -69600
         TabIndex        =   118
         Top             =   4440
         Width           =   3375
      End
      Begin VB.Label ListaMareJC 
         Caption         =   "15 nimic"
         Height          =   255
         Index           =   14
         Left            =   -69600
         TabIndex        =   117
         Top             =   4200
         Width           =   3375
      End
      Begin VB.Label ListaMareJC 
         Caption         =   "14 nimic"
         Height          =   255
         Index           =   13
         Left            =   -69600
         TabIndex        =   116
         Top             =   3960
         Width           =   3375
      End
      Begin VB.Label ListaMareJC 
         Caption         =   "13 nimic"
         Height          =   255
         Index           =   12
         Left            =   -69600
         TabIndex        =   115
         Top             =   3720
         Width           =   3375
      End
      Begin VB.Label ListaMareJC 
         Caption         =   "12 nimic"
         Height          =   255
         Index           =   11
         Left            =   -69600
         TabIndex        =   114
         Top             =   3480
         Width           =   3375
      End
      Begin VB.Label ListaMareJC 
         Caption         =   "11 nimic"
         Height          =   255
         Index           =   10
         Left            =   -69600
         TabIndex        =   113
         Top             =   3240
         Width           =   3375
      End
      Begin VB.Label ListaMareJC 
         Caption         =   "10 nimic"
         Height          =   255
         Index           =   9
         Left            =   -69600
         TabIndex        =   112
         Top             =   3000
         Width           =   3375
      End
      Begin VB.Label ListaMareJC 
         Caption         =   "9 nimic"
         Height          =   255
         Index           =   8
         Left            =   -69600
         TabIndex        =   111
         Top             =   2760
         Width           =   3375
      End
      Begin VB.Label ListaMareJC 
         Caption         =   "8 nimic"
         Height          =   255
         Index           =   7
         Left            =   -69600
         TabIndex        =   110
         Top             =   2520
         Width           =   3375
      End
      Begin VB.Label ListaMareJC 
         Caption         =   "7 nimic"
         Height          =   255
         Index           =   6
         Left            =   -69600
         TabIndex        =   109
         Top             =   2280
         Width           =   3375
      End
      Begin VB.Label ListaMareJC 
         Caption         =   "6 nimic"
         Height          =   255
         Index           =   5
         Left            =   -69600
         TabIndex        =   108
         Top             =   2040
         Width           =   3375
      End
      Begin VB.Label ListaMareJC 
         Caption         =   "5 nimic"
         Height          =   255
         Index           =   4
         Left            =   -69600
         TabIndex        =   107
         Top             =   1800
         Width           =   3375
      End
      Begin VB.Label ListaMareJC 
         Caption         =   "4 nimic"
         Height          =   255
         Index           =   3
         Left            =   -69600
         TabIndex        =   106
         Top             =   1560
         Width           =   3375
      End
      Begin VB.Label ListaMareJC 
         Caption         =   "3 nimic"
         Height          =   255
         Index           =   2
         Left            =   -69600
         TabIndex        =   105
         Top             =   1320
         Width           =   3375
      End
      Begin VB.Label ListaMareJC 
         Caption         =   "2 nimic"
         Height          =   255
         Index           =   1
         Left            =   -69600
         TabIndex        =   104
         Top             =   1080
         Width           =   3375
      End
      Begin VB.Label ListaMareJC 
         Caption         =   "1 nimic"
         Height          =   255
         Index           =   0
         Left            =   -69600
         TabIndex        =   103
         Top             =   840
         Width           =   3375
      End
      Begin VB.Label ListaMareMM 
         Caption         =   "1 nimic"
         Height          =   255
         Index           =   0
         Left            =   -69600
         TabIndex        =   102
         Top             =   840
         Width           =   3375
      End
      Begin VB.Label ListaMareMM 
         Caption         =   "2 nimic"
         Height          =   255
         Index           =   1
         Left            =   -69600
         TabIndex        =   101
         Top             =   1080
         Width           =   3375
      End
      Begin VB.Label ListaMareMM 
         Caption         =   "3 nimic"
         Height          =   255
         Index           =   2
         Left            =   -69600
         TabIndex        =   100
         Top             =   1320
         Width           =   3375
      End
      Begin VB.Label ListaMareMM 
         Caption         =   "4 nimic"
         Height          =   255
         Index           =   3
         Left            =   -69600
         TabIndex        =   99
         Top             =   1560
         Width           =   3375
      End
      Begin VB.Label ListaMareMM 
         Caption         =   "5 nimic"
         Height          =   255
         Index           =   4
         Left            =   -69600
         TabIndex        =   98
         Top             =   1800
         Width           =   3375
      End
      Begin VB.Label ListaMareMM 
         Caption         =   "6 nimic"
         Height          =   255
         Index           =   5
         Left            =   -69600
         TabIndex        =   97
         Top             =   2040
         Width           =   3375
      End
      Begin VB.Label ListaMareMM 
         Caption         =   "7 nimic"
         Height          =   255
         Index           =   6
         Left            =   -69600
         TabIndex        =   96
         Top             =   2280
         Width           =   3375
      End
      Begin VB.Label ListaMareMM 
         Caption         =   "8 nimic"
         Height          =   255
         Index           =   7
         Left            =   -69600
         TabIndex        =   95
         Top             =   2520
         Width           =   3375
      End
      Begin VB.Label ListaMareMM 
         Caption         =   "9 nimic"
         Height          =   255
         Index           =   8
         Left            =   -69600
         TabIndex        =   94
         Top             =   2760
         Width           =   3375
      End
      Begin VB.Label ListaMareMM 
         Caption         =   "10 nimic"
         Height          =   255
         Index           =   9
         Left            =   -69600
         TabIndex        =   93
         Top             =   3000
         Width           =   3375
      End
      Begin VB.Label ListaMareMM 
         Caption         =   "11 nimic"
         Height          =   255
         Index           =   10
         Left            =   -69600
         TabIndex        =   92
         Top             =   3240
         Width           =   3375
      End
      Begin VB.Label ListaMareMM 
         Caption         =   "12 nimic"
         Height          =   255
         Index           =   11
         Left            =   -69600
         TabIndex        =   91
         Top             =   3480
         Width           =   3375
      End
      Begin VB.Label ListaMareMM 
         Caption         =   "13 nimic"
         Height          =   255
         Index           =   12
         Left            =   -69600
         TabIndex        =   90
         Top             =   3720
         Width           =   3375
      End
      Begin VB.Label ListaMareMM 
         Caption         =   "14 nimic"
         Height          =   255
         Index           =   13
         Left            =   -69600
         TabIndex        =   89
         Top             =   3960
         Width           =   3375
      End
      Begin VB.Label ListaMareMM 
         Caption         =   "15 nimic"
         Height          =   255
         Index           =   14
         Left            =   -69600
         TabIndex        =   88
         Top             =   4200
         Width           =   3375
      End
      Begin VB.Label ListaMareMM 
         Caption         =   "16 nimic"
         Height          =   255
         Index           =   15
         Left            =   -69600
         TabIndex        =   87
         Top             =   4440
         Width           =   3375
      End
      Begin VB.Label ListaMareMM 
         Caption         =   "17 nimic"
         Height          =   255
         Index           =   16
         Left            =   -69600
         TabIndex        =   86
         Top             =   4680
         Width           =   3375
      End
      Begin VB.Label ListaMareMM 
         Caption         =   "18 nimic"
         Height          =   255
         Index           =   17
         Left            =   -69600
         TabIndex        =   85
         Top             =   4920
         Width           =   3375
      End
      Begin VB.Line Line2 
         BorderColor     =   &H00000000&
         X1              =   -69840
         X2              =   -69840
         Y1              =   600
         Y2              =   5280
      End
      Begin VB.Label Label8 
         Alignment       =   2  'Center
         Caption         =   "Programele introduse deja."
         Height          =   255
         Left            =   -69360
         TabIndex        =   84
         Top             =   480
         Width           =   3015
      End
      Begin VB.Label Label7 
         Caption         =   "Titlul programului prezentat:"
         Height          =   255
         Left            =   -74640
         TabIndex        =   83
         Top             =   720
         Width           =   2055
      End
      Begin VB.Label Label6 
         Caption         =   "Expicatii despre programul prezentat"
         Height          =   255
         Left            =   -74640
         TabIndex        =   82
         Top             =   1200
         Width           =   2775
      End
      Begin VB.Label Label5 
         Caption         =   "Informatii ce se vor citi la apasarea butonului ""Citeste-ma"""
         Height          =   255
         Left            =   -74640
         TabIndex        =   81
         Top             =   3480
         Width           =   4215
      End
      Begin VB.Label Label4 
         Alignment       =   2  'Center
         Caption         =   "Programele introduse deja."
         Height          =   255
         Left            =   5640
         TabIndex        =   80
         Top             =   480
         Width           =   3015
      End
      Begin VB.Line Line1 
         BorderColor     =   &H00000000&
         Index           =   0
         X1              =   5160
         X2              =   5160
         Y1              =   480
         Y2              =   5280
      End
      Begin VB.Label Label3 
         Caption         =   "Informatii ce se vor citi la apasarea butonului ""Citeste-ma"":"
         Height          =   255
         Left            =   360
         TabIndex        =   79
         Top             =   3480
         Width           =   4215
      End
      Begin VB.Label ListaMare 
         Caption         =   "18 nimic"
         Height          =   255
         Index           =   17
         Left            =   5400
         TabIndex        =   78
         Top             =   4920
         Width           =   3375
      End
      Begin VB.Label ListaMare 
         Caption         =   "17 nimic"
         Height          =   255
         Index           =   16
         Left            =   5400
         TabIndex        =   77
         Top             =   4680
         Width           =   3375
      End
      Begin VB.Label ListaMare 
         Caption         =   "16 nimic"
         Height          =   255
         Index           =   15
         Left            =   5400
         TabIndex        =   76
         Top             =   4440
         Width           =   3375
      End
      Begin VB.Label ListaMare 
         Caption         =   "15 nimic"
         Height          =   255
         Index           =   14
         Left            =   5400
         TabIndex        =   75
         Top             =   4200
         Width           =   3375
      End
      Begin VB.Label ListaMare 
         Caption         =   "14 nimic"
         Height          =   255
         Index           =   13
         Left            =   5400
         TabIndex        =   74
         Top             =   3960
         Width           =   3375
      End
      Begin VB.Label ListaMare 
         Caption         =   "13 nimic"
         Height          =   255
         Index           =   12
         Left            =   5400
         TabIndex        =   73
         Top             =   3720
         Width           =   3375
      End
      Begin VB.Label ListaMare 
         Caption         =   "12 nimic"
         Height          =   255
         Index           =   11
         Left            =   5400
         TabIndex        =   72
         Top             =   3480
         Width           =   3375
      End
      Begin VB.Label ListaMare 
         Caption         =   "11 nimic"
         Height          =   255
         Index           =   10
         Left            =   5400
         TabIndex        =   71
         Top             =   3240
         Width           =   3375
      End
      Begin VB.Label ListaMare 
         Caption         =   "10 nimic"
         Height          =   255
         Index           =   9
         Left            =   5400
         TabIndex        =   70
         Top             =   3000
         Width           =   3375
      End
      Begin VB.Label ListaMare 
         Caption         =   "9 nimic"
         Height          =   255
         Index           =   8
         Left            =   5400
         TabIndex        =   69
         Top             =   2760
         Width           =   3375
      End
      Begin VB.Label ListaMare 
         Caption         =   "8 nimic"
         Height          =   255
         Index           =   7
         Left            =   5400
         TabIndex        =   68
         Top             =   2520
         Width           =   3375
      End
      Begin VB.Label ListaMare 
         Caption         =   "7 nimic"
         Height          =   255
         Index           =   6
         Left            =   5400
         TabIndex        =   67
         Top             =   2280
         Width           =   3375
      End
      Begin VB.Label ListaMare 
         Caption         =   "6 nimic"
         Height          =   255
         Index           =   5
         Left            =   5400
         TabIndex        =   66
         Top             =   2040
         Width           =   3375
      End
      Begin VB.Label ListaMare 
         Caption         =   "5 nimic"
         Height          =   255
         Index           =   4
         Left            =   5400
         TabIndex        =   65
         Top             =   1800
         Width           =   3375
      End
      Begin VB.Label ListaMare 
         Caption         =   "4 nimic"
         Height          =   255
         Index           =   3
         Left            =   5400
         TabIndex        =   64
         Top             =   1560
         Width           =   3375
      End
      Begin VB.Label ListaMare 
         Caption         =   "3 nimic"
         Height          =   255
         Index           =   2
         Left            =   5400
         TabIndex        =   63
         Top             =   1320
         Width           =   3375
      End
      Begin VB.Label ListaMare 
         Caption         =   "2 nimic"
         Height          =   255
         Index           =   1
         Left            =   5400
         TabIndex        =   62
         Top             =   1080
         Width           =   3375
      End
      Begin VB.Label ListaMare 
         Caption         =   "1 nimic"
         Height          =   255
         Index           =   0
         Left            =   5400
         TabIndex        =   61
         Top             =   840
         Width           =   3375
      End
      Begin VB.Label Label2 
         Caption         =   "Expicatii despre programul prezentat:"
         Height          =   255
         Left            =   360
         TabIndex        =   60
         Top             =   1200
         Width           =   2775
      End
      Begin VB.Label Label1 
         Caption         =   "Titlul programului prezentat:"
         Height          =   255
         Left            =   360
         TabIndex        =   59
         Top             =   720
         Width           =   2055
      End
      Begin VB.Line Line1 
         BorderColor     =   &H00000000&
         Index           =   2
         X1              =   -69720
         X2              =   -62760
         Y1              =   5400
         Y2              =   5400
      End
      Begin VB.Shape BorduraTemp 
         BackColor       =   &H000000FF&
         BorderColor     =   &H00000000&
         Height          =   2895
         Index           =   0
         Left            =   9000
         Top             =   5640
         Width           =   3255
      End
      Begin VB.Shape BorduraTemp 
         BackColor       =   &H000000FF&
         BorderColor     =   &H00000000&
         Height          =   2895
         Index           =   1
         Left            =   -66000
         Top             =   5640
         Width           =   3255
      End
      Begin VB.Line Line8 
         BorderColor     =   &H00000000&
         Index           =   0
         X1              =   3480
         X2              =   8880
         Y1              =   6000
         Y2              =   6000
      End
      Begin VB.Line Line9 
         BorderColor     =   &H00000000&
         Index           =   0
         X1              =   8640
         X2              =   8880
         Y1              =   5880
         Y2              =   6000
      End
      Begin VB.Line Line10 
         BorderColor     =   &H00000000&
         Index           =   0
         X1              =   8640
         X2              =   8880
         Y1              =   6120
         Y2              =   6000
      End
      Begin VB.Line Line8 
         BorderColor     =   &H00000000&
         Index           =   1
         X1              =   -71160
         X2              =   -66120
         Y1              =   6000
         Y2              =   6000
      End
      Begin VB.Line Line9 
         BorderColor     =   &H00000000&
         Index           =   1
         X1              =   -66360
         X2              =   -66120
         Y1              =   5880
         Y2              =   6000
      End
      Begin VB.Line Line10 
         BorderColor     =   &H00000000&
         Index           =   3
         X1              =   -66360
         X2              =   -66120
         Y1              =   6120
         Y2              =   6000
      End
      Begin VB.Line Line8 
         BorderColor     =   &H00000000&
         Index           =   2
         X1              =   -70200
         X2              =   -66120
         Y1              =   6000
         Y2              =   6000
      End
      Begin VB.Line Line9 
         BorderColor     =   &H00000000&
         Index           =   2
         X1              =   -66360
         X2              =   -66120
         Y1              =   5880
         Y2              =   6000
      End
      Begin VB.Line Line10 
         BorderColor     =   &H00000000&
         Index           =   1
         X1              =   -66360
         X2              =   -66120
         Y1              =   6120
         Y2              =   6000
      End
      Begin VB.Line Line8 
         BorderColor     =   &H00000000&
         Index           =   3
         X1              =   -69480
         X2              =   -66120
         Y1              =   6000
         Y2              =   6000
      End
      Begin VB.Line Line9 
         BorderColor     =   &H00000000&
         Index           =   3
         X1              =   -66360
         X2              =   -66120
         Y1              =   5880
         Y2              =   6000
      End
      Begin VB.Line Line10 
         BorderColor     =   &H00000000&
         Index           =   2
         X1              =   -66360
         X2              =   -66120
         Y1              =   6120
         Y2              =   6000
      End
      Begin VB.Line Line8 
         BorderColor     =   &H00000000&
         Index           =   4
         X1              =   -69000
         X2              =   -66120
         Y1              =   6000
         Y2              =   6000
      End
      Begin VB.Line Line9 
         BorderColor     =   &H00000000&
         Index           =   4
         X1              =   -66360
         X2              =   -66120
         Y1              =   5880
         Y2              =   6000
      End
      Begin VB.Line Line10 
         BorderColor     =   &H00000000&
         Index           =   4
         X1              =   -66360
         X2              =   -66120
         Y1              =   6120
         Y2              =   6000
      End
      Begin VB.Line Line8 
         BorderColor     =   &H00000000&
         Index           =   5
         X1              =   -68160
         X2              =   -66120
         Y1              =   6000
         Y2              =   6000
      End
      Begin VB.Line Line9 
         BorderColor     =   &H00000000&
         Index           =   5
         X1              =   -66360
         X2              =   -66120
         Y1              =   5880
         Y2              =   6000
      End
      Begin VB.Line Line10 
         BorderColor     =   &H00000000&
         Index           =   5
         X1              =   -66360
         X2              =   -66120
         Y1              =   6120
         Y2              =   6000
      End
      Begin VB.Label Label28 
         Alignment       =   2  'Center
         Caption         =   "Utilitare"
         BeginProperty Font 
            Name            =   "MS Serif"
            Size            =   24
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   615
         Index           =   0
         Left            =   9120
         TabIndex        =   58
         Top             =   3960
         Width           =   3015
      End
   End
   Begin GenerareMatrita.Buton_3D_General Creaza_in_Dir 
      Height          =   495
      Left            =   5280
      TabIndex        =   389
      Top             =   9480
      Width           =   1815
      _ExtentX        =   3201
      _ExtentY        =   873
      Caption         =   "Compileaza in ..."
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Times New Roman"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin VB.Image Image1 
      Height          =   720
      Left            =   0
      Picture         =   "Form1.frx":81B2
      Top             =   9360
      Width           =   720
   End
   Begin VB.Line Line27 
      BorderColor     =   &H00000000&
      X1              =   312
      X2              =   312
      Y1              =   0
      Y2              =   64
   End
End
Attribute VB_Name = "Geneza"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private sat(0 To 5) As String

Private Sub Arhiva_Click()
On Error GoTo aa
Salvare_matrita.Filename = ""
Salvare_matrita.Filter = "Fisiere xls (*.xls)|*.xls"
Salvare_matrita.ShowOpen
Ar_text.Text = Salvare_matrita.Filename
aa:
End Sub

Private Sub cale2_GotFocus(Index As Integer)
cale2(Index).BackColor = &H0&
End Sub

Private Sub calea_GotFocus(Index As Integer)
calea(Index).BackColor = &H0&
End Sub

Private Sub Captura_Mare666_Click()
CapturaEU.Show
End Sub

Private Sub Capturare_Click()
DespreYO.Show
End Sub

Private Sub Citeste_Text_GotFocus(Index As Integer)
Citeste_Text(Index).BackColor = &H0&
End Sub

Private Sub Command1_Click()
ccc = Crypt("gggggggggggggggg", "Paul")
MsgBox ccc
ccc = Crypt(ccc, "Paul")
MsgBox ccc
End Sub

Private Sub Creaza_in_Dir_Click()
'On Error GoTo aa
'Salvare_matrita.Filter = "Fisiere zip (*.zip)|*.zip"
'Salvare_matrita.ShowOpen
'Cale_matrita.Text = Salvare_matrita.FileName
'aa:
Dim sRet As String

mBFF.InitFolder = "c:\"
sRet = mBFF.BrowseForFolder(Me.hwnd, "Selecteaza directorul in care va fi creata matrita ...")

If (sRet <> vbNullString) Then
Cale_matrita.Text = sRet
End If
End Sub

Private Sub D_Alege_Click()
On Error GoTo aa
Deschide_Driver_fundal.Filename = ""
Deschide_Driver_fundal.Filter = "Fisiere jpg (*.jpg)|*.jpg"
Deschide_Driver_fundal.ShowOpen
D_Cale_text.Text = Deschide_Driver_fundal.Filename
aa:
End Sub

Private Sub Deschide_Fisier_Click()
On Error GoTo aa
Salveaza_Deschide.Filename = ""
Salveaza_Deschide.Filter = "Fisiere alfa (*.alfa)|*.alfa"
Salveaza_Deschide.ShowOpen
sss = Salveaza_Deschide.Filename
aa:
End Sub

Private Sub Dezactivari_Click()
Buton_interfata.Show
End Sub

Private Sub DrivereCale_Click(Index As Integer)
On Error GoTo aa
DeschideDriver.Filter = "Fisiere exe (*.exe)|*.exe"
DeschideDriver.ShowOpen
DrivereCale(Index).Text = DeschideDriver.Filename
numeDriver(Index) = DeschideDriver.FileTitle
aa:

End Sub

Private Sub DrivereCale_GotFocus(Index As Integer)
DrivereCale(Index).BackColor = &H0&
End Sub

Private Sub DrivereExplicatii_GotFocus(Index As Integer)
DrivereExplicatii(Index).BackColor = &H0&
End Sub

Private Sub DrivereTitlu_GotFocus(Index As Integer)
DrivereTitlu(Index).BackColor = &H0&
End Sub

Private Sub Explicatie_GotFocus(Index As Integer)
Explicatie(Index).BackColor = &H0&
End Sub

Private Sub Form_Load()

sat(0) = "UTILITARE"
sat(1) = "MULTIMEDIA"
sat(2) = "JOCURI"
sat(3) = "INTERNET"
sat(4) = "ANTIVIRUS"
sat(5) = "PERMANENTE"

Bula_general = "c:\"

On Error Resume Next
MkDir "C:\PC_World"

For nnn = 1 To 18
UT_Variabile_Nume(nnn) = ""
Next nnn

For yo = 0 To 5
Sterge_Click (yo)
Next yo

For tyu = 0 To 18
Activat(tyu) = True
Next tyu

StergeDriver_Click

CaleFundalIntro.Text = App.Path & "\Geneza\IMG\fundal_reclama.gif"
CaleAjutor.Text = App.Path & "\Geneza\IMG\fundal-c.gif"
D_Cale_text.Text = App.Path & "\Geneza\IMG\fundal7.jpg"
End Sub

Private Sub Form_Unload(Cancel As Integer)
'Unload CapturaEU
Unload PreFormular
Unload PreVedere
Unload Buton_interfata
Unload Captura
Unload Me
End
End Sub

Private Sub FundalAjutor_Click()
On Error GoTo aa
DeschideAjutor.Filename = ""
DeschideAjutor.Filter = "Fisiere gif (*.gif)|*.gif"
DeschideAjutor.ShowOpen
CaleAjutor.Text = DeschideAjutor.Filename
aa:
End Sub

Private Sub FundalIntro_Click()
On Error GoTo aa
FundalReclama.Filename = ""
FundalReclama.Filter = "Fisiere gif (*.gif)|*.gif"
FundalReclama.ShowOpen
CaleFundalIntro.Text = FundalReclama.Filename
aa:

End Sub

Private Sub Grafica_Click()
'Modificare_Grafica.Show
End Sub

Private Sub Imagine_Mare_Click(Index As Integer)
On Error GoTo aa

I_Mare_deschide.Filename = ""
I_Mare_deschide.Filter = "Fisiere gif (*.gif)|*.gif"
I_Mare_deschide.ShowOpen

IMare(Index).Text = I_Mare_deschide.Filename
'Pro_imagine(Index).LoadFromFile (IMica(Index).Text)
IMare(Index).BackColor = &H0&
aa:

End Sub

Private Sub ImagineM_Click(Index As Integer)
On Error GoTo aa

I_mica_deschide.Filename = ""
I_mica_deschide.Filter = "Fisiere gif (*.gif)|*.gif"
I_mica_deschide.ShowOpen

IMica(Index).Text = I_mica_deschide.Filename
Pro_imagine(Index).LoadFromFile (IMica(Index).Text)
IMica(Index).BackColor = &H0&
aa:

End Sub

Private Sub IMare_GotFocus(Index As Integer)
IMare(Index).BackColor = &H0&
End Sub

Private Sub IMica_GotFocus(Index As Integer)
IMica(Index).BackColor = &H0&
End Sub

Private Sub IN_Lista_Click(Index As Integer)
'**********************************************************

If Titlu(Index).Text = "" Then
MsgBox "Programul prezentat trebuie sa aiba un nume. Te rog completeaza casuta: TITLUL PROGRAMULUI PREZENTAT"
Titlu(Index).BackColor = &HFF0000
Exit Sub
End If

If Explicatie(Index).Text = "" Then
MsgBox "Programul prezentat trebuie sa aiba explicatii. Te rog completeaza casuta:" & UCase("Expicatii despre programul prezentat")
Explicatie(Index).BackColor = &HFF0000
Exit Sub
End If

If Citeste_Text(Index).Text = "" Then
MsgBox "Te rog sa introduci in casuta " & UCase("Informatii ce se vor citi la apasarea butonului Citeste-ma") & " text cu privire la programul prezentat."
Citeste_Text(Index).BackColor = &HFF0000
Exit Sub
End If



If IMare(Index).Text = "" And IMica(Index).Text = "" Then
MsgBox "Trebuie sa-ti alegi doua fisiere gif:" & vbCrLf & "unul care conzine captura mica si altul care contine captura 1:1"
IMare(Index).BackColor = &HFF0000
IMica(Index).BackColor = &HFF0000
Exit Sub
End If

If IMare(Index).Text = "" Then
MsgBox "Trebuie sa alegi fisierul pentru captura 1:1 (captura mare)"
IMare(Index).BackColor = &HFF0000
Exit Sub
End If

If IMica(Index).Text = "" Then
MsgBox "Trebuie sa alegi fisierul pentru captura mica."
IMica(Index).BackColor = &HFF0000
Exit Sub
End If

If calea(Index).Text = "" And cale2(Index).Text = "" Then
MsgBox "In functie de ce dispui trebuie sa-i pui programului la dispozitie calea spre kit-ul de instalare sau spre aplicatia de instalare"
calea(Index).BackColor = &HFF0000
cale2(Index).BackColor = &HFF0000
Exit Sub
End If


For vaca = 0 To 5

If InStr(Titlu(vaca).Text, "]") <> 0 Or InStr(Titlu(vaca).Text, "[") <> 0 Or InStr(Titlu(vaca).Text, Chr(39)) <> 0 Or InStr(Titlu(vaca).Text, Chr(34)) <> 0 Or InStr(Titlu(vaca).Text, "#") <> 0 Or InStr(Titlu(vaca).Text, "|") <> 0 Then
MsgBox "Caracterele: <|><[><]><#><" & Chr(39) & "><" & Chr(34) & "> sunt nepermise. " & vbCrLf & _
"Greseala este in sectiunea - " & sat(vaca) & ", la casuta " & Chr(34) & "Titlul programului prezentat" & Chr(34)
Master_Control.Tab = vaca
Titlu(vaca).BackColor = &HFF0000
Exit Sub
End If

If InStr(Explicatie(vaca).Text, "]") <> 0 Or InStr(Explicatie(vaca).Text, "[") <> 0 Or InStr(Explicatie(vaca).Text, Chr(39)) <> 0 Or InStr(Explicatie(vaca).Text, Chr(34)) <> 0 Or InStr(Explicatie(vaca).Text, "#") <> 0 Or InStr(Explicatie(vaca).Text, "|") <> 0 Then
MsgBox "Caracterele: <|><[><]><#><" & Chr(39) & "><" & Chr(34) & "> sunt nepermise. " & vbCrLf & _
"Greseala este in sectiunea - " & sat(vaca) & ", la casuta " & Chr(34) & "Expicatii despre programul prezentat" & Chr(34)
Explicatie(vaca).BackColor = &HFF0000
Master_Control.Tab = vaca
Exit Sub
End If

Next vaca


If Index = 0 Then
ggg = 0
Do While UT_Variabile_Nume(ggg) <> ""
ggg = ggg + 1
Loop

If ggg >= 18 Then
MsgBox "(Utilitare) Prea multe ! Limita este de 18 programe/sectiune -> (0 la 18) "
Exit Sub
End If

UT_Variabile_Nume(ggg) = ggg & "|" & Titlu(0).Text & "|#"
UT_Variabile_Explicatii(ggg) = vbCrLf & "[" & ggg & "]" & Explicatie(0).Text & "[STOP]"
UT_Citeste_ma(ggg) = Citeste_Text(0).Text

UT_KitZip(ggg) = temp_KitZip(0)
UT_Kit(ggg) = temp_Kit(0)

ListaMare(ggg).Caption = Titlu(0).Text

UT_Img1(ggg) = IMica(Index).Text
UT_Img2(ggg) = IMare(Index).Text
'PreFormular.Giful.LoadFromFile (IMica(Index).Text)

Imagine_Meniu(Index).LoadFromFile (UT_Img1(Index))
End If
'**********************************************************
If Index = 1 Then
ggg = 0
Do While MM_Variabile_Nume(ggg) <> ""
ggg = ggg + 1
Loop

If ggg >= 18 Then
MsgBox "(Multimedia) Prea multe ! Limita este de 18 programe/sectiune -> (0 la 18) "
Exit Sub
End If


MM_Variabile_Nume(ggg) = ggg & "|" & Titlu(1).Text & "|#"
MM_Variabile_Explicatii(ggg) = vbCrLf & "[" & ggg & "]" & Explicatie(1).Text & "[STOP]"
MM_Citeste_ma(ggg) = Citeste_Text(1).Text

MM_KitZip(ggg) = temp_KitZip(1)
MM_Kit(ggg) = temp_Kit(1)

ListaMareMM(ggg).Caption = Titlu(1).Text

MM_Img1(ggg) = IMica(Index).Text
MM_Img2(ggg) = IMare(Index).Text

Imagine_Meniu(Index).LoadFromFile (MM_Img1(Index))
End If
'**********************************************************
If Index = 2 Then
ggg = 0
Do While JC_Variabile_Nume(ggg) <> ""
ggg = ggg + 1
Loop

If ggg >= 18 Then
MsgBox "(Jocuri) Prea multe ! Limita este de 18 programe/sectiune -> (0 la 18) "
Exit Sub
End If


JC_Variabile_Nume(ggg) = ggg & "|" & Titlu(2).Text & "|#"
JC_Variabile_Explicatii(ggg) = vbCrLf & "[" & ggg & "]" & Explicatie(2).Text & "[STOP]"
JC_Citeste_ma(ggg) = Citeste_Text(2).Text

JC_KitZip(ggg) = temp_KitZip(2)
JC_Kit(ggg) = temp_Kit(2)

ListaMareJC(ggg).Caption = Titlu(2).Text

JC_Img1(ggg) = IMica(Index).Text
JC_Img2(ggg) = IMare(Index).Text

Imagine_Meniu(Index).LoadFromFile (JC_Img1(Index))
End If
'**********************************************************
If Index = 3 Then
ggg = 0
Do While IN_Variabile_Nume(ggg) <> ""
ggg = ggg + 1
Loop

If ggg >= 18 Then
MsgBox "(Internet) Prea multe ! Limita este de 18 programe/sectiune -> (0 la 18) "
Exit Sub
End If


IN_Variabile_Nume(ggg) = ggg & "|" & Titlu(3).Text & "|#"
IN_Variabile_Explicatii(ggg) = vbCrLf & "[" & ggg & "]" & Explicatie(3).Text & "[STOP]"
IN_Citeste_ma(ggg) = Citeste_Text(3).Text

IN_KitZip(ggg) = temp_KitZip(3)
IN_Kit(ggg) = temp_Kit(3)

ListaMareIN(ggg).Caption = Titlu(3).Text

IN_Img1(ggg) = IMica(Index).Text
IN_Img2(ggg) = IMare(Index).Text

Imagine_Meniu(Index).LoadFromFile (IN_Img1(Index))
End If
'**********************************************************
If Index = 4 Then
ggg = 0
Do While AV_Variabile_Nume(ggg) <> ""
ggg = ggg + 1
Loop

If ggg >= 18 Then
MsgBox "(Antivirus) Prea multe ! Limita este de 18 programe/sectiune -> (0 la 18) "
Exit Sub
End If


AV_Variabile_Nume(ggg) = ggg & "|" & Titlu(4).Text & "|#"
AV_Variabile_Explicatii(ggg) = vbCrLf & "[" & ggg & "]" & Explicatie(4).Text & "[STOP]"
AV_Citeste_ma(ggg) = Citeste_Text(4).Text

AV_KitZip(ggg) = temp_KitZip(4)
AV_Kit(ggg) = temp_Kit(4)

ListaMareAV(ggg).Caption = Titlu(4).Text

AV_Img1(ggg) = IMica(Index).Text
AV_Img2(ggg) = IMare(Index).Text

Imagine_Meniu(Index).LoadFromFile (AV_Img1(Index))
End If
'**********************************************************
If Index = 5 Then
ggg = 0
Do While PR_Variabile_Nume(ggg) <> ""
ggg = ggg + 1
Loop

If ggg >= 18 Then
MsgBox "(Permanente) Prea multe ! Limita este de 18 programe/sectiune -> (0 la 18) "
Exit Sub
End If


PR_Variabile_Nume(ggg) = ggg & "|" & Titlu(5).Text & "|#"
PR_Variabile_Explicatii(ggg) = vbCrLf & "[" & ggg & "]" & Explicatie(5).Text & "[STOP]"
PR_Citeste_ma(ggg) = Citeste_Text(5).Text

PR_KitZip(ggg) = temp_KitZip(5)
PR_Kit(ggg) = temp_Kit(5)

ListaMarePR(ggg).Caption = Titlu(5).Text

PR_Img1(ggg) = IMica(Index).Text
PR_Img2(ggg) = IMare(Index).Text

Imagine_Meniu(Index).LoadFromFile (PR_Img1(Index))
End If


Titlu(Index).Text = ""
Explicatie(Index).Text = ""
Citeste_Text(Index).Text = ""
IMica(Index).Text = ""
IMare(Index).Text = ""
calea(Index).Text = ""
cale2(Index).Text = ""

End Sub


Private Sub Redimensioneaza_Click()
iWMax = bordura.Width
iHMax = bordura.Height
  w = LungimeQ
  h = InaltimeQ

   zAspect = w / h
   If w <= iWMax Then
      iW = w
      iH = CLng(iW / zAspect)
   Else  ' Picture1.Width > iWMax
      iW = iWMax
      iH = CLng(iWMax / zAspect)
   End If
   If iH > iHMax Then
      iH = iHMax
      iW = CLng(iH * zAspect)
   End If
   
Image1.Width = iW
Image1.Height = iH
Image1.Refresh

Image1.Left = bordura.Left + (bordura.Width / 2) - (Image1.Width / 2)
Image1.Top = bordura.Top + (bordura.Height / 2) - (Image1.Height / 2)

End Sub

Private Sub Inainte_de_Click(Index As Integer)

If Index < 6 Then

If Explicatie(Index).Text = "" Then
MsgBox "Pentru ca sa vezi cum se aranjeaza pe interfata textul cu explicatiile aferente programului prezentat trebuie sa completezi casuta:" & UCase("Expicatii despre programul prezentat")
Explicatie(Index).BackColor = &HFF0000
Exit Sub
End If

If IMica(Index).Text = "" Then
MsgBox "Alege gif-ul (captura mica) pentru ca programul sa poata afisa captura programului prezentat."
IMica(Index).BackColor = &HFF0000
Exit Sub
End If

End If

If Index = 0 Then
PreFormular.InformatiiPrograme.Caption = Explicatie(Index).Text
PreFormular.Giful.LoadFromFile (IMica(Index).Text)
Captura.EcranMare.LoadFromFile (IMare(Index).Text)
PreFormular.Show
End If

If Index = 1 Then
PreFormular.InformatiiPrograme.Caption = Explicatie(Index).Text
PreFormular.Giful.LoadFromFile (IMica(Index).Text)
Captura.EcranMare.LoadFromFile (IMare(Index).Text)
PreFormular.Show
End If

If Index = 2 Then
PreFormular.InformatiiPrograme.Caption = Explicatie(Index).Text
PreFormular.Giful.LoadFromFile (IMica(Index).Text)
Captura.EcranMare.LoadFromFile (IMare(Index).Text)
PreFormular.Show
End If

If Index = 3 Then
PreFormular.InformatiiPrograme.Caption = Explicatie(Index).Text
PreFormular.Giful.LoadFromFile (IMica(Index).Text)
Captura.EcranMare.LoadFromFile (IMare(Index).Text)
PreFormular.Show
End If


If Index = 4 Then
PreFormular.InformatiiPrograme.Caption = Explicatie(Index).Text
PreFormular.Giful.LoadFromFile (IMica(Index).Text)
Captura.EcranMare.LoadFromFile (IMare(Index).Text)
PreFormular.Show
End If


If Index = 5 Then
PreFormular.InformatiiPrograme.Caption = Explicatie(Index).Text
PreFormular.Giful.LoadFromFile (IMica(Index).Text)
Captura.EcranMare.LoadFromFile (IMare(Index).Text)
PreFormular.Show
End If

'revista --------------------------------------------------------------------------------------------
If Index = 6 Then
ff = FreeFile
Open App.Path & "\Geneza\Revista.htm" For Output As #ff
Print #ff, revista1.Text & vbCrLf & Revista & vbCrLf & revista2.Text
Close #ff
PreVedere.Text_Imagine.Navigate (App.Path & "\Geneza\Revista.htm")
PreVedere.Show
End If

If Index = 7 Then '--------------------------------------------------------------------------------------------
If Reclama_luna.Value = 0 Then

If CaleFundalIntro.Text = "" Then
MsgBox "Trebuie sa alegi imaginea de fundal (imaginea pentru reclama)!"
Exit Sub
End If

ff = FreeFile
Open App.Path & "\Geneza\Intrare.htm" For Output As #ff
lalala1 = "<DIV id=cade style=" & Chr(34) & "BACKGROUND-COLOR: #" & culoare.Text & "; HEIGHT:" & Inaltime.Text & _
"px; LEFT: 126px; POSITION: absolute; TOP: 100px; VISIBILITY: hidden;WIDTH:" & latime.Text & "px" & Chr(34) & ">"

lalala2 = "</DIV></tr></td></table>"

lala3 = "<table border=" & Chr(34) & borduraG.Text & Chr(34) & " cellpadding=" & Chr(34) & "0" & _
Chr(34) & " cellspacing=" & Chr(34) & "0" & Chr(34) & " style=" & Chr(34) & _
"border-collapse: collapse" & Chr(34) & " width=" & Chr(34) & "100%" & Chr(34) & _
" height=" & Chr(34) & "100%" & Chr(34) & "><tr><td valign=top align=right " & _
"width=" & Chr(34) & "100%" & Chr(34) & " background=" & Chr(34) & _
CaleFundalIntro.Text & Chr(34) & "height=100%><button onclick=" & Chr(34) & _
"Hai_Pa();return false" & Chr(34) & " style=" & Chr(34) & "height:20;width:20" & Chr(34) & _
"><FONT color=" & Chr(34) & "000000" & Chr(34) & " face=Arial size=1>x</FONT></button>"

proces = Proceseaza(Intro.Text)
Print #ff, Intro1.Text & vbCrLf & proces & vbCrLf & Intro2.Text & lalala1 & lala3 & Intro3.Text & lalala2
Close #ff

Else
'axa text ==============================

If InStr(AxaRotativa.Text, Chr(39)) <> 0 Then
MsgBox "Caracterul [" & Chr(39) & "] este nepermis !!!"
Exit Sub
End If

'sa scot caracterele nepermise "'#"
ff = FreeFile
Open App.Path & "\Geneza\Intrare.htm" For Output As #ff
Print #ff, IntroFaraReclama(0).Text & Proceseaza(Intro.Text) & IntroFaraReclama(1).Text & AxaRotativa.Text & IntroFaraReclama(2).Text
Close #ff
'axa text ==============================

End If

PreVedere.Text_Imagine.Navigate (App.Path & "\Geneza\Intrare.htm")
PreVedere.Show

End If


If Index = 8 Then '--------------------------------------------------------------------------------------------

If CaleAjutor.Text = "" Then
MsgBox "Trebuie sa alegi imaginea de fundal!"
Exit Sub
End If

ff = FreeFile
Open App.Path & "\Geneza\Ajutor.htm" For Output As #ff

xxl = Proceseaza(Ajutor.Text)
xx1 = "<body bgcolor=white background=" & Chr(34) & CaleAjutor.Text & Chr(34) & "><font size=" & Chr(34) & FontMarime.Text & Chr(34) & " face=" & Chr(34) & Fontul.Text & Chr(34) & " color=" & Chr(34) & "#" & FontCuloare.Text & Chr(34) & ">"

Print #ff, Ajutor1.Text & vbCrLf & xx1 & xxl & "</FONT>"
Close #ff
PreVedere.Text_Imagine.Navigate (App.Path & "\Geneza\Ajutor.htm")
PreVedere.Show
End If

If Index = 9 Then ' --------------------------------------------------------------------------------------------

If D_Cale_text.Text = "" Then
MsgBox "Trebuie sa alegi imaginea de fundal(drivere)!"
Exit Sub
End If

For bulaD = 0 To 7
If DrivereTitlu(bulaD).Text <> "" Or DrivereExplicatii(bulaD).Text <> "" Or DrivereCale(bulaD).Text <> "" Then
GoTo este_una
Else

DrivereExplicatii(bulaD).BackColor = 16711680
DrivereTitlu(bulaD).BackColor = 16711680
DrivereCale(bulaD).BackColor = 16711680

MsgBox "Trebuie sa completezi cel putin o casuta ! (adica interfata trebuie sa prezinte cel putin un driver)"
Exit Sub
End If
Next bulaD
este_una:

For bulaD = 0 To 7
If DrivereTitlu(bulaD).Text <> "" And DrivereExplicatii(bulaD).Text <> "" And DrivereCale(bulaD).Text = "" Then
MsgBox "Pentru ca programul sa poata copia driver-ul in structura matritei trebuie sa introduci" & vbCrLf & _
"toate datele cerute intr-o casuta(nu trebuie lasata completata partial)"
DrivereCale(bulaD).BackColor = 16711680
Exit Sub
End If

If DrivereTitlu(bulaD).Text <> "" And DrivereExplicatii(bulaD).Text = "" And DrivereCale(bulaD).Text <> "" Then
MsgBox "Pentru ca programul sa poata copia driver-ul in structura matritei trebuie sa introduci" & vbCrLf & _
"toate datele cerute intr-o casuta(nu trebuie lasata completata partial)"
DrivereExplicatii(bulaD).BackColor = 16711680
Exit Sub
End If


If DrivereTitlu(bulaD).Text = "" And DrivereExplicatii(bulaD).Text <> "" And DrivereCale(bulaD).Text <> "" Then
MsgBox "Pentru ca programul sa poata copia driver-ul in structura matritei trebuie sa introduci" & vbCrLf & _
"toate datele cerute intr-o casuta(nu trebuie lasata completata partial)"
DrivereTitlu(bulaD).BackColor = 16711680
Exit Sub
End If


If DrivereTitlu(bulaD).Text <> "" And DrivereExplicatii(bulaD).Text = "" And DrivereCale(bulaD).Text = "" Then
MsgBox "Pentru ca programul sa poata copia driver-ul in structura matritei trebuie sa introduci" & vbCrLf & _
"toate datele cerute intr-o casuta(nu trebuie lasata completata partial)"
DrivereExplicatii(bulaD).BackColor = 16711680
DrivereCale(bulaD).BackColor = 16711680
Exit Sub
End If


If DrivereTitlu(bulaD).Text = "" And DrivereExplicatii(bulaD).Text <> "" And DrivereCale(bulaD).Text = "" Then
MsgBox "Pentru ca programul sa poata copia driver-ul in structura matritei trebuie sa introduci" & vbCrLf & _
"toate datele cerute intr-o casuta(nu trebuie lasata completata partial)"
DrivereTitlu(bulaD).BackColor = 16711680
DrivereCale(bulaD).BackColor = 16711680
Exit Sub
End If

If DrivereTitlu(bulaD).Text = "" And DrivereExplicatii(bulaD).Text = "" And DrivereCale(bulaD).Text <> "" Then
MsgBox "Pentru ca programul sa poata copia driver-ul in structura matritei trebuie sa introduci" & vbCrLf & _
"toate datele cerute intr-o casuta(nu trebuie lasata completata partial)"
DrivereTitlu(bulaD).BackColor = 16711680
DrivereExplicatii(bulaD).BackColor = 16711680
Exit Sub
End If

DoEvents

Next bulaD

ff = FreeFile
Open App.Path & "\Geneza\Drivere.htm" For Output As #ff

d333 = "<body scroll=no bgcolor=#ffffff background=" & Chr(34) & D_Cale_text.Text & Chr(34) & ">"

d222 = "<center><FONT style=" & Chr(34) & "font-family:Time New Roman;face:Time New Roman" & Chr(34) & " size=" & Chr(34) & "10" & Chr(34) & " color=#ffffff> Drivere </FONT><br><br></center>"

capulZulu = d333 & d222 & "<table border=" & Chr(34) & "0" & Chr(34) & " cellpadding=" & Chr(34) & "0" & Chr(34) & " cellspacing=" & Chr(34) & "0" & Chr(34) & " style=" & Chr(34) & "border-collapse:collapse" & Chr(34) & " width=" & Chr(34) & "100%" & Chr(34) & " id=" & Chr(34) & "Eu" & Chr(34) & ">"

bulaD = 0
For tt = 1 To 4
capulZulu = capulZulu & "<tr>"

For vv = 1 To 2
If DrivereTitlu(bulaD).Text = "" And DrivereExplicatii(bulaD).Text = "" And DrivereCale(bulaD).Text = "" Then
GoTo nimic
End If


capulZulu = capulZulu & "<td width=" & Chr(34) & "50%" & Chr(34) & " onmouseout=" & Chr(34) & "sterge()" & Chr(34) & "onmouseover=" & Chr(34) & "arata(" & Chr(39) & DrivereExplicatii(bulaD).Text & Chr(39) & ")" & Chr(34) & ">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"

capulZulu = capulZulu & "<a href=" & Chr(34) & DrivereCale(bulaD).Text & Chr(34) & _
" style=" & Chr(34) & "text-decoration:none" & Chr(34) & ">"

capulZulu = capulZulu & "<font size=" & Chr(34) & D_FontMarime.Text & Chr(34) & " face=" & _
Chr(34) & D_Font.Text & Chr(34) & " color=" & Chr(34) & "#" & D_FontCuloare.Text & Chr(34) & _
"><img src=" & Chr(34) & "IMG\pc2.GIF" & Chr(34) & " border=" & Chr(34) & "0" & _
Chr(34) & ">" & DrivereTitlu(bulaD).Text & "</font></a>"

capulZulu = capulZulu & "</td>"

nimic:
bulaD = bulaD + 1
Next vv
capulZulu = capulZulu & "</tr>"
Next tt

'MsgBox capulZulu
InPlus = "<font size=" & Chr(34) & EX_FontMarime.Text & Chr(34) & " face=" & Chr(34) & EX_Font.Text & Chr(34) & " color=" & Chr(34) & "#" & EX_FontCuloare.Text & Chr(34) & "><div align=left valign=top Id=" & Chr(34) & "CutiaNeagra" & Chr(34) & " style=" & Chr(34) & "position:absolute;top:13;left:20;width:100%;overflow:auto;height:50px" & Chr(34) & "></div></font>"

Print #ff, drivere1.Text & vbCrLf & capulZulu & Drivere & InPlus & vbCrLf & drivere2.Text
Close #ff
PreVedere.Text_Imagine.Navigate (App.Path & "\Geneza\Drivere.htm")
PreVedere.Show
End If

End Sub

Function Proceseaza(ByVal xx As String) As String
saty = xx
saty = Replace(saty, Chr(13), "<br>")

Proceseaza = saty
End Function

Private Sub kit_Click(Index As Integer)
On Error GoTo aa

Deschide.Filename = ""
Deschide.Filter = "Fisiere EXE (*.exe)|*.exe"
Deschide.ShowOpen

If Index = 0 Then
temp_Kit(0) = Deschide.Filename
cale2(0).Text = Deschide.Filename
End If

If Index = 1 Then
temp_Kit(1) = Deschide.Filename
cale2(1).Text = Deschide.Filename
End If

If Index = 2 Then
temp_Kit(2) = Deschide.Filename
cale2(2).Text = Deschide.Filename
End If

If Index = 3 Then
temp_Kit(3) = Deschide.Filename
cale2(3).Text = Deschide.Filename
End If

If Index = 4 Then
temp_Kit(4) = Deschide.Filename
cale2(4).Text = Deschide.Filename
End If

If Index = 5 Then
temp_Kit(5) = Deschide.Filename
cale2(5).Text = Deschide.Filename
End If

cale2(Index).BackColor = &H0&
aa:
End Sub

Private Sub kitZip_Click(Index As Integer)
On Error GoTo aa

Deschide.Filename = ""
Deschide.Filter = "Fisiere zip (*.zip)|*.zip"
Deschide.ShowOpen

If Index = 0 Then
temp_KitZip(0) = Deschide.Filename
calea(0).Text = Deschide.Filename
End If

If Index = 1 Then
temp_KitZip(1) = Deschide.Filename
calea(1).Text = Deschide.Filename
End If

If Index = 2 Then
temp_KitZip(2) = Deschide.Filename
calea(2).Text = Deschide.Filename
End If

If Index = 3 Then
temp_KitZip(3) = Deschide.Filename
calea(3).Text = Deschide.Filename
End If

If Index = 4 Then
temp_KitZip(4) = Deschide.Filename
calea(4).Text = Deschide.Filename
End If

If Index = 5 Then
temp_KitZip(5) = Deschide.Filename
calea(5).Text = Deschide.Filename
End If

calea(Index).BackColor = &H0&

aa:
End Sub

Private Sub ListaMare_Click(Index As Integer)
On Error Resume Next

EU_nobel = Mid(UT_Variabile_Nume(Index), InStr(UT_Variabile_Nume(Index), "|") + 1, Len(UT_Variabile_Nume(Index)))
Titlu(0).Text = Mid(EU_nobel, 1, InStr(EU_nobel, "|#") - 1)

'UT_Variabile_Explicatii(Index) = Replace(UT_Variabile_Explicatii(Index), vbCrLf, "")

EU_nobel = Mid(UT_Variabile_Explicatii(Index), InStr(UT_Variabile_Explicatii(Index), "]") + 1, Len(UT_Variabile_Explicatii(Index)))
Explicatie(0).Text = Mid(EU_nobel, 1, InStr(EU_nobel, "[STO") - 1) 'MM_Variabile_Explicatii(Index)

Citeste_Text(0) = UT_Citeste_ma(Index)

calea(0).Text = UT_KitZip(Index)
cale2(0).Text = UT_Kit(Index)

IMica(0).Text = UT_Img1(Index)
IMare(0).Text = UT_Img2(Index)

Imagine_Meniu(0).LoadFromFile (UT_Img1(Index))
End Sub

Private Sub ListaMareAV_Click(Index As Integer)
On Error Resume Next

EU_nobel = Mid(AV_Variabile_Nume(Index), InStr(AV_Variabile_Nume(Index), "|") + 1, Len(AV_Variabile_Nume(Index)))
Titlu(4).Text = Mid(EU_nobel, 1, InStr(EU_nobel, "|#") - 1)

EU_nobel = Mid(AV_Variabile_Explicatii(Index), InStr(AV_Variabile_Explicatii(Index), "]") + 1, Len(AV_Variabile_Explicatii(Index)))
Explicatie(4).Text = Mid(EU_nobel, 1, InStr(EU_nobel, "[STO") - 4) 'MM_Variabile_Explicatii(Index)

Citeste_Text(4) = AV_Citeste_ma(Index)

calea(4).Text = AV_KitZip(Index)
cale2(4).Text = AV_Kit(Index)

IMica(4).Text = AV_Img1(Index)
IMare(4).Text = AV_Img2(Index)

Imagine_Meniu(4).LoadFromFile (AV_Img1(Index))
End Sub

Private Sub ListaMareIN_Click(Index As Integer)
On Error Resume Next

EU_nobel = Mid(IN_Variabile_Nume(Index), InStr(IN_Variabile_Nume(Index), "|") + 1, Len(IN_Variabile_Nume(Index)))
Titlu(3).Text = Mid(EU_nobel, 1, InStr(EU_nobel, "|#") - 1)

EU_nobel = Mid(IN_Variabile_Explicatii(Index), InStr(IN_Variabile_Explicatii(Index), "]") + 1, Len(IN_Variabile_Explicatii(Index)))
Explicatie(3).Text = Mid(EU_nobel, 1, InStr(EU_nobel, "[STO") - 4) 'MM_Variabile_Explicatii(Index)

Citeste_Text(3) = IN_Citeste_ma(Index)

calea(3).Text = IN_KitZip(Index)
cale2(3).Text = IN_Kit(Index)

IMica(3).Text = IN_Img1(Index)
IMare(3).Text = IN_Img2(Index)

Imagine_Meniu(3).LoadFromFile (IN_Img1(Index))
End Sub

Private Sub ListaMareJC_Click(Index As Integer)
On Error Resume Next

EU_nobel = Mid(JC_Variabile_Nume(Index), InStr(JC_Variabile_Nume(Index), "|") + 1, Len(JC_Variabile_Nume(Index)))
Titlu(2).Text = Mid(EU_nobel, 1, InStr(EU_nobel, "|#") - 1)

EU_nobel = Mid(JC_Variabile_Explicatii(Index), InStr(JC_Variabile_Explicatii(Index), "]") + 1, Len(JC_Variabile_Explicatii(Index)))
Explicatie(2).Text = Mid(EU_nobel, 1, InStr(EU_nobel, "[STO") - 4) 'MM_Variabile_Explicatii(Index)

Citeste_Text(2) = JC_Citeste_ma(Index)

calea(2).Text = JC_KitZip(Index)
cale2(2).Text = JC_Kit(Index)

IMica(2).Text = JC_Img1(Index)
IMare(2).Text = JC_Img2(Index)

Imagine_Meniu(2).LoadFromFile (JC_Img1(Index))
End Sub

Private Sub ListaMareMM_Click(Index As Integer)
On Error Resume Next

EU_nobel = Mid(MM_Variabile_Nume(Index), InStr(MM_Variabile_Nume(Index), "|") + 1, Len(MM_Variabile_Nume(Index)))
Titlu(1).Text = Mid(EU_nobel, 1, InStr(EU_nobel, "|#") - 1)

EU_nobel = Mid(MM_Variabile_Explicatii(Index), InStr(MM_Variabile_Explicatii(Index), "]") + 1, Len(MM_Variabile_Explicatii(Index)))
Explicatie(1).Text = Mid(EU_nobel, 1, InStr(EU_nobel, "[STO") - 4) 'MM_Variabile_Explicatii(Index)

Citeste_Text(1) = MM_Citeste_ma(Index)

calea(1).Text = MM_KitZip(Index)
cale2(1).Text = MM_Kit(Index)

IMica(1).Text = MM_Img1(Index)
IMare(1).Text = MM_Img2(Index)

Imagine_Meniu(1).LoadFromFile (MM_Img1(Index))

End Sub

Private Sub ListaMarePR_Click(Index As Integer)
On Error Resume Next

EU_nobel = Mid(PR_Variabile_Nume(Index), InStr(PR_Variabile_Nume(Index), "|") + 1, Len(PR_Variabile_Nume(Index)))
Titlu(5).Text = Mid(EU_nobel, 1, InStr(EU_nobel, "|#") - 1)

EU_nobel = Mid(PR_Variabile_Explicatii(Index), InStr(PR_Variabile_Explicatii(Index), "]") + 1, Len(PR_Variabile_Explicatii(Index)))
Explicatie(5).Text = Mid(EU_nobel, 1, InStr(EU_nobel, "[STO") - 4) 'MM_Variabile_Explicatii(Index)

Citeste_Text(5) = PR_Citeste_ma(Index)

calea(5).Text = PR_KitZip(Index)
cale2(5).Text = PR_Kit(Index)

IMica(5).Text = PR_Img1(Index)
IMare(5).Text = PR_Img2(Index)

Imagine_Meniu(5).LoadFromFile (PR_Img1(Index))

End Sub

Private Sub Pachet_Click()

Compilare_CD.Text = ""

If UT_Variabile_Nume(0) = "" And Activat(0) = True Then
MsgBox "In sectiunea UTILITARE nu a fost prezentat nici un program !" & vbCrLf & _
"Dupa introducerea datelor pentru prezentarea unui program trebuie apasat butonul " & _
Chr(34) & "Introdu datele in lista de setari" & Chr(34)
Master_Control.Tab = 0
Exit Sub
End If

If MM_Variabile_Nume(0) = "" And Activat(1) = True Then
MsgBox "In sectiunea MULTIMEDIA nu a fost prezentat nici un program !" & vbCrLf & _
"Dupa introducerea datelor pentru prezentarea unui program trebuie apasat butonul " & _
Chr(34) & "Introdu datele in lista de setari" & Chr(34)
Master_Control.Tab = 1
Exit Sub
End If

If JC_Variabile_Nume(0) = "" And Activat(2) = True Then
MsgBox "In sectiunea JOCURI nu a fost prezentat nici un program !" & vbCrLf & _
"Dupa introducerea datelor pentru prezentarea unui program trebuie apasat butonul " & _
Chr(34) & "Introdu datele in lista de setari" & Chr(34)
Master_Control.Tab = 2
Exit Sub
End If

If IN_Variabile_Nume(0) = "" And Activat(3) = True Then
MsgBox "In sectiunea INTERNET nu a fost prezentat nici un program !" & vbCrLf & _
"Dupa introducerea datelor pentru prezentarea unui program trebuie apasat butonul " & _
Chr(34) & "Introdu datele in lista de setari" & Chr(34)
Master_Control.Tab = 3
Exit Sub
End If

If AV_Variabile_Nume(0) = "" And Activat(4) = True Then
MsgBox "In sectiunea ANTIVIRUS nu a fost prezentat nici un program !" & vbCrLf & _
"Dupa introducerea datelor pentru prezentarea unui program trebuie apasat butonul " & _
Chr(34) & "Introdu datele in lista de setari" & Chr(34)
Master_Control.Tab = 4
Exit Sub
End If

If PR_Variabile_Nume(0) = "" And Activat(5) = True Then
MsgBox "In sectiunea PERMANENTE nu a fost prezentat nici un program !" & vbCrLf & _
"Dupa introducerea datelor pentru prezentarea unui program trebuie apasat butonul " & _
Chr(34) & "Introdu datele in lista de setari" & Chr(34)
Master_Control.Tab = 5
Exit Sub
End If

If CaleFundalIntro.Text = "" And Activat(6) = True Then
MsgBox "Trebuie sa alegi imaginea de fundal pentru sectiunea INTRO!" & vbCrLf & _
"Imaginea pentru reclama de care imi spuneai la telefon ! (desenezi un baner ... si il salvezi ca fisier GIF)"
Master_Control.Tab = 7
Exit Sub
End If

If CaleAjutor.Text = "" And Activat(7) = True Then
MsgBox "Trebuie sa alegi imaginea de fundal pentru sectiunea Ajutor!"
Master_Control.Tab = 8
Exit Sub
End If

' Astea sunt fara var "ACTIVAT" pt. ca tin de melodie si de xls
'(acuma are variabila ACTIVAT)
If Ar_text.Text = "" And Activat(16) = True Then
MsgBox "Trebuie sa alegi fisierul XLS pentru arhiva PC World!"
Master_Control.Tab = 10
Exit Sub
End If

' Astea sunt fara var "ACTIVAT" pt. ca tin de melodie si de xls
If cale_sunet.Text = "" And Activat(10) = True Then
MsgBox "Trebuie sa alegi WAV-ul ciclic de fundal ! (melodia de fundal)"
Master_Control.Tab = 10
Exit Sub
End If

'evitarea caracterelor critice ca : |[]""''#

For vaca = 0 To 5

If InStr(Titlu(vaca).Text, "]") <> 0 Or InStr(Titlu(vaca).Text, "[") <> 0 Or InStr(Titlu(vaca).Text, Chr(39)) <> 0 Or InStr(Titlu(vaca).Text, Chr(34)) <> 0 Or InStr(Titlu(vaca).Text, "#") <> 0 Or InStr(Titlu(vaca).Text, "|") <> 0 Then
MsgBox "Caracterele: <|><[><]><#><" & Chr(39) & "><" & Chr(34) & "> sunt nepermise. " & vbCrLf & _
"Greseala este in sectiunea - " & sat(vaca) & ", la casuta " & Chr(34) & "Titlul programului prezentat" & Chr(34)
'If Activat(vaca) = False Then MsgBox "Trebuie sa activezi butonul aferent sectiunii " & sat(vaca) & " si apoi sa stergi caracterele nepermise !!!!!!!!"
Master_Control.Tab = vaca
Titlu(vaca).BackColor = &HFF0000
Exit Sub
End If

If InStr(Explicatie(vaca).Text, "]") <> 0 Or InStr(Explicatie(vaca).Text, "[") <> 0 Or InStr(Explicatie(vaca).Text, Chr(39)) <> 0 Or InStr(Explicatie(vaca).Text, Chr(34)) <> 0 Or InStr(Explicatie(vaca).Text, "#") <> 0 Or InStr(Explicatie(vaca).Text, "|") <> 0 Then
MsgBox "Caracterele: <|><[><]><#><" & Chr(39) & "><" & Chr(34) & "> sunt nepermise. " & vbCrLf & _
"Greseala este in sectiunea - " & sat(vaca) & ", la casuta " & Chr(34) & "Expicatii despre programul prezentat" & Chr(34)
'If Activat(vaca) = False Then MsgBox "Trebuie sa activezi butonul aferent sectiunii " & sat(vaca) & " si apoi sa stergi caracterele nepermise !!!!!!!!"
Explicatie(vaca).BackColor = &HFF0000
Master_Control.Tab = vaca
Exit Sub
End If

Next vaca


If InStr(AxaRotativa.Text, Chr(39)) <> 0 Then
MsgBox "Caracterul [" & Chr(39) & "] este nepermis !!!"
Exit Sub
End If

'***************************************************************************
'DRIVERE

If Activat(9) = True Then

For bulaD = 0 To 7
If DrivereTitlu(bulaD).Text <> "" Or DrivereExplicatii(bulaD).Text <> "" Or DrivereCale(bulaD).Text <> "" Then
GoTo este_una
Else

Master_Control.Tab = 9

DrivereExplicatii(bulaD).BackColor = 16711680
DrivereTitlu(bulaD).BackColor = 16711680
DrivereCale(bulaD).BackColor = 16711680

MsgBox "Trebuie sa completezi cel putin o casuta ! (adica interfata trebuie sa prezinte cel putin un driver)"
Exit Sub
End If
Next bulaD
este_una:

For bulaD = 0 To 7
If DrivereTitlu(bulaD).Text <> "" And DrivereExplicatii(bulaD).Text <> "" And DrivereCale(bulaD).Text = "" Then
Master_Control.Tab = 9
MsgBox "Pentru ca programul sa poata copia driver-ul in structura matritei trebuie sa introduci" & vbCrLf & _
"toate datele cerute intr-o casuta(nu trebuie lasata completata partial)"
DrivereCale(bulaD).BackColor = 16711680
Exit Sub
End If

If DrivereTitlu(bulaD).Text <> "" And DrivereExplicatii(bulaD).Text = "" And DrivereCale(bulaD).Text <> "" Then
Master_Control.Tab = 9
MsgBox "Pentru ca programul sa poata copia driver-ul in structura matritei trebuie sa introduci" & vbCrLf & _
"toate datele cerute intr-o casuta(nu trebuie lasata completata partial)"
DrivereExplicatii(bulaD).BackColor = 16711680
Exit Sub
End If


If DrivereTitlu(bulaD).Text = "" And DrivereExplicatii(bulaD).Text <> "" And DrivereCale(bulaD).Text <> "" Then
Master_Control.Tab = 9
MsgBox "Pentru ca programul sa poata copia driver-ul in structura matritei trebuie sa introduci" & vbCrLf & _
"toate datele cerute intr-o casuta(nu trebuie lasata completata partial)"
DrivereTitlu(bulaD).BackColor = 16711680
Exit Sub
End If


If DrivereTitlu(bulaD).Text <> "" And DrivereExplicatii(bulaD).Text = "" And DrivereCale(bulaD).Text = "" Then
Master_Control.Tab = 9
MsgBox "Pentru ca programul sa poata copia driver-ul in structura matritei trebuie sa introduci" & vbCrLf & _
"toate datele cerute intr-o casuta(nu trebuie lasata completata partial)"
DrivereExplicatii(bulaD).BackColor = 16711680
DrivereCale(bulaD).BackColor = 16711680
Exit Sub
End If


If DrivereTitlu(bulaD).Text = "" And DrivereExplicatii(bulaD).Text <> "" And DrivereCale(bulaD).Text = "" Then
Master_Control.Tab = 9
MsgBox "Pentru ca programul sa poata copia driver-ul in structura matritei trebuie sa introduci" & vbCrLf & _
"toate datele cerute intr-o casuta(nu trebuie lasata completata partial)"
DrivereTitlu(bulaD).BackColor = 16711680
DrivereCale(bulaD).BackColor = 16711680
Exit Sub
End If

If DrivereTitlu(bulaD).Text = "" And DrivereExplicatii(bulaD).Text = "" And DrivereCale(bulaD).Text <> "" Then
Master_Control.Tab = 9
MsgBox "Pentru ca programul sa poata copia driver-ul in structura matritei trebuie sa introduci" & vbCrLf & _
"toate datele cerute intr-o casuta(nu trebuie lasata completata partial)"
DrivereTitlu(bulaD).BackColor = 16711680
DrivereExplicatii(bulaD).BackColor = 16711680
Exit Sub
End If

DoEvents

Next bulaD

End If ' vine de la Activat(9) = True
'***************************************************************************

Master_Control.Tab = 11

For ddsx = 0 To 10
Master_Control.TabEnabled(ddsx) = False

If ddsx <= 5 Then
If Activat(ddsx) = False Then
Sterge_Click (ddsx)
End If
End If

Next ddsx

' **************************** Titluri ***********************************************
For ffg = 0 To 18
If UT_Variabile_Nume(ffg) = "" Then
Else
lala_UT = lala_UT & vbCrLf & UT_Variabile_Nume(ffg)
lala_UT_E = lala_UT_E & vbCrLf & UT_Variabile_Explicatii(ffg)

End If
Next ffg
Sectiuni_meniu_final(0) = vbCrLf & "[UTILITARE]" & lala_UT & vbCrLf & "[UT-STOP]"
Sectiuni_explicatii_final(0) = "[UTILITARE-EXPLICATII]" & lala_UT_E & vbCrLf & "[UTILITARE-STOP]" & vbCrLf
Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Utilitare - titlul programului si explicatii = OK"

For ffg = 0 To 18
If MM_Variabile_Nume(ffg) = "" Then
Else
lala_MM = lala_MM & vbCrLf & MM_Variabile_Nume(ffg)
lala_MM_E = lala_MM_E & vbCrLf & MM_Variabile_Explicatii(ffg)
End If
Next ffg
Sectiuni_meniu_final(1) = vbCrLf & "[MULTIMEDIA]" & lala_MM & vbCrLf & "[MM-STOP]"
Sectiuni_explicatii_final(1) = "[MULTIMEDIA-EXPLICATII]" & lala_MM_E & vbCrLf & "[MULTIMEDIA-STOP]" & vbCrLf
Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Multimedia - titlul programului si explicatii = OK"

For ffg = 0 To 18
If JC_Variabile_Nume(ffg) = "" Then
Else
lala_JC = lala_JC & vbCrLf & JC_Variabile_Nume(ffg)
lala_JC_E = lala_JC_E & vbCrLf & JC_Variabile_Explicatii(ffg)
End If
Next ffg
Sectiuni_meniu_final(2) = vbCrLf & "[JOCURI]" & lala_JC & vbCrLf & "[JC-STOP]"
Sectiuni_explicatii_final(2) = "[JOCURI-EXPLICATII]" & lala_JC_E & vbCrLf & "[JOCURI-STOP]" & vbCrLf
Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Jocuri - titlul programului si explicatii = OK"


For ffg = 0 To 18
If IN_Variabile_Nume(ffg) = "" Then
Else
lala_IN = lala_IN & vbCrLf & IN_Variabile_Nume(ffg)
lala_IN_E = lala_IN_E & vbCrLf & IN_Variabile_Explicatii(ffg)
End If
Next ffg
Sectiuni_meniu_final(3) = vbCrLf & "[INTERNET]" & lala_IN & vbCrLf & "[IN-STOP]"
Sectiuni_explicatii_final(3) = "[INTERNET-EXPLICATII]" & lala_IN_E & vbCrLf & "[INTERNET-STOP]" & vbCrLf
Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Internet - titlul programului si explicatii = OK"


For ffg = 0 To 18
If AV_Variabile_Nume(ffg) = "" Then
Else
lala_AV = lala_AV & vbCrLf & AV_Variabile_Nume(ffg)
lala_AV_E = lala_AV_E & vbCrLf & AV_Variabile_Explicatii(ffg)
End If
Next ffg
Sectiuni_meniu_final(4) = vbCrLf & "[ANTIVIRUS]" & lala_AV & vbCrLf & "[AV-STOP]"
Sectiuni_explicatii_final(4) = "[ANTIVIRUS-EXPLICATII]" & lala_AV_E & vbCrLf & "[ANTIVIRUS-STOP]" & vbCrLf
Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Antivirus - titlul programului si explicatii = OK"


For ffg = 0 To 18
If PR_Variabile_Nume(ffg) = "" Then
Else
lala_PR = lala_PR & vbCrLf & PR_Variabile_Nume(ffg)
lala_PR_E = lala_PR_E & vbCrLf & PR_Variabile_Explicatii(ffg)
End If
Next ffg
Sectiuni_meniu_final(5) = vbCrLf & "[PERMANENTE]" & lala_PR & vbCrLf & "[PR-STOP]"
Sectiuni_explicatii_final(5) = "[PERMANENTE-EXPLICATII]" & lala_PR_E & vbCrLf & "[PERMANENTE-STOP]"
Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Permanente - titlul programului si explicatii = OK"

'*********************************  explicatii  **********************************************

Radacina_cap = "***** Copyright by Paul Gagniuc *****" & vbCrLf & "[MENIURI]"
Radacina_mijloc = vbCrLf & "[MENIURI-STOP]" & vbCrLf & "[Rupere-de-nori]" & vbCrLf
Radacina_coada = vbCrLf & "[Rupere-de-nori-STOP]"

For rrt = 0 To 5 '6
Meniuri_general = Meniuri_general & Sectiuni_meniu_final(rrt)
Next rrt

For rrt = 0 To 5 '6
Explicatii_general = Explicatii_general & Sectiuni_explicatii_final(rrt)
Next rrt

Partea1 = Radacina_cap & Meniuri_general & Radacina_mijloc
Partea2 = Explicatii_general & Radacina_coada

Gata_Tataie = Partea1 & Partea2

Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Imbinare si generare structuri ..."
'MsgBox Gata_Tataie
director (Cale_matrita.Text & "\Matrita")
director (Cale_matrita.Text & "\Matrita\PC_World")

ff = FreeFile
Open App.Path & "\Geneza\biohazard.zulu" For Output As #ff
Print #ff, Gata_Tataie
Close #ff

Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "biohazard.zulu a fost generat si copiat !"

'++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
For gama = 0 To 18
If Activat(gama) = False Then
xgama = xgama & gama & "#"
End If
Next gama

'xgama = xgama & vbCrLf & codul_lunii

Call ScrieIn(App.Path & "\Geneza\biohazard.gama", xgama)
'++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

'Revista --------------------------------------------------------------------------------------------
If Activat(6) = True Then

ff = FreeFile
Open App.Path & "\Geneza\Revista.htm" For Output As #ff
Print #ff, revista1.Text & vbCrLf & Revista & vbCrLf & revista2.Text
Close #ff

End If
'Intro --------------------------------------------------------------------------------------------
If Activat(7) = True Then
If Reclama_luna.Value = 0 Then


ff = FreeFile
Open App.Path & "\Geneza\Intrare.htm" For Output As #ff
lalala1 = "<DIV id=cade style=" & Chr(34) & "BACKGROUND-COLOR: #" & culoare.Text & "; HEIGHT:" & Inaltime.Text & _
"px; LEFT: 126px; POSITION: absolute; TOP: 100px; VISIBILITY: hidden;WIDTH:" & latime.Text & "px" & Chr(34) & ">"


lalala2 = "</DIV></tr></td></table>"

lala3 = "<table border=" & Chr(34) & borduraG.Text & Chr(34) & " cellpadding=" & Chr(34) & "0" & _
Chr(34) & " cellspacing=" & Chr(34) & "0" & Chr(34) & " style=" & Chr(34) & _
"border-collapse: collapse" & Chr(34) & " width=" & Chr(34) & "100%" & Chr(34) & _
" height=" & Chr(34) & "100%" & Chr(34) & "><tr><td valign=top align=right " & _
"width=" & Chr(34) & "100%" & Chr(34) & " background=" & Chr(34) & _
CaleFundalIntro.Text & Chr(34) & "height=100%><button onclick=" & Chr(34) & _
"Hai_Pa();return false" & Chr(34) & " style=" & Chr(34) & "height:20;width:20" & Chr(34) & _
"><FONT color=" & Chr(34) & "000000" & Chr(34) & " face=Arial size=1>x</FONT></button>"

proces = Proceseaza(Intro.Text)
Print #ff, Intro1.Text & vbCrLf & proces & vbCrLf & Intro2.Text & lalala1 & lala3 & Intro3.Text & lalala2
Close #ff

Else

'axa text ==============================
'mai sus la conditii am verificat inainte de compilare sa nu aiba caractere nepermise.
ff = FreeFile
Open App.Path & "\Geneza\Intrare.htm" For Output As #ff
Print #ff, IntroFaraReclama(0).Text & Proceseaza(Intro.Text) & IntroFaraReclama(1).Text & AxaRotativa.Text & IntroFaraReclama(2).Text
Close #ff
'axa text ==============================

End If
End If
'Ajutor --------------------------------------------------------------------------------------------
If Activat(8) = True Then

ff = FreeFile
Open App.Path & "\Geneza\Ajutor.htm" For Output As #ff

xxl = Proceseaza(Ajutor.Text)
xx1 = "<body bgcolor=white background=" & Chr(34) & "IMG\fundal-c.gif" & Chr(34) & "><font size=" & Chr(34) & FontMarime.Text & Chr(34) & " face=" & Chr(34) & Fontul.Text & Chr(34) & " color=" & Chr(34) & "#" & FontCuloare.Text & Chr(34) & ">"

Print #ff, Ajutor1.Text & vbCrLf & xx1 & xxl & "</FONT>"
Close #ff

End If
'Driver --------------------------------------------------------------------------------------------
If Activat(9) = True Then

ff = FreeFile
Open App.Path & "\Geneza\Drivere.htm" For Output As #ff

d333 = "<body scroll=no bgcolor=#ffffff background=" & Chr(34) & "IMG\fundal7.jpg" & Chr(34) & ">"
d222 = "<center><FONT style=" & Chr(34) & "font-family:Time New Roman;face:Time New Roman" & Chr(34) & " size=" & Chr(34) & "10" & Chr(34) & " color=#ffffff> Drivere </FONT><br><br></center>"

capulZulu = d333 & d222 & "<table border=" & Chr(34) & "0" & Chr(34) & " cellpadding=" & Chr(34) & "0" & Chr(34) & " cellspacing=" & Chr(34) & "0" & Chr(34) & " style=" & Chr(34) & "border-collapse:collapse" & Chr(34) & " width=" & Chr(34) & "100%" & Chr(34) & " id=" & Chr(34) & "Eu" & Chr(34) & ">"

bulaD = 0
For tt = 1 To 4
capulZulu = capulZulu & "<tr>"

For vv = 1 To 2
If DrivereTitlu(bulaD).Text = "" And DrivereExplicatii(bulaD).Text = "" And DrivereCale(bulaD).Text = "" Then
GoTo nimic
End If

capulZulu = capulZulu & "<td width=" & Chr(34) & "50%" & Chr(34) & " onmouseout=" & Chr(34) & "sterge()" & Chr(34) & "onmouseover=" & Chr(34) & "arata(" & Chr(39) & DrivereExplicatii(bulaD).Text & Chr(39) & ")" & Chr(34) & ">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"

capulZulu = capulZulu & "<a href=" & Chr(34) & "Drivere\" & numeDriver(bulaD) & Chr(34) & _
" style=" & Chr(34) & "text-decoration:none" & Chr(34) & ">"

capulZulu = capulZulu & "<font size=" & Chr(34) & D_FontMarime.Text & Chr(34) & " face=" & _
Chr(34) & D_Font.Text & Chr(34) & " color=" & Chr(34) & "#" & D_FontCuloare.Text & Chr(34) & _
"><img src=" & Chr(34) & "IMG\pc2.GIF" & Chr(34) & " border=" & Chr(34) & "0" & _
Chr(34) & ">" & DrivereTitlu(bulaD).Text & "</font></a>"

capulZulu = capulZulu & "</td>"

nimic:
bulaD = bulaD + 1
Next vv
capulZulu = capulZulu & "</tr>"
Next tt

InPlus = "<font size=" & Chr(34) & EX_FontMarime.Text & Chr(34) & " face=" & Chr(34) & EX_Font.Text & Chr(34) & " color=" & Chr(34) & "#" & EX_FontCuloare.Text & Chr(34) & "><div align=left valign=top Id=" & Chr(34) & "CutiaNeagra" & Chr(34) & " style=" & Chr(34) & "position:absolute;top:13;left:20;width:100%;overflow:auto;height:50px" & Chr(34) & "></div></font>"

Print #ff, drivere1.Text & vbCrLf & capulZulu & Drivere & InPlus & vbCrLf & drivere2.Text
Close #ff

End If
' --------------------------------------------------------------------------------------------
Call Fa_directoare

Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Structura matritei a fost COMPILATA !!!"
Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Bine-mi pare, in gradina am o floare ..."
Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "GATA !!!"

For ddsx = 0 To 9

If Activat(ddsx) = False Then
Master_Control.TabEnabled(ddsx) = False
End If

If Activat(ddsx) = True Then
Master_Control.TabEnabled(ddsx) = True
End If

Next ddsx

End Sub

Function director(ByVal yo As String)
DoEvents
MkDir (yo)
DoEvents
End Function

Function Fa_directoare()
Dim Miracol(0 To 20) As String
Dim Misiune(1 To 3) As String

Miracol(0) = "UT"
Miracol(1) = "MM"
Miracol(2) = "JC"
Miracol(3) = "IN"
Miracol(4) = "AV"
Miracol(5) = "PR"

Miracol(6) = "Kit"
Miracol(7) = "Negativ"
Miracol(8) = "IMG"


Misiune(1) = "Kit"
Misiune(2) = "_Instalare"
Misiune(3) = "_Rulare"

Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Este creata structura de directoare ..."

director (Cale_matrita.Text & "\Matrita\PC_World\aferent")
director (Cale_matrita.Text & "\Matrita\PC_World\aferent\Drivere")
director (Cale_matrita.Text & "\Matrita\PC_World\aferent\Revista")

For dirr = 0 To 8
director (Cale_matrita.Text & "\Matrita\PC_World\aferent\" & Miracol(dirr))
Next dirr

For dirr = 0 To 5
director (Cale_matrita.Text & "\Matrita\PC_World\aferent\Kit\" & Miracol(dirr))

' rindurile de mai jos ar trebui sa fie mai sus la 1 to 8
'------------------------------------------------------------------------------------
If Miracol(dirr) = "UT" And Activat(0) = True Then
On Error GoTo zuluAlfa
director (Cale_matrita.Text & "\Matrita\PC_World\aferent\UT\img")
zuluAlfa:

ggg = 0
Do While UT_Variabile_Nume(ggg) <> ""
FileCopy UT_Img1(ggg), Cale_matrita.Text & "\Matrita\PC_World\aferent\UT\" & ggg & ".gif"
FileCopy UT_Img2(ggg), Cale_matrita.Text & "\Matrita\PC_World\aferent\UT\img\" & ggg & ".gif"
ggg = ggg + 1
Loop
Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Copiez capturi - utilitare"
End If
'-----------------------------------------------------------------------------------
If Miracol(dirr) = "MM" And Activat(1) = True Then
On Error GoTo zuluAlfa2
director (Cale_matrita.Text & "\Matrita\PC_World\aferent\MM\img")
zuluAlfa2:
ggg = 0
Do While MM_Variabile_Nume(ggg) <> ""
FileCopy MM_Img1(ggg), Cale_matrita.Text & "\Matrita\PC_World\aferent\MM\" & ggg & ".gif"
FileCopy MM_Img2(ggg), Cale_matrita.Text & "\Matrita\PC_World\aferent\MM\img\" & ggg & ".gif"
ggg = ggg + 1
Loop
Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Copiez capturi - multimedia"
End If
'-----------------------------------------------------------------------------------
If Miracol(dirr) = "JC" And Activat(2) = True Then
On Error GoTo zuluAlfa3
director (Cale_matrita.Text & "\Matrita\PC_World\aferent\JC\img")
zuluAlfa3:

ggg = 0
Do While JC_Variabile_Nume(ggg) <> ""
FileCopy JC_Img1(ggg), Cale_matrita.Text & "\Matrita\PC_World\aferent\JC\" & ggg & ".gif"
FileCopy JC_Img2(ggg), Cale_matrita.Text & "\Matrita\PC_World\aferent\JC\img\" & ggg & ".gif"

ggg = ggg + 1
Loop
Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Copiez capturi - jocuri"
End If
'-----------------------------------------------------------------------------------
If Miracol(dirr) = "IN" And Activat(3) = True Then
On Error GoTo zuluAlfa4
director (Cale_matrita.Text & "\Matrita\PC_World\aferent\IN\img")
zuluAlfa4:
ggg = 0
Do While IN_Variabile_Nume(ggg) <> ""
FileCopy IN_Img1(ggg), Cale_matrita.Text & "\Matrita\PC_World\aferent\IN\" & ggg & ".gif"
FileCopy IN_Img2(ggg), Cale_matrita.Text & "\Matrita\PC_World\aferent\IN\img\" & ggg & ".gif"

ggg = ggg + 1
Loop
Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Copiez capturi - internet"
End If
'-----------------------------------------------------------------------------------
If Miracol(dirr) = "AV" And Activat(4) = True Then
On Error GoTo zuluAlfa5
director (Cale_matrita.Text & "\Matrita\PC_World\aferent\AV\img")
zuluAlfa5:
ggg = 0
Do While AV_Variabile_Nume(ggg) <> ""
FileCopy AV_Img1(ggg), Cale_matrita.Text & "\Matrita\PC_World\aferent\AV\" & ggg & ".gif"
FileCopy AV_Img2(ggg), Cale_matrita.Text & "\Matrita\PC_World\aferent\AV\img\" & ggg & ".gif"

ggg = ggg + 1
Loop
Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Copiez capturi - antivirus"
End If
'------------------------------------------------------------------------------------
If Miracol(dirr) = "PR" And Activat(5) = True Then
On Error GoTo zuluAlfa6
director (Cale_matrita.Text & "\Matrita\PC_World\aferent\PR\img")
zuluAlfa6:
ggg = 0
Do While PR_Variabile_Nume(ggg) <> ""
FileCopy PR_Img1(ggg), Cale_matrita.Text & "\Matrita\PC_World\aferent\PR\" & ggg & ".gif"
FileCopy PR_Img2(ggg), Cale_matrita.Text & "\Matrita\PC_World\aferent\PR\img\" & ggg & ".gif"

ggg = ggg + 1
Loop
Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Copiez capturi - permanente"
End If
'************************************************************************************************

'If dirr = 0 Then
'ggg = 1
'Do While UT_Variabile_Nume(ggg) <> ""
'ggg = ggg + 1
'Loop
'If ggg >= 18 Then
'Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Maxim 18 programe/sectiune"
'Exit Function
'End If
'End If

'If dirr = 1 Then
'ggg = 0
'Do While MM_Variabile_Nume(ggg) <> ""
'ggg = ggg + 1
'Loop
'If ggg >= 18 Then
'Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Maxim 18 programe/sectiune"
'Exit Function
'End If
'End If

'If dirr = 2 Then
'ggg = 0
'Do While JC_Variabile_Nume(ggg) <> ""
'ggg = ggg + 1
'Loop
'If ggg >= 18 Then
'Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Maxim 18 programe/sectiune"
'Exit Function
'End If
'End If

'If dirr = 3 Then
'ggg = 0
'Do While IN_Variabile_Nume(ggg) <> ""
'ggg = ggg + 1
'Loop
'If ggg >= 18 Then
'Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Maxim 18 programe/sectiune"
'Exit Function
'End If
'End If

'If dirr = 4 Then
'ggg = 0
'Do While AV_Variabile_Nume(ggg) <> ""
'ggg = ggg + 1
'Loop
'If ggg >= 18 Then
'Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Maxim 18 programe/sectiune"
'Exit Function
'End If
'End If

'If dirr = 5 Then
'ggg = 0
'Do While PR_Variabile_Nume(ggg) <> ""
'ggg = ggg + 1
'Loop

'If ggg >= 18 Then
'Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Maxim 18 programe/sectiune"
'Exit Function
'End If
'End If
'jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj
For dirr1 = 0 To 18 'ggg
director (Cale_matrita.Text & "\Matrita\PC_World\aferent\Kit\" & Miracol(dirr) & "\" & dirr1)

For dirr2 = 1 To 3
If dirr2 = 1 Then
director (Cale_matrita.Text & "\Matrita\PC_World\aferent\Kit\" & Miracol(dirr) & "\" & dirr1 & "\" & Misiune(dirr2))


If Miracol(dirr) = "UT" And Activat(0) = True Then
If UT_Citeste_ma(dirr1) <> "" Then
Call ScrieIn(Cale_matrita.Text & "\Matrita\PC_World\aferent\Kit\" & Miracol(dirr) & "\" & dirr1 & "\Citeste_ma.txt", UT_Citeste_ma(dirr1))

If UT_KitZip(dirr1) <> "" Then
FileCopy UT_KitZip(dirr1), Cale_matrita.Text & "\Matrita\PC_World\aferent\Kit\" & Miracol(dirr) & "\" & dirr1 & "\" & Misiune(dirr2) & "\Kit.zip"
End If

End If
End If

If Miracol(dirr) = "MM" And Activat(1) = True Then
If MM_Citeste_ma(dirr1) <> "" Then
Call ScrieIn(Cale_matrita.Text & "\Matrita\PC_World\aferent\Kit\" & Miracol(dirr) & "\" & dirr1 & "\Citeste_ma.txt", MM_Citeste_ma(dirr1))

If MM_KitZip(dirr1) <> "" Then
FileCopy MM_KitZip(dirr1), Cale_matrita.Text & "\Matrita\PC_World\aferent\Kit\" & Miracol(dirr) & "\" & dirr1 & "\" & Misiune(dirr2) & "\Kit.zip"
End If

End If
End If

If Miracol(dirr) = "JC" And Activat(2) = True Then
If JC_Citeste_ma(dirr1) <> "" Then
Call ScrieIn(Cale_matrita.Text & "\Matrita\PC_World\aferent\Kit\" & Miracol(dirr) & "\" & dirr1 & "\Citeste_ma.txt", JC_Citeste_ma(dirr1))

If JC_KitZip(dirr1) <> "" Then
FileCopy JC_KitZip(dirr1), Cale_matrita.Text & "\Matrita\PC_World\aferent\Kit\" & Miracol(dirr) & "\" & dirr1 & "\" & Misiune(dirr2) & "\Kit.zip"
End If

End If
End If

If Miracol(dirr) = "IN" And Activat(3) = True Then
If IN_Citeste_ma(dirr1) <> "" Then
Call ScrieIn(Cale_matrita.Text & "\Matrita\PC_World\aferent\Kit\" & Miracol(dirr) & "\" & dirr1 & "\Citeste_ma.txt", IN_Citeste_ma(dirr1))

If IN_KitZip(dirr1) <> "" Then
FileCopy IN_KitZip(dirr1), Cale_matrita.Text & "\Matrita\PC_World\aferent\Kit\" & Miracol(dirr) & "\" & dirr1 & "\" & Misiune(dirr2) & "\Kit.zip"
End If

End If
End If


If Miracol(dirr) = "AV" And Activat(4) = True Then
If AV_Citeste_ma(dirr1) <> "" Then
Call ScrieIn(Cale_matrita.Text & "\Matrita\PC_World\aferent\Kit\" & Miracol(dirr) & "\" & dirr1 & "\Citeste_ma.txt", AV_Citeste_ma(dirr1))

If AV_KitZip(dirr1) <> "" Then
FileCopy AV_KitZip(dirr1), Cale_matrita.Text & "\Matrita\PC_World\aferent\Kit\" & Miracol(dirr) & "\" & dirr1 & "\" & Misiune(dirr2) & "\Kit.zip"
End If

End If
End If

If Miracol(dirr) = "PR" And Activat(5) = True Then
If PR_Citeste_ma(dirr1) <> "" Then
Call ScrieIn(Cale_matrita.Text & "\Matrita\PC_World\aferent\Kit\" & Miracol(dirr) & "\" & dirr1 & "\Citeste_ma.txt", PR_Citeste_ma(dirr1))

If PR_KitZip(dirr1) <> "" Then
FileCopy PR_KitZip(dirr1), Cale_matrita.Text & "\Matrita\PC_World\aferent\Kit\" & Miracol(dirr) & "\" & dirr1 & "\" & Misiune(dirr2) & "\Kit.zip"
End If

End If
End If


Else
'MsgBox App.Path & "\aferent\Kit\" & Miracol(dirr) & "\" & dirr1 & "\" & dirr1 & Misiune(dirr2)
director (Cale_matrita.Text & "\Matrita\PC_World\aferent\Kit\" & Miracol(dirr) & "\" & dirr1 & "\" & dirr1 & Misiune(dirr2))


If dirr2 = 2 Then


If Miracol(dirr) = "UT" And Activat(0) = True Then

If UT_Kit(dirr1) <> "" Then
FileCopy UT_Kit(dirr1), Cale_matrita.Text & "\Matrita\PC_World\aferent\Kit\" & Miracol(dirr) & "\" & dirr1 & "\" & dirr1 & Misiune(dirr2) & "\setup.exe"
End If

End If

If Miracol(dirr) = "MM" And Activat(1) = True Then

If MM_Kit(dirr1) <> "" Then
FileCopy MM_Kit(dirr1), Cale_matrita.Text & "\Matrita\PC_World\aferent\Kit\" & Miracol(dirr) & "\" & dirr1 & "\" & dirr1 & Misiune(dirr2) & "\setup.exe"
End If

End If

If Miracol(dirr) = "JC" And Activat(2) = True Then

If JC_Kit(dirr1) <> "" Then
FileCopy JC_Kit(dirr1), Cale_matrita.Text & "\Matrita\PC_World\aferent\Kit\" & Miracol(dirr) & "\" & dirr1 & "\" & dirr1 & Misiune(dirr2) & "\setup.exe"
End If

End If

If Miracol(dirr) = "IN" And Activat(3) = True Then

If IN_Kit(dirr1) <> "" Then
FileCopy IN_Kit(dirr1), Cale_matrita.Text & "\Matrita\PC_World\aferent\Kit\" & Miracol(dirr) & "\" & dirr1 & "\" & dirr1 & Misiune(dirr2) & "\setup.exe"
End If

End If


If Miracol(dirr) = "AV" And Activat(4) = True Then

If AV_Kit(dirr1) <> "" Then
FileCopy AV_Kit(dirr1), Cale_matrita.Text & "\Matrita\PC_World\aferent\Kit\" & Miracol(dirr) & "\" & dirr1 & "\" & dirr1 & Misiune(dirr2) & "\setup.exe"
End If

End If

If Miracol(dirr) = "PR" And Activat(5) = True Then

If PR_Kit(dirr1) <> "" Then
FileCopy PR_Kit(dirr1), Cale_matrita.Text & "\Matrita\PC_World\aferent\Kit\" & Miracol(dirr) & "\" & dirr1 & "\" & dirr1 & Misiune(dirr2) & "\setup.exe"
End If

End If

End If ' de la dirr2 = 2




End If ' terminarea de la dirr2 = 1
Next dirr2


Next dirr1
Next dirr

Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Structura directoare = OK"
Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Copiere capturi = OK"
'Aici se umple fiecare director ... cu fisiere

director (Cale_matrita.Text & "\Matrita\PC_World\aferent\Negativ\voce")

Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Incepe copierea fisiere dinamice."
DoEvents

'---------------------- biohazard
FileCopy App.Path & "\Geneza\biohazard.gama", Cale_matrita.Text & "\Matrita\PC_World\aferent\biohazard.gama"
FileCopy App.Path & "\Geneza\biohazard.zulu", Cale_matrita.Text & "\Matrita\PC_World\aferent\biohazard.zulu"
'---------------------- biohazard

FileCopy App.Path & "\Geneza\PC.ico", Cale_matrita.Text & "\Matrita\PC_World\aferent\PC.ico"

If Activat(8) = True Then FileCopy App.Path & "\Geneza\Ajutor.htm", Cale_matrita.Text & "\Matrita\PC_World\aferent\Ajutor.htm"
If Activat(7) = True Then FileCopy App.Path & "\Geneza\Intrare.htm", Cale_matrita.Text & "\Matrita\PC_World\aferent\Intrare.htm"
If Activat(6) = True Then FileCopy App.Path & "\Geneza\Revista.htm", Cale_matrita.Text & "\Matrita\PC_World\aferent\Revista.htm"
If Activat(9) = True Then FileCopy App.Path & "\Geneza\Drivere.htm", Cale_matrita.Text & "\Matrita\PC_World\aferent\Drivere.htm"
FileCopy App.Path & "\Geneza\Internet.htm", Cale_matrita.Text & "\Matrita\PC_World\aferent\Internet.htm"
FileCopy App.Path & "\Geneza\Cruce.ani", Cale_matrita.Text & "\Matrita\PC_World\aferent\Cruce.ani"
DoEvents

FileCopy App.Path & "\Geneza\IMG\fundal4.jpg", Cale_matrita.Text & "\Matrita\PC_World\aferent\IMG\fundal4.jpg"

'8888888888888888888888888888888888888888888888888888888888888888888888888888888888
FileCopy D_Cale_text.Text, Cale_matrita.Text & "\Matrita\PC_World\aferent\IMG\fundal7.jpg"
'8888888888888888888888888888888888888888888888888888888888888888888888888888888888

FileCopy App.Path & "\Geneza\IMG\fundal.jpg", Cale_matrita.Text & "\Matrita\PC_World\aferent\IMG\fundal.jpg"
FileCopy App.Path & "\Geneza\IMG\fundal-c.gif", Cale_matrita.Text & "\Matrita\PC_World\aferent\IMG\fundal-c.gif"
FileCopy App.Path & "\Geneza\IMG\pc.gif", Cale_matrita.Text & "\Matrita\PC_World\aferent\IMG\pc.gif"
FileCopy App.Path & "\Geneza\IMG\revista.gif", Cale_matrita.Text & "\Matrita\PC_World\aferent\IMG\revista.gif"
FileCopy App.Path & "\Geneza\IMG\wallpaper.bmp", Cale_matrita.Text & "\Matrita\PC_World\aferent\IMG\wallpaper.bmp"
FileCopy App.Path & "\Geneza\IMG\pc2.GIF", Cale_matrita.Text & "\Matrita\PC_World\aferent\IMG\pc2.GIF"
FileCopy CaleFundalIntro.Text, Cale_matrita.Text & "\Matrita\PC_World\aferent\IMG\fundal_reclama.gif"

If Activat(9) = True Then
For xxc = 0 To 7

If DrivereCale(xxc).Text = "" Then
'Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Kit-ul driver-ului " & DrivereTitlu(xxc).Text & " nu poate fi copiat !"
GoTo xxzulu
End If

FileCopy DrivereCale(xxc).Text, Cale_matrita.Text & "\Matrita\PC_World\aferent\Drivere\" & numeDriver(xxc)
xxzulu:
Next xxc
End If

If Activat(10) = False Then
sunetONsiOFF = "nimic.htm"
Else
sunetONsiOFF = "S1.htm"
End If

FileCopy App.Path & "\Geneza\Negativ\Negativ.GIF", Cale_matrita.Text & "\Matrita\PC_World\aferent\Negativ\Negativ.GIF"
FileCopy App.Path & "\Geneza\Negativ\fundal.gif", Cale_matrita.Text & "\Matrita\PC_World\aferent\Negativ\fundal.gif"
FileCopy App.Path & "\Geneza\Negativ\cafeluta.gif", Cale_matrita.Text & "\Matrita\PC_World\aferent\Negativ\cafeluta.gif"
FileCopy App.Path & "\Geneza\Negativ\nimic.htm", Cale_matrita.Text & "\Matrita\PC_World\aferent\Negativ\nimic.htm"
FileCopy App.Path & "\Geneza\Negativ\S0.htm", Cale_matrita.Text & "\Matrita\PC_World\aferent\Negativ\S0.htm"
FileCopy App.Path & "\Geneza\Negativ\" & sunetONsiOFF, Cale_matrita.Text & "\Matrita\PC_World\aferent\Negativ\S1.htm"
FileCopy App.Path & "\Geneza\Negativ\Voce1.htm", Cale_matrita.Text & "\Matrita\PC_World\aferent\Negativ\Voce1.htm"
FileCopy App.Path & "\Geneza\Negativ\Voce2.htm", Cale_matrita.Text & "\Matrita\PC_World\aferent\Negativ\Voce2.htm"

Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Fisierele dinamice au fost copiate."
DoEvents
Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Incepe copierea fisierelor audio."
DoEvents
FileCopy App.Path & "\Geneza\Negativ\Revista.wav", Cale_matrita.Text & "\Matrita\PC_World\aferent\Negativ\Revista.wav"
FileCopy App.Path & "\Geneza\Negativ\Buton.wav", Cale_matrita.Text & "\Matrita\PC_World\aferent\Negativ\Buton.wav"
FileCopy App.Path & "\Geneza\Negativ\Negativ.wav", Cale_matrita.Text & "\Matrita\PC_World\aferent\Negativ\Negativ.wav"

If cale_sunet.Text = "" Then
If Activat(10) = True Then FileCopy App.Path & "\Geneza\Negativ\S_fundal.wav", Cale_matrita.Text & "\Matrita\PC_World\aferent\Negativ\S_fundal.wav"
Else
If Activat(10) = True Then FileCopy cale_sunet.Text, Cale_matrita.Text & "\Matrita\PC_World\aferent\Negativ\S_fundal.wav"
End If


FileCopy App.Path & "\Geneza\Negativ\ScurtCircuit.wav", Cale_matrita.Text & "\Matrita\PC_World\aferent\Negativ\ScurtCircuit.wav"

FileCopy App.Path & "\Geneza\Negativ\voce\afara.wav", Cale_matrita.Text & "\Matrita\PC_World\aferent\Negativ\voce\afara.wav"
FileCopy App.Path & "\Geneza\Negativ\voce\apasa.WAV", Cale_matrita.Text & "\Matrita\PC_World\aferent\Negativ\voce\apasa.WAV"
FileCopy App.Path & "\Geneza\Negativ\voce\citeste.wav", Cale_matrita.Text & "\Matrita\PC_World\aferent\Negativ\voce\citeste.wav"
FileCopy App.Path & "\Geneza\Negativ\voce\copiaza_in.wav", Cale_matrita.Text & "\Matrita\PC_World\aferent\Negativ\voce\copiaza_in.wav"
FileCopy App.Path & "\Geneza\Negativ\voce\copiere.wav", Cale_matrita.Text & "\Matrita\PC_World\aferent\Negativ\voce\copiere.wav"
FileCopy App.Path & "\Geneza\Negativ\voce\Eu.wav", Cale_matrita.Text & "\Matrita\PC_World\aferent\Negativ\voce\Eu.wav"
FileCopy App.Path & "\Geneza\Negativ\voce\instalare.wav", Cale_matrita.Text & "\Matrita\PC_World\aferent\Negativ\voce\instalare.wav"
FileCopy App.Path & "\Geneza\Negativ\voce\rulare.wav", Cale_matrita.Text & "\Matrita\PC_World\aferent\Negativ\voce\rulare.wav"
DoEvents
Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Copierea fisierelor audio a fost facuta."
Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Incepe copierea fisierelor de dependenta."

FileCopy App.Path & "\Geneza\dep\B074000D.TTF", Cale_matrita.Text & "\Matrita\PC_World\B074000D.TTF"
FileCopy App.Path & "\Geneza\dep\G034000D.TTF", Cale_matrita.Text & "\Matrita\PC_World\G034000D.TTF"
FileCopy App.Path & "\Geneza\dep\olepro32.dll", Cale_matrita.Text & "\Matrita\PC_World\olepro32.dll"
FileCopy App.Path & "\Geneza\dep\VBA6.DLL", Cale_matrita.Text & "\Matrita\PC_World\VBA6.DLL"
FileCopy App.Path & "\Geneza\dep\msvbvm60.dll", Cale_matrita.Text & "\Matrita\PC_World\msvbvm60.dll"
FileCopy App.Path & "\Geneza\dep\shdocvw.dll", Cale_matrita.Text & "\Matrita\PC_World\shdocvw.dll"
FileCopy App.Path & "\Geneza\dep\winmm.dll", Cale_matrita.Text & "\Matrita\PC_World\winmm.dll"
'Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
If Activat(16) = True Then FileCopy Ar_text.Text, Cale_matrita.Text & "\Matrita\PC_World\arhiva.xls"
'Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
DoEvents
Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Copierea fisierelor de dependenta a fost facuta."
DoEvents
Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Incepe copierea aplicatiei."
FileCopy App.Path & "\Geneza\CD.exe", Cale_matrita.Text & "\Matrita\PC_World\CD.exe"
Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "Copierea aplicatiei a fost facuta."
FileCopy App.Path & "\Geneza\AUTORUN.INF", Cale_matrita.Text & "\Matrita\AUTORUN.INF"
Compilare_CD.Text = Compilare_CD.Text & vbCrLf & "AUTORUN.INF a fost generat."

End Function

Function ScrieIn(ByVal cale As String, ByVal info As String)
ff = FreeFile
Open cale For Output As #ff
Print #ff, info
Close #ff

End Function

Private Sub Reclama_luna_Click()
If Reclama_luna.Value = 0 Then
Mare_smecherie.Visible = True
Else
Mare_smecherie.Visible = False
End If
End Sub

Private Sub Salveaza_fisier_Click()
'Salveaza_Deschide.ShowColor
'MsgBox Salveaza_Deschide.Color

On Error GoTo aa
Salveaza_Deschide.Filename = ""
Salveaza_Deschide.Filter = "Fisiere alfa (*.alfa)|*.alfa"
Salveaza_Deschide.ShowSave
sss = Salveaza_Deschide.Filename
aa:
End Sub

Private Sub Sterge_Click(Index As Integer)
'Public UT_Variabile_Nume(0 To 18) As String
'Public UT_Variabile_Explicatii(0 To 18) As String
'Public UT_Citeste_ma(0 To 18) As String

'Public UT_KitZip(0 To 18) As String
'Public UT_Kit(0 To 18) As String

'Public UT_Img1(0 To 18) As String
'Public UT_Img2(0 To 18) As String

'Public temp_KitZip(0 To 5) As String
'Public temp_Kit(0 To 5) As String
If Index = 0 Then
For vacuum = 0 To 17
UT_Variabile_Nume(vacuum) = Empty
UT_Variabile_Explicatii(vacuum) = Empty
UT_Citeste_ma(vacuum) = Empty
UT_KitZip(vacuum) = Empty
UT_Kit(vacuum) = Empty
UT_Img1(vacuum) = Empty
UT_Img2(vacuum) = Empty
ListaMare(vacuum).Caption = Empty
Next vacuum
End If


If Index = 1 Then
For vacuum = 0 To 17
MM_Variabile_Nume(vacuum) = Empty
MM_Variabile_Explicatii(vacuum) = Empty
MM_Citeste_ma(vacuum) = Empty
MM_KitZip(vacuum) = Empty
MM_Kit(vacuum) = Empty
MM_Img1(vacuum) = Empty
MM_Img2(vacuum) = Empty
ListaMareMM(vacuum).Caption = Empty
Next vacuum
End If

If Index = 2 Then
For vacuum = 0 To 17
JC_Variabile_Nume(vacuum) = Empty
JC_Variabile_Explicatii(vacuum) = Empty
JC_Citeste_ma(vacuum) = Empty
JC_KitZip(vacuum) = Empty
JC_Kit(vacuum) = Empty
JC_Img1(vacuum) = Empty
JC_Img2(vacuum) = Empty
ListaMareJC(vacuum).Caption = Empty
Next vacuum
End If


If Index = 3 Then
For vacuum = 0 To 17
IN_Variabile_Nume(vacuum) = Empty
IN_Variabile_Explicatii(vacuum) = Empty
IN_Citeste_ma(vacuum) = Empty
IN_KitZip(vacuum) = Empty
IN_Kit(vacuum) = Empty
IN_Img1(vacuum) = Empty
IN_Img2(vacuum) = Empty
ListaMareIN(vacuum).Caption = Empty
Next vacuum
End If

If Index = 4 Then
For vacuum = 0 To 17
AV_Variabile_Nume(vacuum) = Empty
AV_Variabile_Explicatii(vacuum) = Empty
AV_Citeste_ma(vacuum) = Empty
AV_KitZip(vacuum) = Empty
AV_Kit(vacuum) = Empty
AV_Img1(vacuum) = Empty
AV_Img2(vacuum) = Empty
ListaMareAV(vacuum).Caption = Empty
Next vacuum
End If


If Index = 5 Then
For vacuum = 0 To 17
PR_Variabile_Nume(vacuum) = Empty
PR_Variabile_Explicatii(vacuum) = Empty
PR_Citeste_ma(vacuum) = Empty
PR_KitZip(vacuum) = Empty
PR_Kit(vacuum) = Empty
PR_Img1(vacuum) = Empty
PR_Img2(vacuum) = Empty
ListaMarePR(vacuum).Caption = Empty
Next vacuum
End If

Titlu(Index).Text = ""
Explicatie(Index).Text = ""
Citeste_Text(Index).Text = ""
IMica(Index).Text = ""
IMare(Index).Text = ""
calea(Index).Text = ""
cale2(Index).Text = ""

End Sub

Private Sub StergeDriver_Click()
For fgh = 0 To 7
DrivereTitlu(fgh).Text = ""
DrivereCale(fgh).Text = ""
DrivereExplicatii(fgh).Text = ""


DrivereTitlu(fgh).BackColor = &H0&
DrivereCale(fgh).BackColor = &H0&
DrivereExplicatii(fgh).BackColor = &H0&

Next fgh
End Sub

Private Sub sunetul_Click()
On Error GoTo aa
sunetEu.Filename = ""
sunetEu.Filter = "Fisiere wav (*.wav)|*.wav"
sunetEu.ShowOpen
cale_sunet.Text = sunetEu.Filename
aa:
End Sub

Private Sub Titlu_GotFocus(Index As Integer)
Titlu(Index).BackColor = &H0&
End Sub

Private Sub xls_ul_Click()
On Error Resume Next
If Ar_text.Text = "" Then
MsgBox "Nu ai ales calea spre fisierul XLS !!!"
Exit Sub
End If
ShellExecute hwnd, "open", Ar_text.Text, vbNullString, vbNullString, conSwNormal
End Sub

Private Sub zi_mai_Click(Index As Integer)
On Error Resume Next

If cale_sunet.Text = "" Then
MsgBox "Nu ai ales calea spre fisierul WAV !!!"
Exit Sub
End If

If Index = 0 Then
Call ScrieIn(App.Path & "\x.htm", "<bgsound src=" & Chr(34) & cale_sunet.Text & Chr(34) & " loop=" & Chr(34) & "infinite" & Chr(34) & ">")
Else
Call ScrieIn(App.Path & "\x.htm", "")
End If

Sunetele.Navigate (App.Path & "\x.htm")
End Sub
