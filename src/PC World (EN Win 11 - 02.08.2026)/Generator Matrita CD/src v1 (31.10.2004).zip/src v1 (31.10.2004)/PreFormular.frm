VERSION 5.00
Begin VB.Form PreFormular 
   Caption         =   "PreFormular"
   ClientHeight    =   8265
   ClientLeft      =   60
   ClientTop       =   450
   ClientWidth     =   11280
   Icon            =   "PreFormular.frx":0000
   LinkTopic       =   "Form1"
   Picture         =   "PreFormular.frx":0D2A
   ScaleHeight     =   551
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   752
   StartUpPosition =   2  'CenterScreen
   Begin VB.PictureBox Bara_copiere 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      BackColor       =   &H00004040&
      ForeColor       =   &H80000008&
      Height          =   375
      Left            =   6360
      Picture         =   "PreFormular.frx":31071
      ScaleHeight     =   23
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   255
      TabIndex        =   1
      Top             =   7560
      Visible         =   0   'False
      Width           =   3855
   End
   Begin GenerareMatrita.Listare_Tip_GIF Giful 
      Height          =   2895
      Left            =   6600
      Top             =   3000
      Width           =   3255
      _ExtentX        =   5741
      _ExtentY        =   5106
      AutoPlay        =   -1  'True
      BackColor       =   1121794
   End
   Begin GenerareMatrita.Buton_3D_General Butoane_Coordonate 
      Height          =   375
      Index           =   0
      Left            =   720
      TabIndex        =   2
      Top             =   720
      Width           =   1215
      _ExtentX        =   2143
      _ExtentY        =   661
      Caption         =   "Utilitare"
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "GlaserSteD"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin GenerareMatrita.Buton_3D_General Butoane_Coordonate 
      Height          =   375
      Index           =   1
      Left            =   2040
      TabIndex        =   3
      Top             =   720
      Width           =   1215
      _ExtentX        =   2143
      _ExtentY        =   661
      Caption         =   "Multimedia"
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "GlaserSteD"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin GenerareMatrita.Buton_3D_General Butoane_Coordonate 
      Height          =   375
      Index           =   2
      Left            =   3360
      TabIndex        =   4
      Top             =   720
      Width           =   1215
      _ExtentX        =   2143
      _ExtentY        =   661
      Caption         =   "Jocuri"
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "GlaserSteD"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin GenerareMatrita.Buton_3D_General Butoane_Coordonate 
      Height          =   375
      Index           =   3
      Left            =   4680
      TabIndex        =   5
      Top             =   720
      Width           =   1215
      _ExtentX        =   2143
      _ExtentY        =   661
      Caption         =   "Internet"
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "GlaserSteD"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin GenerareMatrita.Buton_3D_General Butoane_Coordonate 
      Height          =   375
      Index           =   4
      Left            =   6000
      TabIndex        =   6
      Top             =   720
      Width           =   1215
      _ExtentX        =   2143
      _ExtentY        =   661
      Caption         =   "Antivirus"
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "GlaserSteD"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin GenerareMatrita.Buton_3D_General Butoane_Coordonate 
      Height          =   375
      Index           =   5
      Left            =   7320
      TabIndex        =   7
      Top             =   720
      Width           =   1335
      _ExtentX        =   2355
      _ExtentY        =   661
      Caption         =   "Permanente"
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "GlaserSteD"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin GenerareMatrita.Buton_3D_General Butoane_Coordonate 
      Height          =   255
      Index           =   6
      Left            =   1680
      TabIndex        =   8
      Top             =   7560
      Width           =   2415
      _ExtentX        =   4260
      _ExtentY        =   450
      Caption         =   "Revista"
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "German"
         Size            =   9
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin GenerareMatrita.Buton_3D_General Butoane_Coordonate 
      Height          =   375
      Index           =   19
      Left            =   10080
      TabIndex        =   9
      Top             =   720
      Width           =   1095
      _ExtentX        =   1931
      _ExtentY        =   661
      Caption         =   "Despre"
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "GlaserSteD"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin GenerareMatrita.Buton_3D_General Butoane_Coordonate 
      Height          =   375
      Index           =   12
      Left            =   360
      TabIndex        =   10
      Top             =   4800
      Width           =   1335
      _ExtentX        =   2355
      _ExtentY        =   661
      Caption         =   "Instaleaza"
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "BankScrD"
         Size            =   15.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin GenerareMatrita.Buton_3D_General Butoane_Coordonate 
      Height          =   375
      Index           =   13
      Left            =   1680
      TabIndex        =   11
      Top             =   4800
      Width           =   1215
      _ExtentX        =   2143
      _ExtentY        =   661
      Caption         =   "Copiaza"
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "BankScrD"
         Size            =   15.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin GenerareMatrita.Buton_3D_General Butoane_Coordonate 
      Height          =   375
      Index           =   14
      Left            =   2880
      TabIndex        =   12
      Top             =   4800
      Width           =   1215
      _ExtentX        =   2143
      _ExtentY        =   661
      Caption         =   "Ruleaza"
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "BankScrD"
         Size            =   15.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin GenerareMatrita.Buton_3D_General Butoane_Coordonate 
      Height          =   375
      Index           =   15
      Left            =   4080
      TabIndex        =   13
      Top             =   4800
      Width           =   1215
      _ExtentX        =   2143
      _ExtentY        =   661
      Caption         =   "Citeste-ma"
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "BankScrD"
         Size            =   15.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin GenerareMatrita.Buton_3D_General Butoane_Coordonate 
      Height          =   495
      Index           =   11
      Left            =   3840
      TabIndex        =   14
      Top             =   6120
      Width           =   1575
      _ExtentX        =   7011
      _ExtentY        =   450
      Caption         =   "Internet"
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "German"
         Size            =   9
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin GenerareMatrita.Buton_3D_General Butoane_Coordonate 
      Height          =   1095
      Index           =   10
      Left            =   480
      TabIndex        =   15
      Top             =   6120
      Width           =   1095
      _ExtentX        =   1931
      _ExtentY        =   1931
      Caption         =   "Sunet"
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "German"
         Size            =   9
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin GenerareMatrita.Buton_3D_General Butoane_Coordonate 
      Height          =   375
      Index           =   66
      Left            =   3720
      TabIndex        =   16
      Top             =   1320
      Width           =   1695
      _ExtentX        =   2990
      _ExtentY        =   661
      Caption         =   "Copiaza in ..."
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "GlaserSteD"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin GenerareMatrita.Buton_3D_General Butoane_Coordonate 
      Height          =   255
      Index           =   7
      Left            =   1920
      TabIndex        =   17
      Top             =   7200
      Width           =   1695
      _ExtentX        =   2990
      _ExtentY        =   450
      Caption         =   "Intro"
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "German"
         Size            =   9
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin GenerareMatrita.Buton_3D_General Butoane_Coordonate 
      Height          =   255
      Index           =   8
      Left            =   960
      TabIndex        =   18
      Top             =   7920
      Width           =   3855
      _ExtentX        =   6800
      _ExtentY        =   450
      Caption         =   "Ajutor"
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "German"
         Size            =   9
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin GenerareMatrita.Buton_3D_General Butoane_Coordonate 
      Height          =   375
      Index           =   9
      Left            =   8760
      TabIndex        =   19
      Top             =   720
      Width           =   1215
      _ExtentX        =   2143
      _ExtentY        =   661
      Caption         =   "Drivere"
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "GlaserSteD"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin GenerareMatrita.Buton_3D_General Butoane_Coordonate 
      Height          =   255
      Index           =   16
      Left            =   6240
      TabIndex        =   20
      Top             =   240
      Width           =   3495
      _ExtentX        =   6165
      _ExtentY        =   450
      Caption         =   "Arhiva"
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "German"
         Size            =   9
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin GenerareMatrita.Buton_3D_General Butoane_Coordonate 
      Height          =   255
      Index           =   18
      Left            =   10320
      TabIndex        =   21
      Top             =   240
      Width           =   255
      _ExtentX        =   450
      _ExtentY        =   450
      Caption         =   "X"
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin GenerareMatrita.Buton_3D_General Butoane_Coordonate 
      Height          =   255
      Index           =   17
      Left            =   9960
      TabIndex        =   22
      Top             =   240
      Width           =   255
      _ExtentX        =   450
      _ExtentY        =   450
      Caption         =   "_"
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin VB.Label ButonMareMSG 
      BackStyle       =   0  'Transparent
      Caption         =   "ON"
      BeginProperty Font 
         Name            =   "Small Fonts"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   255
      Index           =   0
      Left            =   4800
      TabIndex        =   31
      Top             =   5880
      Width           =   375
   End
   Begin VB.Label ButonMareMSG 
      BackStyle       =   0  'Transparent
      Caption         =   "OFF"
      BeginProperty Font 
         Name            =   "Small Fonts"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00808080&
      Height          =   255
      Index           =   1
      Left            =   4800
      TabIndex        =   30
      Top             =   6600
      Width           =   495
   End
   Begin VB.Image Pe_web 
      Height          =   525
      Left            =   6840
      Picture         =   "PreFormular.frx":31FE8
      Top             =   7500
      Width           =   3075
   End
   Begin VB.Image Dll_ul 
      Height          =   360
      Left            =   240
      Picture         =   "PreFormular.frx":32AF9
      Top             =   720
      Width           =   360
   End
   Begin VB.Label Sectiune 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "Sectiune - Intro"
      BeginProperty Font 
         Name            =   "German"
         Size            =   9
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H0000C000&
      Height          =   255
      Index           =   1
      Left            =   6960
      TabIndex        =   29
      Top             =   2520
      Width           =   2535
   End
   Begin VB.Label Sectiune 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "Captura"
      BeginProperty Font 
         Name            =   "German"
         Size            =   9
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00008000&
      Height          =   255
      Index           =   4
      Left            =   7440
      TabIndex        =   28
      Top             =   2280
      Width           =   1695
   End
   Begin VB.Label Eu_la_suta 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "0 %"
      BeginProperty Font 
         Name            =   "German"
         Size            =   9
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H0000FF00&
      Height          =   255
      Left            =   7800
      TabIndex        =   27
      Top             =   2760
      Visible         =   0   'False
      Width           =   855
   End
   Begin VB.Label Sunet_Status 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "Sunet - ON"
      BeginProperty Font 
         Name            =   "German"
         Size            =   9
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H0000FF00&
      Height          =   255
      Left            =   7320
      TabIndex        =   26
      Top             =   6000
      Visible         =   0   'False
      Width           =   1815
   End
   Begin VB.Label Bara_principal 
      BackStyle       =   0  'Transparent
      Caption         =   " Aproximare  vizuala  !"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   18
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   495
      Left            =   840
      TabIndex        =   25
      Top             =   120
      Width           =   4575
   End
   Begin VB.Label Da_domnule 
      BackStyle       =   0  'Transparent
      Caption         =   "Calea spre directorul in care se copiaza kit-ul"
      ForeColor       =   &H00C0C0C0&
      Height          =   255
      Left            =   5760
      TabIndex        =   24
      Top             =   1440
      Width           =   4935
   End
   Begin VB.Label Sectiune 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "Explicatii"
      BeginProperty Font 
         Name            =   "BrushScrD"
         Size            =   14.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   375
      Index           =   3
      Left            =   2160
      TabIndex        =   23
      Top             =   1680
      Width           =   1335
   End
   Begin VB.Label InformatiiPrograme 
      BackStyle       =   0  'Transparent
      Caption         =   "Explicatii ..."
      Height          =   2295
      Left            =   600
      TabIndex        =   0
      Top             =   2160
      Width           =   4455
   End
End
Attribute VB_Name = "PreFormular"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False


Private Sub Form_Load()
For q = 0 To 18

If Activat(q) = False Then
PreFormular.Butoane_Coordonate(q).Visible = False
End If

If Activat(q) = True Then
PreFormular.Butoane_Coordonate(q).Visible = True
End If

Next q




LungimeTotala = (Dll_ul.Left + Dll_ul.Width) - (Butoane_Coordonate(19).Left + Butoane_Coordonate(19).Width)



End Sub

Private Sub Form_Unload(Cancel As Integer)
Unload Captura
End Sub

Private Sub Giful_Click()
Captura.Show
End Sub
