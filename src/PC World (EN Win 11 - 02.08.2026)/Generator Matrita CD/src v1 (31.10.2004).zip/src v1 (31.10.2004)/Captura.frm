VERSION 5.00
Begin VB.Form CapturaEU 
   BackColor       =   &H00000000&
   Caption         =   "Captura"
   ClientHeight    =   5325
   ClientLeft      =   60
   ClientTop       =   450
   ClientWidth     =   6225
   Icon            =   "Captura.frx":0000
   LinkTopic       =   "Form2"
   ScaleHeight     =   5325
   ScaleWidth      =   6225
   StartUpPosition =   2  'CenterScreen
   Begin VB.TextBox Selecteaza_cale 
      Appearance      =   0  'Flat
      BackColor       =   &H00000040&
      ForeColor       =   &H000000FF&
      Height          =   285
      Left            =   1440
      Locked          =   -1  'True
      TabIndex        =   7
      Text            =   "C:\"
      Top             =   3480
      Width           =   4095
   End
   Begin VB.CommandButton Ok 
      Caption         =   "Salveaza"
      Height          =   255
      Left            =   120
      TabIndex        =   5
      Top             =   3480
      Width           =   1335
   End
   Begin VB.CommandButton Captureaza 
      Caption         =   "Captureaza"
      Height          =   375
      Left            =   3840
      TabIndex        =   4
      Top             =   120
      Width           =   1695
   End
   Begin VB.PictureBox Picture1 
      AutoSize        =   -1  'True
      Height          =   2895
      Left            =   120
      ScaleHeight     =   2835
      ScaleWidth      =   3555
      TabIndex        =   3
      Top             =   6000
      Visible         =   0   'False
      Width           =   3615
   End
   Begin VB.PictureBox Picture2 
      AutoSize        =   -1  'True
      Height          =   2895
      Left            =   3840
      ScaleHeight     =   2835
      ScaleWidth      =   3555
      TabIndex        =   2
      Top             =   6000
      Visible         =   0   'False
      Width           =   3615
   End
   Begin VB.CommandButton Redimensioneaza 
      Caption         =   "Redimensioneaza"
      Height          =   375
      Left            =   7800
      TabIndex        =   1
      Top             =   5160
      Visible         =   0   'False
      Width           =   1695
   End
   Begin VB.CommandButton Re_Pixelizare 
      Caption         =   "Blur"
      Height          =   375
      Left            =   7800
      TabIndex        =   0
      Top             =   4680
      Visible         =   0   'False
      Width           =   1695
   End
   Begin VB.Label Label1 
      BackStyle       =   0  'Transparent
      Caption         =   $"Captura.frx":0ECA
      ForeColor       =   &H000000FF&
      Height          =   1095
      Left            =   120
      TabIndex        =   6
      Top             =   3960
      Width           =   5415
   End
   Begin VB.Image Image3 
      Height          =   1230
      Left            =   4080
      MouseIcon       =   "Captura.frx":1032
      MousePointer    =   99  'Custom
      Picture         =   "Captura.frx":18FC
      ToolTipText     =   "Iesire"
      Top             =   1320
      Width           =   1320
   End
   Begin VB.Image Image1 
      Height          =   3255
      Left            =   240
      Stretch         =   -1  'True
      Top             =   7680
      Visible         =   0   'False
      Width           =   3615
   End
   Begin VB.Image Image2 
      Height          =   3255
      Left            =   120
      Stretch         =   -1  'True
      Top             =   120
      Width           =   3615
   End
   Begin VB.Shape bordura 
      BackColor       =   &H00808080&
      BorderColor     =   &H000000FF&
      Height          =   3255
      Left            =   120
      Top             =   120
      Width           =   3615
   End
   Begin VB.Shape bordura2 
      BackColor       =   &H00808080&
      BorderColor     =   &H00000000&
      Height          =   3255
      Left            =   240
      Top             =   7680
      Visible         =   0   'False
      Width           =   3615
   End
End
Attribute VB_Name = "CapturaEU"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'Option Explicit
Option Base 0

Private Type PALETTEENTRY
   peRed As Byte
   peGreen As Byte
   peBlue As Byte
   peFlags As Byte
End Type

Private Type LOGPALETTE
   palVersion As Integer
   palNumEntries As Integer
   palPalEntry(255) As PALETTEENTRY  ' Enough for 256 colors.
End Type

Private Type GUID
   Data1 As Long
   Data2 As Integer
   Data3 As Integer
   Data4(7) As Byte
End Type

Private Const RASTERCAPS As Long = 38
Private Const RC_PALETTE As Long = &H100
Private Const SIZEPALETTE As Long = 104

Private Type RECT
   Left As Long
   Top As Long
   Right As Long
   Bottom As Long
End Type

Private Declare Function CreateCompatibleDC Lib "gdi32" (ByVal hDC As Long) As Long
Private Declare Function CreateCompatibleBitmap Lib "gdi32" (ByVal hDC As Long, ByVal nWidth As Long, ByVal nHeight As Long) As Long
Private Declare Function GetDeviceCaps Lib "gdi32" (ByVal hDC As Long, ByVal iCapabilitiy As Long) As Long
Private Declare Function GetSystemPaletteEntries Lib "gdi32" (ByVal hDC As Long, ByVal wStartIndex As Long, ByVal wNumEntries As Long, lpPaletteEntries As PALETTEENTRY) As Long
Private Declare Function CreatePalette Lib "gdi32" (lpLogPalette As LOGPALETTE) As Long
Private Declare Function SelectObject Lib "gdi32" (ByVal hDC As Long, ByVal hObject As Long) As Long
Private Declare Function BitBlt Lib "gdi32" (ByVal hDCDest As Long, ByVal XDest As Long, ByVal YDest As Long, ByVal nWidth As Long, ByVal nHeight As Long, ByVal hDCSrc As Long, ByVal xSrc As Long, ByVal ySrc As Long, ByVal dwRop As Long) As Long
Private Declare Function DeleteDC Lib "gdi32" (ByVal hDC As Long) As Long
Private Declare Function GetForegroundWindow Lib "user32" () As Long
Private Declare Function SelectPalette Lib "gdi32" (ByVal hDC As Long, ByVal hPalette As Long, ByVal bForceBackground As Long) As Long
Private Declare Function RealizePalette Lib "gdi32" (ByVal hDC As Long) As Long
Private Declare Function GetWindowDC Lib "user32" (ByVal hWnd As Long) As Long
Private Declare Function GetDC Lib "user32" (ByVal hWnd As Long) As Long
Private Declare Function GetWindowRect Lib "user32" (ByVal hWnd As Long, lpRect As RECT) As Long
Private Declare Function ReleaseDC Lib "user32" (ByVal hWnd As Long, ByVal hDC As Long) As Long
Private Declare Function GetDesktopWindow Lib "user32" () As Long

Private Type PicBmp
   Size As Long
   Type As Long
   hBmp As Long
   hPal As Long
   Reserved As Long
End Type
'**********************************************************************************************
Private Declare Function OleCreatePictureIndirect Lib "olepro32.dll" (PicDesc As PicBmp, RefIID As GUID, ByVal fPictureOwnsHandle As Long, iPic As IPicture) As Long
Private Declare Function VarPtrArray Lib "msvbvm50.dll" _
        Alias "VarPtr" (Ptr() As Any) As Long
        
Private Declare Sub CopyMemory Lib "kernel32" Alias _
        "RtlMoveMemory" (pDst As Any, pSrc As Any, ByVal _
        ByteLen As Long)
        

Private Declare Function GetObject Lib "gdi32" Alias _
        "GetObjectA" (ByVal hObject As Long, ByVal nCount _
        As Long, lpObject As Any) As Long

Private Type SAFEARRAYBOUND
  cElements As Long
  lLbound As Long
End Type

Private Type SAFEARRAY1D
  cDims As Integer
  fFeatures As Integer
  cbElements As Long
  cLocks As Long
  pvData As Long
  Bounds(0 To 0) As SAFEARRAYBOUND
End Type

Private Type SAFEARRAY2D
  cDims As Integer
  fFeatures As Integer
  cbElements As Long
  cLocks As Long
  pvData As Long
  Bounds(0 To 1) As SAFEARRAYBOUND
End Type

Private Type BITMAP
  bmType As Long
  bmWidth As Long
  bmHeight As Long
  bmWidthBytes As Long
  bmPlanes As Integer
  bmBitsPixel As Integer
  bmBits As Long
End Type

Private Const SRCCOPY = &HCC0020

Dim aa As Long, bb As Long
'**********************************************************************************************

Private iW As Long
Private iH As Long
Private iWMax As Long
Private iHMax As Long
Private zAspect As Single

Private w As Long
Private h As Long


Dim LungimeQ As Variant
Dim InaltimeQ As Variant
'**********************************************************************************************

Private Sub DoBlur(bPic As PictureBox)
   Dim Pict() As Byte
   Dim av As Long
   Dim Ptr As Long
   Dim safe As SAFEARRAY1D, bmp As BITMAP
   
    Call GetObject(bPic.Picture, Len(bmp), bmp)
    With safe
      .cbElements = 1
      .cDims = 1
      .Bounds(0).lLbound = 0
      .Bounds(0).cElements = bmp.bmHeight * bmp.bmWidthBytes
      .pvData = bmp.bmBits
    End With
    Call CopyMemory(ByVal VarPtrArray(Pict), VarPtr(safe), 4)
    
    On Error Resume Next

    'Blur algo
    Ptr = bmp.bmWidthBytes + 3
    For aa = 1 To bmp.bmHeight - 3
      For bb = 0 To bmp.bmWidthBytes
        Ptr = Ptr + 1
        av = Pict(Ptr - bmp.bmWidthBytes)
        av = av + Pict(Ptr - 3)
        av = av + Pict(Ptr + 3)
        av = av + Pict(Ptr + bmp.bmWidthBytes)
        Pict(Ptr) = av \ 4
      Next bb
    Next aa

    Call CopyMemory(ByVal VarPtrArray(Pict), 0&, 4)
End Sub



Private Sub Captureaza_Click()
Image2.Top = bordura.Top
Image2.Left = bordura.Left
Image2.Width = bordura.Width
Image2.Height = bordura.Height


Image1.Top = bordura2.Top
Image1.Left = bordura2.Left
Image1.Width = bordura2.Width
Image1.Height = bordura2.Height

    MsgBox "Captureaza dupa 2 secunde"
    ' Wait for two seconds.
    Dim EndTime As Date
    EndTime = DateAdd("s", 2, Now)
    Do Until Now > EndTime
       DoEvents
       Loop
    Set Picture1.Picture = CaptureActiveWindow()
    ' Set focus back to form.
    Me.SetFocus

LungimeQ = Picture1.Width
InaltimeQ = Picture1.Height

Redimensioneaza_Click


  Picture2.Picture = Picture1.Image
  Image1.Picture = Picture1.Image
  Image2.Picture = Picture2.Image

  Call SavePicture(Picture2.Picture, App.Path & "\Temp.BMP")
  Picture2.Picture = LoadPicture(App.Path & "\Temp.BMP")
  
  Call DoBlur(Picture2)
  Image1.Picture = Picture1.Image
  Image2.Picture = Picture2.Image

End Sub

Public Function CaptureActiveWindow() As Picture

    Dim hWndActive As Long
    Dim r As Long
    
    Dim RectActive As RECT
    
    ' Get a handle to the active/foreground window.
    hWndActive = GetForegroundWindow()
    
    ' Get the dimensions of the window.
    r = GetWindowRect(hWndActive, RectActive)
    
    ' Call CaptureWindow to capture the active window given its
    ' handle and return the Resulting Picture object.
    Set CaptureActiveWindow = CaptureWindow(hWndActive, False, 0, 0, RectActive.Right - RectActive.Left, RectActive.Bottom - RectActive.Top)
End Function


Public Function CaptureWindow(ByVal hWndSrc As Long, ByVal Client As Boolean, ByVal LeftSrc As Long, ByVal TopSrc As Long, ByVal WidthSrc As Long, ByVal HeightSrc As Long) As Picture

  Dim hDCMemory As Long
  Dim hBmp As Long
  Dim hBmpPrev As Long
  Dim r As Long
  Dim hDCSrc As Long
  Dim hPal As Long
  Dim hPalPrev As Long
  Dim RasterCapsScrn As Long
  Dim HasPaletteScrn As Long
  Dim PaletteSizeScrn As Long
  Dim LogPal As LOGPALETTE

   ' Depending on the value of Client get the proper device context.
   If Client Then
      hDCSrc = GetDC(hWndSrc) ' Get device context for client area.
   Else
      hDCSrc = GetWindowDC(hWndSrc) ' Get device context for entire
                                    ' window.
   End If

   ' Create a memory device context for the copy process.
   hDCMemory = CreateCompatibleDC(hDCSrc)
   ' Create a bitmap and place it in the memory DC.
   hBmp = CreateCompatibleBitmap(hDCSrc, WidthSrc, HeightSrc)
   hBmpPrev = SelectObject(hDCMemory, hBmp)

   ' Get screen properties.
   RasterCapsScrn = GetDeviceCaps(hDCSrc, RASTERCAPS) ' Raster
                                                      ' capabilities.
   HasPaletteScrn = RasterCapsScrn And RC_PALETTE       ' Palette
                                                        ' support.
   PaletteSizeScrn = GetDeviceCaps(hDCSrc, SIZEPALETTE) ' Size of
                                                        ' palette.

   ' If the screen has a palette make a copy and realize it.
   If HasPaletteScrn And (PaletteSizeScrn = 256) Then
      ' Create a copy of the system palette.
      LogPal.palVersion = &H300
      LogPal.palNumEntries = 256
      r = GetSystemPaletteEntries(hDCSrc, 0, 256, LogPal.palPalEntry(0))
      hPal = CreatePalette(LogPal)
      ' Select the new palette into the memory DC and realize it.
      hPalPrev = SelectPalette(hDCMemory, hPal, 0)
      r = RealizePalette(hDCMemory)
   End If

   ' Copy the on-screen image into the memory DC.
   r = BitBlt(hDCMemory, 0, 0, WidthSrc, HeightSrc, hDCSrc, LeftSrc, TopSrc, vbSrcCopy)

' Remove the new copy of the  on-screen image.
   hBmp = SelectObject(hDCMemory, hBmpPrev)

   ' If the screen has a palette get back the palette that was
   ' selected in previously.
   If HasPaletteScrn And (PaletteSizeScrn = 256) Then
      hPal = SelectPalette(hDCMemory, hPalPrev, 0)
   End If

   ' Release the device context resources back to the system.
   r = DeleteDC(hDCMemory)
   r = ReleaseDC(hWndSrc, hDCSrc)

   ' Call CreateBitmapPicture to create a picture object from the
   ' bitmap and palette handles. Then return the resulting picture
   ' object.
   Set CaptureWindow = CreateBitmapPicture(hBmp, hPal)
End Function

Public Function CreateBitmapPicture(ByVal hBmp As Long, ByVal hPal As Long) As Picture
  Dim r As Long

   Dim Pic As PicBmp
   ' IPicture requires a reference to "Standard OLE Types."
   Dim iPic As IPicture
   Dim IID_IDispatch As GUID

   ' Fill in with IDispatch Interface ID.
   With IID_IDispatch
      .Data1 = &H20400
      .Data4(0) = &HC0
      .Data4(7) = &H46
   End With

   ' Fill Pic with necessary parts.
   With Pic
      .Size = Len(Pic)          ' Length of structure.
      .Type = vbPicTypeBitmap   ' Type of Picture (bitmap).
      .hBmp = hBmp              ' Handle to bitmap.
      .hPal = hPal              ' Handle to palette (may be null).
   End With

   ' Create Picture object.
   r = OleCreatePictureIndirect(Pic, IID_IDispatch, 1, iPic)

   ' Return the new Picture object.
   Set CreateBitmapPicture = iPic
End Function



Private Sub Ok_Click()
Dim sRet As String
On Error Resume Next

mBFF.InitFolder = "c:\"
sRet = mBFF.BrowseForFolder(Me.hWnd, "Selecteaza directorul in care va fi salvata CAPTURA ...")

If (sRet <> vbNullString) Then
Selecteaza_cale.Text = sRet

xxzulu = 0
3:
If FileExist(Selecteaza_cale.Text & "\" & xxzulu & ".bmp") Then
xxzulu = xxzulu + 1
GoTo 3
End If

Call SavePicture(Picture1.Picture, Selecteaza_cale.Text & "\" & xxzulu & ".bmp")
End If

'Geneza.Pro_imagine(CapturaSectiune).Picture = LoadPicture(App.Path & "\" & CapturaProgram & ".bmp")
'Geneza.u(CapturaSectiune).Text = "Captura incarcata"
'Me.Hide
End Sub

Public Function FileExist(aFile As String) As Boolean
On Error GoTo 23

If aFile = "" Then
FileExist = False
Exit Function
End If

If Dir$(aFile) = "" Then
If Dir$(aFile, vbHidden) = "" Then
FileExist = False
Else
FileExist = True
End If
Else
FileExist = True
End If
Exit Function
23:
FileExist = False
'KillPC
End Function


Private Sub Re_Pixelizare_Click()
Call SavePicture(Picture2.Picture, App.Path & "\Temp.BMP")
  Picture2.Picture = LoadPicture(App.Path & "\Temp.BMP")
  
  Call DoBlur(Picture2)
  Image1.Picture = Picture1.Image
  Image2.Picture = Picture2.Image
End Sub

Private Sub Redimensioneaza_Click()
iWMax = bordura.Width
iHMax = bordura.Height
  w = LungimeQ
  h = InaltimeQ

   zAspect = w / h
   If w <= iWMax Then
      iW = w
      iH = CLng(iW / zAspect)
   Else  ' Picture1.Width > iWMax
      iW = iWMax
      iH = CLng(iWMax / zAspect)
   End If
   If iH > iHMax Then
      iH = iHMax
      iW = CLng(iH * zAspect)
   End If
   
   Image1.Width = iW
   Image1.Height = iH
   Image2.Width = iW
   Image2.Height = iH
   'Imagine_mica.Picture = PICIN.Picture  'LoadPicture(FileSpec$)
   Image2.Refresh
   Image2.Refresh



Image1.Left = bordura2.Left + (bordura2.Width / 2) - (Image1.Width / 2)
Image1.Top = bordura2.Top + (bordura2.Height / 2) - (Image1.Height / 2)

Image2.Left = bordura.Left + (bordura.Width / 2) - (Image2.Width / 2)
Image2.Top = bordura.Top + (bordura.Height / 2) - (Image2.Height / 2)
End Sub


