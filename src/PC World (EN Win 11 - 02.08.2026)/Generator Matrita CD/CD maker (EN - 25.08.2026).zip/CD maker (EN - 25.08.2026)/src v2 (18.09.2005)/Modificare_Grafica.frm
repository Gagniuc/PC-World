VERSION 5.00
Begin VB.Form Modificare_Grafica 
   BorderStyle     =   0  'None
   Caption         =   "Form1"
   ClientHeight    =   8310
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   11325
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   Picture         =   "Modificare_Grafica.frx":0000
   ScaleHeight     =   554
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   755
   ShowInTaskbar   =   0   'False
   StartUpPosition =   3  'Windows Default
   Begin VB.PictureBox Bara_copiere 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      BackColor       =   &H00004040&
      ForeColor       =   &H80000008&
      Height          =   375
      Left            =   6360
      Picture         =   "Modificare_Grafica.frx":30347
      ScaleHeight     =   23
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   255
      TabIndex        =   12
      Top             =   7560
      Visible         =   0   'False
      Width           =   3855
   End
   Begin GenerareMatrita.Listare_Tip_GIF Listare_Tip_GIF1 
      Height          =   2775
      Left            =   6600
      Top             =   3000
      Width           =   3375
      _ExtentX        =   5953
      _ExtentY        =   4895
      BackColor       =   1121794
   End
   Begin GenerareMatrita.Buton_3D_General Butoane_Coordonate 
      Height          =   375
      Index           =   0
      Left            =   720
      TabIndex        =   0
      Top             =   720
      Width           =   1455
      _ExtentX        =   2566
      _ExtentY        =   661
      Caption         =   "Utilities"
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "GlaserSteD"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin GenerareMatrita.Buton_3D_General Butoane_Coordonate 
      Height          =   375
      Index           =   1
      Left            =   2280
      TabIndex        =   1
      Top             =   720
      Width           =   1455
      _ExtentX        =   2566
      _ExtentY        =   661
      Caption         =   "Multimedia"
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "GlaserSteD"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin GenerareMatrita.Buton_3D_General Butoane_Coordonate 
      Height          =   375
      Index           =   2
      Left            =   3840
      TabIndex        =   2
      Top             =   720
      Width           =   1455
      _ExtentX        =   2566
      _ExtentY        =   661
      Caption         =   "Games"
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "GlaserSteD"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin GenerareMatrita.Buton_3D_General Butoane_Coordonate 
      Height          =   375
      Index           =   3
      Left            =   5400
      TabIndex        =   3
      Top             =   720
      Width           =   1455
      _ExtentX        =   2566
      _ExtentY        =   661
      Caption         =   "Internet"
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "GlaserSteD"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin GenerareMatrita.Buton_3D_General Butoane_Coordonate 
      Height          =   375
      Index           =   4
      Left            =   6960
      TabIndex        =   4
      Top             =   720
      Width           =   1455
      _ExtentX        =   2566
      _ExtentY        =   661
      Caption         =   "Antivirus"
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "GlaserSteD"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin GenerareMatrita.Buton_3D_General Butoane_Coordonate 
      Height          =   375
      Index           =   5
      Left            =   8520
      TabIndex        =   5
      Top             =   720
      Width           =   1455
      _ExtentX        =   2566
      _ExtentY        =   661
      Caption         =   "Permanent"
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "GlaserSteD"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin GenerareMatrita.Buton_3D_General Butoane_Coordonate 
      Height          =   255
      Index           =   6
      Left            =   120
      TabIndex        =   6
      Top             =   6840
      Width           =   3375
      _ExtentX        =   5953
      _ExtentY        =   450
      Caption         =   "Magazine"
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "GlaserSteD"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin GenerareMatrita.Buton_3D_General Butoane_Coordonate 
      Height          =   375
      Index           =   7
      Left            =   10080
      TabIndex        =   14
      Top             =   720
      Width           =   1095
      _ExtentX        =   1931
      _ExtentY        =   661
      Caption         =   "About"
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "GlaserSteD"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin GenerareMatrita.Buton_3D_General Butoane_Coordonate 
      Height          =   375
      Index           =   8
      Left            =   360
      TabIndex        =   15
      Top             =   4800
      Width           =   1335
      _ExtentX        =   2355
      _ExtentY        =   661
      Caption         =   "Install"
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "BankScrD"
         Size            =   15.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin GenerareMatrita.Buton_3D_General Butoane_Coordonate 
      Height          =   375
      Index           =   9
      Left            =   1680
      TabIndex        =   16
      Top             =   4800
      Width           =   1215
      _ExtentX        =   2143
      _ExtentY        =   661
      Caption         =   "Copy"
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "BankScrD"
         Size            =   15.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin GenerareMatrita.Buton_3D_General Butoane_Coordonate 
      Height          =   375
      Index           =   10
      Left            =   2880
      TabIndex        =   17
      Top             =   4800
      Width           =   1215
      _ExtentX        =   2143
      _ExtentY        =   661
      Caption         =   "Run"
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "BankScrD"
         Size            =   15.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin GenerareMatrita.Buton_3D_General Butoane_Coordonate 
      Height          =   375
      Index           =   11
      Left            =   4080
      TabIndex        =   18
      Top             =   4800
      Width           =   1215
      _ExtentX        =   2143
      _ExtentY        =   661
      Caption         =   "Read me"
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "BankScrD"
         Size            =   15.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin GenerareMatrita.Buton_3D_General Butoane_Coordonate 
      Height          =   255
      Index           =   12
      Left            =   120
      TabIndex        =   19
      Top             =   7200
      Width           =   3975
      _ExtentX        =   7011
      _ExtentY        =   450
      Caption         =   "Internet"
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "German"
         Size            =   9
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin GenerareMatrita.Buton_3D_General Butoane_Coordonate 
      Height          =   495
      Index           =   13
      Left            =   120
      TabIndex        =   20
      Top             =   7560
      Width           =   4575
      _ExtentX        =   8070
      _ExtentY        =   873
      Caption         =   "Sound"
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "German"
         Size            =   9
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin GenerareMatrita.Buton_3D_General Butoane_Coordonate 
      Height          =   375
      Index           =   14
      Left            =   3720
      TabIndex        =   21
      Top             =   1320
      Width           =   1695
      _ExtentX        =   2990
      _ExtentY        =   661
      Caption         =   "Copy to ..."
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "GlaserSteD"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin GenerareMatrita.Buton_3D_General Butoane_Coordonate 
      Height          =   255
      Index           =   15
      Left            =   6120
      TabIndex        =   22
      Top             =   240
      Width           =   1815
      _ExtentX        =   3201
      _ExtentY        =   450
      Caption         =   "Intro"
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "German"
         Size            =   9
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin GenerareMatrita.Buton_3D_General Butoane_Coordonate 
      Height          =   255
      Index           =   16
      Left            =   8040
      TabIndex        =   23
      Top             =   240
      Width           =   1815
      _ExtentX        =   3201
      _ExtentY        =   450
      Caption         =   "Help"
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "German"
         Size            =   9
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin GenerareMatrita.Buton_3D_General Butoane_Coordonate 
      Height          =   255
      Index           =   17
      Left            =   120
      TabIndex        =   24
      Top             =   6120
      Width           =   2055
      _ExtentX        =   3625
      _ExtentY        =   450
      Caption         =   "Drivers"
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "German"
         Size            =   9
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin GenerareMatrita.Buton_3D_General Butoane_Coordonate 
      Height          =   255
      Index           =   18
      Left            =   120
      TabIndex        =   26
      Top             =   6480
      Width           =   2775
      _ExtentX        =   4895
      _ExtentY        =   450
      Caption         =   "Archive"
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "German"
         Size            =   9
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin GenerareMatrita.Buton_3D_General Butoane_Coordonate 
      Height          =   255
      Index           =   19
      Left            =   10320
      TabIndex        =   28
      Top             =   240
      Width           =   255
      _ExtentX        =   450
      _ExtentY        =   450
      Caption         =   "X"
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin GenerareMatrita.Buton_3D_General Butoane_Coordonate 
      Height          =   255
      Index           =   20
      Left            =   9960
      TabIndex        =   29
      Top             =   240
      Width           =   255
      _ExtentX        =   450
      _ExtentY        =   450
      Caption         =   "_"
      ButtonStyle     =   3
      OriginalPicSizeW=   0
      OriginalPicSizeH=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MousePointer    =   99
      BackColor       =   4194304
      ForeColor       =   16777215
   End
   Begin VB.Image Image2 
      Height          =   360
      Left            =   240
      Picture         =   "Modificare_Grafica.frx":312BE
      Top             =   720
      Width           =   360
   End
   Begin VB.Label Sectiune 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "Explanations"
      BeginProperty Font 
         Name            =   "BrushScrD"
         Size            =   14.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   375
      Index           =   3
      Left            =   2160
      TabIndex        =   27
      Top             =   1680
      Width           =   1335
   End
   Begin VB.Label Da_domnule 
      BackStyle       =   0  'Transparent
      Caption         =   "Path to the directory the kit is copied to"
      ForeColor       =   &H00C0C0C0&
      Height          =   255
      Left            =   5760
      TabIndex        =   25
      Top             =   1440
      Width           =   4935
   End
   Begin VB.Label Bara_principal 
      BackStyle       =   0  'Transparent
      Caption         =   " Visual preview !"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   18
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   495
      Left            =   840
      TabIndex        =   13
      Top             =   120
      Width           =   4575
   End
   Begin VB.Label Sunet_Status 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "Sound - ON"
      BeginProperty Font 
         Name            =   "German"
         Size            =   9
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H0000FF00&
      Height          =   255
      Left            =   7320
      TabIndex        =   11
      Top             =   6000
      Visible         =   0   'False
      Width           =   1815
   End
   Begin VB.Label Eu_la_suta 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "0 %"
      BeginProperty Font 
         Name            =   "German"
         Size            =   9
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H0000FF00&
      Height          =   255
      Left            =   7800
      TabIndex        =   10
      Top             =   2760
      Visible         =   0   'False
      Width           =   855
   End
   Begin VB.Label Sectiune 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "Capture"
      BeginProperty Font 
         Name            =   "German"
         Size            =   9
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00008000&
      Height          =   255
      Index           =   4
      Left            =   7440
      TabIndex        =   9
      Top             =   2280
      Width           =   1695
   End
   Begin VB.Label Sectiune 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "Section - Intro"
      BeginProperty Font 
         Name            =   "German"
         Size            =   9
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H0000C000&
      Height          =   255
      Index           =   1
      Left            =   6960
      TabIndex        =   8
      Top             =   2520
      Width           =   2535
   End
   Begin VB.Label InformatiiPrograme 
      BackStyle       =   0  'Transparent
      Caption         =   "Explanations ..."
      Height          =   2295
      Left            =   600
      TabIndex        =   7
      Top             =   2160
      Width           =   4455
   End
End
Attribute VB_Name = "Modificare_Grafica"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
