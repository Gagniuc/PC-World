VERSION 5.00
Begin VB.Form Buton_interfata 
   BorderStyle     =   0  'None
   Caption         =   "Disable/enable interface buttons ..."
   ClientHeight    =   5775
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   5415
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   5775
   ScaleWidth      =   5415
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Begin VB.CheckBox Buton_dezactivat 
      Caption         =   "_"
      Height          =   255
      Index           =   18
      Left            =   2880
      TabIndex        =   19
      Top             =   3960
      Value           =   1  'Checked
      Width           =   2055
   End
   Begin VB.CheckBox Buton_dezactivat 
      Caption         =   "X"
      Height          =   255
      Index           =   17
      Left            =   2880
      TabIndex        =   18
      Top             =   3600
      Value           =   1  'Checked
      Width           =   2055
   End
   Begin VB.CheckBox Buton_dezactivat 
      Caption         =   "Archive"
      Height          =   255
      Index           =   16
      Left            =   2880
      TabIndex        =   17
      Top             =   3120
      Value           =   1  'Checked
      Width           =   2055
   End
   Begin VB.CheckBox Buton_dezactivat 
      Caption         =   "Read me"
      Height          =   255
      Index           =   15
      Left            =   2880
      TabIndex        =   16
      Top             =   2520
      Value           =   1  'Checked
      Width           =   2055
   End
   Begin VB.CheckBox Buton_dezactivat 
      Caption         =   "Run"
      Height          =   255
      Index           =   14
      Left            =   2880
      TabIndex        =   15
      Top             =   2160
      Value           =   1  'Checked
      Width           =   2055
   End
   Begin VB.CheckBox Buton_dezactivat 
      Caption         =   "Copy"
      Height          =   255
      Index           =   13
      Left            =   2880
      TabIndex        =   14
      Top             =   1800
      Value           =   1  'Checked
      Width           =   2055
   End
   Begin VB.CheckBox Buton_dezactivat 
      Caption         =   "Install"
      Height          =   255
      Index           =   12
      Left            =   2880
      TabIndex        =   13
      Top             =   1440
      Value           =   1  'Checked
      Width           =   2055
   End
   Begin VB.CheckBox Buton_dezactivat 
      Caption         =   "Interface/Internet"
      Enabled         =   0   'False
      Height          =   255
      Index           =   11
      Left            =   2880
      TabIndex        =   12
      Top             =   960
      Value           =   1  'Checked
      Width           =   2055
   End
   Begin VB.CheckBox Buton_dezactivat 
      Caption         =   "Sound"
      Height          =   255
      Index           =   10
      Left            =   2880
      TabIndex        =   11
      Top             =   600
      Value           =   1  'Checked
      Width           =   2055
   End
   Begin VB.CommandButton Dezactiveaza_acum 
      Caption         =   "OK"
      Height          =   1095
      Left            =   240
      TabIndex        =   10
      Top             =   4440
      Width           =   4935
   End
   Begin VB.CheckBox Buton_dezactivat 
      Caption         =   "Drivers"
      Height          =   255
      Index           =   9
      Left            =   360
      TabIndex        =   9
      Top             =   3840
      Value           =   1  'Checked
      Width           =   2055
   End
   Begin VB.CheckBox Buton_dezactivat 
      Caption         =   "Help"
      Height          =   255
      Index           =   8
      Left            =   360
      TabIndex        =   8
      Top             =   3480
      Value           =   1  'Checked
      Width           =   2055
   End
   Begin VB.CheckBox Buton_dezactivat 
      Caption         =   "Intro"
      Height          =   255
      Index           =   7
      Left            =   360
      TabIndex        =   7
      Top             =   3120
      Value           =   1  'Checked
      Width           =   2055
   End
   Begin VB.CheckBox Buton_dezactivat 
      Caption         =   "Magazine"
      Height          =   255
      Index           =   6
      Left            =   360
      TabIndex        =   6
      Top             =   2760
      Value           =   1  'Checked
      Width           =   2055
   End
   Begin VB.CheckBox Buton_dezactivat 
      Caption         =   "Permanent"
      Height          =   255
      Index           =   5
      Left            =   360
      TabIndex        =   5
      Top             =   2400
      Value           =   1  'Checked
      Width           =   2055
   End
   Begin VB.CheckBox Buton_dezactivat 
      Caption         =   "Antivirus"
      Height          =   255
      Index           =   4
      Left            =   360
      TabIndex        =   4
      Top             =   2040
      Value           =   1  'Checked
      Width           =   2055
   End
   Begin VB.CheckBox Buton_dezactivat 
      Caption         =   "Internet"
      Height          =   255
      Index           =   3
      Left            =   360
      TabIndex        =   3
      Top             =   1680
      Value           =   1  'Checked
      Width           =   2055
   End
   Begin VB.CheckBox Buton_dezactivat 
      Caption         =   "Games"
      Height          =   255
      Index           =   2
      Left            =   360
      TabIndex        =   2
      Top             =   1320
      Value           =   1  'Checked
      Width           =   2055
   End
   Begin VB.CheckBox Buton_dezactivat 
      Caption         =   "Multimedia"
      Height          =   255
      Index           =   1
      Left            =   360
      TabIndex        =   1
      Top             =   960
      Value           =   1  'Checked
      Width           =   2055
   End
   Begin VB.CheckBox Buton_dezactivat 
      Caption         =   "Utilities"
      Height          =   255
      Index           =   0
      Left            =   360
      TabIndex        =   0
      Top             =   600
      Value           =   1  'Checked
      Width           =   2055
   End
   Begin VB.Shape Shape3 
      BorderColor     =   &H00000000&
      Height          =   5775
      Left            =   0
      Top             =   0
      Width           =   5415
   End
   Begin VB.Line Line4 
      BorderColor     =   &H00000000&
      X1              =   0
      X2              =   5400
      Y1              =   360
      Y2              =   360
   End
   Begin VB.Label Misca_ti_cadavrul 
      BackStyle       =   0  'Transparent
      Caption         =   " Disable/enable interface buttons ..."
      Height          =   375
      Left            =   0
      TabIndex        =   20
      Top             =   0
      Width           =   5415
   End
   Begin VB.Line Line3 
      BorderColor     =   &H00000000&
      X1              =   2760
      X2              =   5160
      Y1              =   3480
      Y2              =   3480
   End
   Begin VB.Line Line2 
      BorderColor     =   &H00000000&
      X1              =   2760
      X2              =   5160
      Y1              =   3000
      Y2              =   3000
   End
   Begin VB.Line Line1 
      BorderColor     =   &H00000000&
      X1              =   2760
      X2              =   5160
      Y1              =   1320
      Y2              =   1320
   End
   Begin VB.Shape Shape2 
      BorderColor     =   &H00000000&
      Height          =   3855
      Left            =   2760
      Top             =   480
      Width           =   2415
   End
   Begin VB.Shape Shape1 
      BorderColor     =   &H00000000&
      Height          =   3855
      Left            =   240
      Top             =   480
      Width           =   2415
   End
End
Attribute VB_Name = "Buton_interfata"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Declare Function SendMessage Lib "user32" _
Alias "SendMessageA" (ByVal hWnd As Long, _
ByVal wMsg As Long, _
ByVal wParam As Long, _
lParam As Any) As Long

Private Declare Sub ReleaseCapture Lib "user32" ()
Const WM_NCLBUTTONDOWN = &HA1
Const HTCAPTION = 2

Private Sub Dezactiveaza_acum_Click()

Geneza.Compilare_CD.Text = ""

For q = 0 To 9

If Buton_dezactivat(q).Value = 0 Then
Activat(q) = False
Geneza.Master_Control.TabEnabled(q) = False
Geneza.Compilare_CD.Text = Geneza.Compilare_CD.Text & vbCrLf & "A fost inactivat butonul " & Buton_dezactivat(q).Caption
PreFormular.Butoane_Coordonate(q).Visible = False
End If

If Buton_dezactivat(q).Value = 1 Then
Activat(q) = True
Geneza.Master_Control.TabEnabled(q) = True
Geneza.Compilare_CD.Text = Geneza.Compilare_CD.Text & vbCrLf & "Butonul " & Buton_dezactivat(q).Caption & " a ramas activ."
PreFormular.Butoane_Coordonate(q).Visible = True
End If

Next q

For q = 10 To 18

If Buton_dezactivat(q).Value = 0 Then
PreFormular.Butoane_Coordonate(q).Visible = False
Activat(q) = False
Geneza.Compilare_CD.Text = Geneza.Compilare_CD.Text & vbCrLf & "A fost inactivat butonul " & Buton_dezactivat(q).Caption
End If

If Buton_dezactivat(q).Value = 1 Then
PreFormular.Butoane_Coordonate(q).Visible = True
Activat(q) = True
Geneza.Compilare_CD.Text = Geneza.Compilare_CD.Text & vbCrLf & "Butonul " & Buton_dezactivat(q).Caption & " a ramas activ."
End If

Next q

Geneza.Master_Control.Tab = 11

Me.Hide
End Sub

Private Sub Misca_ti_cadavrul_MouseMove(Button As Integer, Shift As Integer, X As Single, y As Single)
Dim lngReturnValue As Long
If Button = 1 Then
Call ReleaseCapture
lngReturnValue = SendMessage(Me.hWnd, WM_NCLBUTTONDOWN, _
HTCAPTION, 0&)
End If
End Sub
